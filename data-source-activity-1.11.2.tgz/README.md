# Data Source Health and Activity

See which Cribl Stream Sources are sending data, which have gone quiet, which are unhealthy or far from their usual volume, and which drive your ingest volume.

## Summary

Data Source Health and Activity is a Cribl app for monitoring Stream Sources across Worker Groups. It flags Sources that have been silent for longer than you allow, warns before they get there, calls out Sources that stopped together, flags Sources whose last hour is far from their usual volume, and shows whether data is flowing. Load-balanced Sources can be grouped and treated as one Source. The Overview reloads every minute while it's open. Alerts go through Cribl's own notifications, so they reach the same email, Slack, PagerDuty, AWS SNS and webhook targets as your other Cribl alerts, even when nobody has the app open.

## What This App Does

* Primary purpose: a health and activity view of every Stream Source (input), with alerts when a Source goes quiet. The only Cribl configuration it changes is its own alert notifications: an administrator confirms each change, and the app's backend (when installed on an Enterprise plan) only narrows and restores their time window.
* Key capabilities:
  * Overview, reloaded every minute, for all Worker Groups or the ones you pick:
    * Status counts, each Source counted once, as one line or, with several Worker Groups, a table per group.
    * Needs attention: Overdue Sources and tokens, most recent first, then Sources whose health reports errors or degraded, then collectors whose latest run failed. Sources in one group that stopped together are one row.
    * Due soon: Sources and tokens quiet for 90% of their allowance or more, before they go Overdue.
    * Last hour: Sources that went Overdue or resumed; a Source Overdue more than once is one Intermittent row, with a suggested allowance when its normal gaps run past its own. Use suggested allowance… opens the Source's allowance with it filled in, to review and save.
    * Current ingest: the last 15 minutes against the 15 before.
    * A Sources-by-time activity strip for the selected range.
    * Recent activity and health reload every minute; the Source list and range chart every five minutes, or at once with Refresh. The Source and collector lists come from the app's storage for Worker Groups whose configuration hasn't changed since they were last listed (a deploy changes it); Refresh lists every group again.
    * If a reload fails, the last good data stays on screen, clearly marked stale, on the Overview, Sources and a Source's details.
  * Sources: search, filters (status, health, Worker Group, type, hide disabled; the Worker Group and type filters can be searched), sorting (kept in the link), pages of 20, 50 or 100, and CSV export, each Source's allowance, with the search, filters and time range kept in the link. Each row shows Cribl's health as an icon and has actions: Open in Cribl, Metrics in Cribl Search, Logs in Cribl Search, Copy Source ID, and for administrators Edit monitoring (its allowance and volume threshold) and Edit alert. Administrators can also tick several Sources to edit their allowance and volume threshold, stop tracking them, or group them (Group Sources), so they're treated as one Source. Token rows sit under their Source. Collectors have their own tab, with their schedule and latest run; selecting one shows its details: schedule, what each run collects, and its recent runs with links to Cribl's Job Inspector. When Cribl no longer keeps a collector's runs, its last status comes from Cribl's health metric. Arrow keys move through the list and Enter opens a Source.
  * Sources with several tokens: a Splunk HEC, Zscaler HEC or Cloudflare HEC Source with Cribl's "Emit per-token request metrics" turned on is monitored token by token. Each token gets its own row under its Source, with its own status, allowance and History; a Source's token rows can be hidden one Source at a time, or all at once with Hide tokens. A token that goes quiet shows on the Overview while the others keep its Source sending, and its Source counts with its most urgent token's status. Cribl measures a token's request size rather than its event bytes, so tokens show no bytes. A disabled token that senders still use shows how many requests Cribl refused. Other Sources that take several tokens (HTTP, Splunk S2S, Elastic and more) are measured by Cribl only as a whole, and the app says so on the Source.
  * History: every time a Source or token went Overdue, one row per silence with when it began and ended, as far back as Cribl holds metrics, with search and filters. The Overview, the Source details and History show the same Overdue periods.
  * Source details: status, Cribl's own log lines for an Overdue or unhealthy Source from the 10 minutes before the problem began (or its latest lines from the last 24 hours), its activity across the range, the times it was Overdue, its allowance, Open in Cribl, and the Cribl Search links.
  * Alerts: for each Source, three alerts, each on or off: Health (Cribl reports it red for over 5 minutes), Silence and Volume (far from its usual volume for 5 minutes), with Back when it recovers. Health and volume alerts, and a Source group's silence alert, are sent by the app's backend through Cribl Search notifications (as token alerts are, below); a grouped Source's own silence and volume alerts stop, and its health alert stays. Silence: one Cribl "No Data Received" notification per Source, using that Source's allowance as the time window, sent to the Cribl notification targets you pick (email, Slack, PagerDuty, AWS SNS, webhooks, System Messages). Different Sources can alert to different places: besides the default targets, profiles name other sets of targets and email recipients, and each Source alerts with the default, a profile, or not at all. Tick several Sources to give them the same one. Each profile, Default included, can be renamed, has its own email subject and message (using Cribl's email variables, with the Source, its Worker Group, workspace and a link to it in Cribl suggested by default), and can be saved on its own. A profile can also add fields to every alert it sends, for a webhook to use: the Source's link, its description, the kind of alert, or your own text such as a team to assign a ticket to. Nothing is added unless you choose a field, and the profile shows an example of what the webhook receives. Cribl's Leader sends them, so they work with the app closed. With this app's backend running (Cribl runs app backends on Enterprise plans), the app checks every Source every minute; when one passes its allowance, it narrows that Source's Cribl alert to a one-minute window, so Cribl alerts within a few minutes, and puts the window back as soon as the Source sends again. Without the backend, Cribl checks once per window as long as the allowance, so an alert arrives one to two allowances after the Source goes quiet. Jira, ServiceNow and similar services connect through a Webhook target or through Cribl Stream. Cribl alerts when the silence starts and when it ends. Before applying, the app shows every change and estimates how often each Source would have alerted recently. Sources already covered by a notification set up in Cribl are left alone. A token of a Source monitored token by token can alert on its own too (Off, the same as its Source, the default delivery or a profile): Cribl's notifications watch whole Sources, so token alerts go through Cribl Search notifications: one saved search per delivery (`dsh_tokens_…`) holds the notification and never runs (no Search credits), and the backend forwards that notification when a token passes its allowance or sends again, so it arrives within about a minute. The Alerts page has the on/off switch, with how often Sources are checked and whether Cribl matches the settings, then the profiles and each Source's alert with its state in Cribl. With alerts off, only the switch shows.
  * Volume (on by default; Settings › Volume thresholds turns it off for everyone): each minute, every Source's last hour is compared with its usual volume for that time, and flagged as a drop or a spike when it's above or below usual by its threshold (±30% by default), in events or in bytes, and the difference is more than random variation (at least 3 × √usual events). The usual is the median of the same clock hour on up to 5 recent days of the same kind (weekdays, or weekends), from an hourly history the app's backend keeps; until it holds 2 such days, and without the backend, the average over the hours it sent in during the last 24. The history can be filled at once from Cribl Lake (one Cribl Search per day, after measuring one hour and showing the estimated cost). Sources shows In range, Drop or Spike in a Volume column (the numbers when you point at it); Needs attention lists Sources far from their usual volume.
  * Source groups: Sources treated as one, such as one Source load-balanced across Worker Groups. A group is Active while any of its Sources receives, on its own allowance; its volume is theirs together; it counts once. Its Sources are listed under it with their own status. Make one from Sources ticked on the Sources page (Group Sources), or from a suggestion: enabled Sources of one type on one port in two or more Worker Groups.
  * Each person chooses which Sources columns they see (the gear at the right end of the table's header); the choice is theirs only.
  * Settings: Monitoring (Allowances, Volume thresholds and Source groups) and Cribl Search. Allowances: the allowable silence and expected delay (in minutes, hours or days), as defaults, rules for a Source type or Worker Group, and per-Source overrides; Sources not tracked, and Sources snoozed (snoozed from a Source's row, ended from its row or here); and Cribl Search: the "Metrics in Cribl Search" and "Logs in Cribl Search" links, each turned on or off, with the dataset its CriblMetrics or CriblLogs data is routed to (defaults `cribl_metrics` and `cribl_logs`, off until turned on) and the query. Only Organization or Workspace administrators can change them.
  * Help: statuses, allowances, alerts, keyboard keys and support. The Cribl API calls are listed under Permissions below.
  * Time ranges of 1 hour, 6 hours, 12 hours, 24 hours and 7 days.
  * Follows your Cribl light or dark theme. Same look and behaviour as Config Quest for Cribl.
* Intended users: Admin, Platform owner
* Works with: Stream (distributed deployments, Cribl.Cloud or hybrid)

Status definitions:

Each Source has an allowance: its allowable silence plus its expected delay (15 + 0 minutes unless you change them in Settings).

| Status | Meaning |
|---|---|
| Overdue | No events for longer than its allowance |
| Due soon | Active, but quiet for 90% of its allowance or more: it goes Overdue if nothing arrives |
| Active | Its last event is within its allowance |
| Not tracked | An administrator chose not to track it: no status, History or alert; counted on its own |
| Snoozed | Not tracked until a set time, then tracked again automatically; its Cribl alert is paused meanwhile |
| No data | Enabled, with no events in the last 24 hours (whatever range is selected) |
| Unknown | Recent activity couldn't be read, so Active and Overdue can't be told apart |
| Disabled | Turned off in Cribl, and not monitored |

Each Source has one status and counts once; a Source monitored token by token shows its most urgent enabled token's status. When Cribl's own Source health metric over the last two minutes reports Errors or Degraded, that shows beside the status.

## When To Use This App

* Catch a Source that stopped sending before downstream teams notice missing data.
* Find enabled Sources that never receive data and can be cleaned up.
* See which Sources drive ingest growth or a volume spike.

## Before You Install

* Required deployment: a distributed Cribl Stream Leader with Worker Groups. Single-instance deployments aren't supported yet.
* Required permissions: an admin installs the app and shares it with App users. The app's own read grants are listed under Permissions.
* Who can change Settings and alerts: Organization Owners and Admins, Workspace Owners and Admins, or a member whose role grants every action on every object (the built-in Admin role on self-managed Cribl). Everyone else the app is shared with can view.
* Alerts need a Cribl plan that includes Stream Source notifications. The every-minute check runs in the app's backend, which Cribl allows on Enterprise plans.
* The backend only changes the time window of alerts this app created and an administrator turned on; it never creates or deletes notifications. It keeps its working state in the app's storage under `state/arming` and records each run under `state/arming-run`, which the Alerts page shows. Without an Enterprise plan the app works the same, with Cribl's slower alert timing. Email, Slack, PagerDuty and other targets are set up in Cribl (Stream › Notifications › Targets); the app picks from them.
* No external systems, API keys or configuration values are needed.

## Installation

### Install From Marketplace or URL
1. Go to Apps in your Cribl environment.
2. Install from the Cribl Marketplace, or import from the Marketplace-hosted URL.
3. Review the app's permissions and complete installation.

### If The App Is Not Yet In The Cribl Marketplace
1. Download the `.tgz` package for the version you want from the repository's Releases.
2. In Cribl, go to Apps and choose import from file.
3. Upload the `.tgz` file, review the permissions and complete installation.

## Configuration

None is needed: the app reads every Stream Worker Group it is allowed to, with a 15-minute allowance (15 minutes of allowable silence plus 0 minutes of expected delay).

To change it, open Settings:

* **Allowable silence**: the longest normal gap between a Source's events.
* **Expected delay**: how late data normally arrives, including metrics reporting lag.
* **Rules by type or Worker Group**: an allowance for every Source of a type (all S3 Sources, say) or every Source in a Worker Group.
* **Per-Source overrides**: for batch or bursty Sources that are normally quiet for longer. On the Sources page, administrators can also tick several Sources and set their overrides together.

The most specific setting wins, field by field: a Source's own override, then (for a token) its Source's, then its type's rule, then its Worker Group's rule, then the defaults.

Review changes lists what will change and asks for confirmation before saving. Settings are shared by everyone the app is shared with, so only Organization or Workspace administrators can save them; everyone else sees them read-only.

## How To Use

### First-Time Setup (Alerts Last)
Help › Getting started walks through these in the app.
1. Allowances (Settings › Allowances): how long each Source may be quiet before it's Overdue. Start from the defaults, add rules by type or Worker Group, and give batch or bursty Sources longer ones.
2. Source groups: group Sources load-balanced across Worker Groups so one quiet copy isn't flagged on its own.
3. Volume checks (Settings › Volume thresholds): turn them off for everyone, or set the default threshold, rules and overrides. The checks read Cribl's own metrics and use no Search credits; only filling the history from Cribl Lake does, when an administrator starts it.
4. Leave it a day and check what it flags (Needs attention, the Volume column, History). Adjust allowances, thresholds and groups until what's flagged is what you'd act on.
5. Turn alerts on last. The review lists every change in Cribl and how often each Source would have alerted recently before anything is applied.

### Typical Workflow
1. Open the app. The Overview says when it last read the data.
2. Work through Needs attention now, newest first. A "stopped together" row usually means the Workers or their network, not each sender.
3. Check Due soon for Sources that are unusually quiet for them.
4. Use Last hour to see what just broke or recovered, and Current ingest to confirm data is flowing.
5. Open Sources to sort or filter the full list. Open Settings to give batch or bursty Sources a longer allowance.
6. On the Alerts page (once set up as above), choose where alerts go and which Sources alert, review the changes and apply them. Set up new targets in Cribl first, under Stream › Notifications › Targets.

### First-Run Checklist
* Confirm the Overview header counts your Worker Groups and shows when it last updated.
* If a warning says some data couldn't be read, check the app's permissions.

## Permissions

The app runs in Strict mode: it can call only the paths below, whatever the signed-in member's own role. Every call is a read except the alert notifications, which the app writes only after an administrator confirms the exact changes, and which its backend updates only to change their time window. If the health or recent-activity query fails, the app keeps working and marks what's incomplete. If Worker Groups, Sources or volume can't be read, it shows an error instead of guessing.

### Cribl API Endpoints Used

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/products/stream/groups` | List Stream Worker Groups |
| GET | `/api/v1/m/<group>/system/inputs` | List each group's Sources (id, type, enabled) |
| POST | `/api/v1/system/metrics/query` | Read each collector's health and events per hour (for runs Cribl no longer keeps), and Source volume (`total.in_events`, `total.in_bytes`) for the selected range, for the last 24 hours (what statuses are based on, whatever the range), and, per minute, for the last two hours (up to six, to cover allowances that long), and, in coarser windows, over any longer allowance, and health (`health.inputs`), and per minute for the last day for one unhealthy Source, to find when its health turned. For Sources with per-token metrics on, the same for each token (`http.perToken.numEvents`, `.bytesReceived`, `.numErrors`). The POST carries the query; it changes nothing. |
| GET | `/api/v1/authorize/roles` | Your roles in this session, to decide whether you can change the shared allowances |
| GET | `/api/v1/authorize/policy` | Your effective policy in this session: Cribl.Cloud reports a Workspace admin as the role `admin`, which counts only with a global all-actions grant |
| GET | `/api/v1/notification-targets` | List Cribl's notification targets for the alert settings (the app keeps only each target's ID and type) |
| GET | `/api/v1/notification-targets/<id>` | Granted alongside the list so Cribl returns the targets (the app doesn't read single targets) |
| GET | `/api/v1/notifications` | List every Worker Group's notifications in one read (each names its group), so a large estate isn't read one group at a time; a group is read on its own only if this fails |
| GET, POST | `/api/v1/m/<group>/notifications` | List a group's notifications when the one-read list can't be used; create this app's "No Data Received" notifications |
| GET | `/api/v1/m/<group>/notifications/<id>` | Read single notifications (granted alongside the list so Cribl returns them) |
| PATCH, DELETE | `/api/v1/m/<group>/notifications/dsh-*` | Update or delete this app's notifications; the backend uses PATCH to arm and restore their time window. The grant only covers IDs starting `dsh-`, so other notifications can't be changed through the app |
| GET, POST | `/api/v1/m/default_search/search/saved`; GET, POST, PATCH, DELETE `/api/v1/m/default_search/search/saved/dsh_tokens_*` | Only with token, collector, health, volume or Source group alerts on: the app's own saved searches (one per delivery; they never run) and their Search notifications, created, changed and deleted only in a reviewed apply |
| POST | `/api/v1/search/notifications` | Only with those alerts on: the backend forwards the app's own Search notification to send them (Cribl.Cloud; Cribl documents this call as the one its scheduled searches use, so a future version could change it) |
| POST, GET | `/api/v1/m/default_search/search/jobs`, `/jobs/<id>` and `/jobs/<id>/cancel`; GET `/api/v1/m/default_search/search/datasets/default_metrics` | Only with the optional look-back on (Settings › Cribl Search): one Cribl Search query, at most once an hour, for each Source's last event in the `default_metrics` dataset, cancelled if it runs too long. And only when an administrator fills the volume history (Settings › Monitoring › Volume thresholds): one query to measure an hour's cost, then one per day filled, each Source's events and bytes per hour; its cost (`/jobs/<id>/metrics`) is read to show the estimate. Cribl Search runs an app's query only on the datasets the app names, and the app names only this one, so it can't be used to search any other dataset. Read-only; Search queries use Search credits |
| GET | `/api/v1/products/stream/workers` and `/workers/<id>` | List a Worker Group's connected Workers, to read a Source's recent log lines (the item path is needed or Cribl returns an empty list) |
| GET | `/api/v1/w/<worker>/system/logs/search` and `/api/v1/m/<group>/system/logs/search` | Search each Worker's logs for one Source's channel (`input:<id>`) over a 10-minute window (before the problem began, or the latest), as Cribl's own Source › Logs tab does. Worker paths are authorized against their group path, so both are declared |
| GET | `/api/v1/m/<group>/lib/jobs` and `/lib/jobs/<id>` | List each group's collectors (the app keeps only each one's ID, type and schedule) |
| GET | `/api/v1/jobs` | Every Worker Group's collector runs in one read (each names its group), paged |
| GET | `/api/v1/m/<group>/jobs` and `/jobs/<id>` | A group's collector runs when the one-read list can't be used: each collector's recent runs (up to 10) and their state |

The app's own key-value store (granted automatically to every app) holds the allowance settings, the alert choices and the Worker Groups' Source and collector lists; see Data And Storage.

What these grants give app users, beyond what the app shows:

* The Sources grant returns each Source's full configuration in every Stream Worker Group, which can include secrets such as HEC tokens. Anyone the app is shared with can read it through the app, whatever their own role. The app reads a Source's tokens, and the token in each per-token metric, only to reduce each one to a short one-way fingerprint that tells tokens apart; it never shows, stores or exports a token.
* The metrics grant is Leader-wide. The app asks only for Source metrics, but the grant isn't limited to particular metrics or Worker Groups.
* The log grants let anyone the app is shared with search any Worker's logs through the app. The app asks only for one Source's lines, only for unhealthy Sources, and only when its details are opened.
* The collector grants return each collector's full definition, which can include credentials (a Splunk search collector's password, for example). The app keeps only the ID, type and schedule, but anyone the app is shared with can read the definitions through the app.
* The notification targets grant returns each target's full configuration, which can include secrets such as webhook URLs, keys and SMTP settings. The app keeps only each target's ID and type.
* The notification targets are read only for administrators, but the grant lets anyone the app is shared with read every target's configuration through the app.
* Updating and deleting notifications is limited by the grant to IDs starting `dsh-`, the app's own. Creating can't be limited that way: anyone the app is shared with could create a notification through the app, including one that emails any address through an Email target. Only administrators can create them in the app, but that's an app rule, not a security boundary.

Share the app only with people who may see that information.

## External API Access

None. The app makes no external calls and ships no `proxies.yml` entries.

## Data And Storage

The app stores these documents in its own key-value store: the allowance defaults, rules, per-Source and per-token overrides, the Sources not tracked and the Sources snoozed with when each snooze ends (a token's override is keyed by its fingerprint, never the token), the Cribl Search datasets and queries (`settings/search`), the alert choices (on or off, the default targets and its name, profiles with their targets, email subject and message and webhook fields, which Sources use each profile, Sources left out, the email recipients for Email targets, and the webhook field names the app manages in its notifications), each with who saved it and when, and, when the backend runs, its working state (`state/arming`: which alerts it set to check every minute and the window each had) and its last run (`state/arming-run`), and, with the look-back on, its latest result (`state/lookback`: each Source's last event and when it was looked up), the volume thresholds and Source groups (in the allowance settings), each person's own choices (`prefs/u-…`: which Sources columns they hide, suggestions they dismissed, whether the menu stays open), the backend's hourly volume history (`vol/hours/…`, a 14-day ring of each Source's events and bytes per hour, the Source list they index `vol/ids`, and the usual volumes `vol/summary`, each in pieces of at most 90 KB), its health and volume alert state (`state/monitor-alerts`) and the alerts waiting to be sent through Cribl Search (`state/token-alerts`, with `state/token-alerts-sent`, which of them a large incident has sent), and each Worker Group's Source and collector lists with its configuration version (`cache/inv2` and its numbered pieces), so a group is listed again only after a deploy changes it, plus a couple of groups each minute in turn. Those lists hold what the app reads from a Source's settings: its ID, type, whether it's turned on, a pull Source's schedule, and for a Source with several tokens each token's one-way fingerprint, description and whether it's enabled; never a token. For a collector: its ID, type, schedule, description, collection range and how long Cribl keeps its runs. Removing them only means the next load lists every group again. Email addresses are personal data: they're stored there and in each Cribl notification that sends email, and anyone the app is shared with can read them. Only administrators can save from the app, but Cribl's app storage itself is open to everyone the app is shared with, so treat that as an app-level rule rather than a security boundary.

The app's alerts are Cribl notifications, so they stay in Cribl if the app is uninstalled. To remove them, turn alerts off on the Alerts page and apply before uninstalling, or delete the notifications whose IDs start with `dsh-` under Stream › Notifications.

## Support

### Partner Built
This app is built and supported by Discovered Intelligence. For questions, bugs and feature requests, contact support@discoveredintelligence.ca.

## Known Limitations

* Sources inside Packs aren't listed yet. Their metrics are reported as unmatched on the Overview rather than dropped silently.
* Distributed deployments only.
* "Last seen" is accurate to a minute for recent events. Older events, and Sources with an allowance of 6 hours or more, are accurate to the chart interval (10 minutes up to a day, 2 hours for 7 days) or to a coarser query sized for that allowance.
* Cribl keeps one-minute metrics for only the last 2.5 hours or so, then one total per 10 minutes. A Source's Activity chart draws events per minute: each minute for the last two hours, and before that each 10-minute total as its per-minute average (the tooltip gives the 10-minute total), so a steady Source draws flat rather than as spikes. The 6-hour and 24-hour ranges use 10-minute intervals for the same reason.
* Rhythm is read from the last two hours, so a Source that sends less often than about every 40 minutes has no rhythm to compare with.
* The Overview reloads only while it's open and visible; it isn't an alerting service.
* With the 7-day range, outages that began more than two hours ago aren't grouped as "stopped together", because their start is only known to the 2-hour chart interval.
* Custom date ranges aren't available yet.
* Alerts are per Source: several Sources that stop together send one alert each. Token alerts are per delivery: tokens that change together arrive in one alert, which names the first and links to the rest.
* Token alerts need Cribl Search (Cribl.Cloud) and the app's backend (Enterprise plans), and arrive within about a minute of the backend seeing the change. Their wording is fixed: Cribl Search notifications use their own variables, so a profile's email subject and message apply to Source alerts only.
* Webhook fields go with every alert a profile sends, to all its targets. Email and System Messages ignore them (tested on Cribl.Cloud, November 2026); Slack, PagerDuty and AWS SNS targets haven't been tested with them. On Cribl's silence alerts they're each Source notification's Metadata, so changing a profile's fields updates each of its Sources' notifications. When the backend can't read the alert choices, its own alerts go without fields.
* If the app's storage is lost, the alert choices are rebuilt from its notifications in Cribl, but webhook fields aren't: the fields stay on the silence notifications, no longer managed by the app, until a profile adds a field of the same name again or they're removed in Cribl.
* A webhook field name any profile uses is the app's on all of its silence notifications (so a Source moved to another profile doesn't keep the old one's fields): metadata an administrator adds in Cribl under that name is replaced or removed at the next apply. Metadata under other names is kept.
* Turning volume checks off was added in 1.11.1. An earlier version ignores the switch (it checks volume) and drops it when it saves anything, so after upgrading reload every open tab of the app, and don't roll back to an earlier version while volume checks are off.
* Webhook fields were added in 1.11. Saving alert choices from an earlier version drops them from the choices, and the app stops managing them: they stay on Cribl's silence notifications (earlier versions keep metadata they don't manage) until they're removed in Cribl, or a profile adds a field of the same name again.
* Volume against the same hour on recent days needs the app's backend (Enterprise plans) and a week or so of its history, or a fill from Cribl Lake (which needs CriblMetrics routed to `default_metrics`, and uses Search credits). Until then, and without the backend, the last 24 hours' average is used, so a Source with a daily rhythm reads as drops at night and spikes by day.
* Weekdays and weekends follow the time zone chosen in Settings › Monitoring › Volume thresholds (UTC until one is chosen); hours are clock hours in UTC, so a zone with a half-hour offset shifts the hour by 30 minutes.
* Volume isn't checked for collectors, scheduled-pull Sources, tokens, a usual of under 10 events an hour, or an hour in which the Source was quiet for longer than its allowance (its silence is the news).
* The last 24 hours' average counts only the hours a Source sent in (at least 3), so a Source new today, or back from a long outage, isn't read as a spike.
* A Source group's health is shown as its worst Source's; health alerts stay per Source.
* Volume thresholds and Source groups were added in 1.10. Saving allowances from an earlier version drops them, so reload every open tab of the app after upgrading. With thousands of overrides the allowances are stored in pieces, which an earlier version can't read at all.
* Alerts don't follow allowance changes by themselves. After changing allowances, review and apply the alert changes the app lists.
* Cribl's Source notifications require an eligible plan or licence, and the Leader must be able to reach each target.
* A webhook target that needs a token should have it in the target's own authentication setting in Cribl (Auth token). A custom Authorization header is sent with the app's health, volume and token alerts but not with Cribl's silence (No Data) alerts, so the receiver refuses those (tested on Cribl.Cloud, November 2026).
* The alert preview is an estimate from the last two hours of one-minute metrics; Cribl evaluates on its own schedule.
* History reaches back only as far as Cribl holds metrics. Cribl's Leader keeps them in memory, limited by volume rather than time, and loses them on restart (about a day and a half on the Cribl.Cloud tenant it was tested on). Overdue periods in the last two hours are to the minute; earlier ones are to 10 minutes, so a shorter silence before then may not show.
* The Cribl Search links need setting up: route the CriblMetrics and CriblLogs Sources to a dataset Cribl Search can read (a Cribl Lake dataset, for example), then turn each link on in Settings › Cribl Search with that dataset. On Cribl.Cloud the built-in `cribl_metrics` and `cribl_logs` datasets hold only the Leader's own data and can't be routed to. The default queries fit CriblMetrics and CriblLogs routed to a Cribl Lake dataset with CriblMetrics' default name prefix (`cribl.logstream.`), verified on Cribl.Cloud; both can be edited there if yours differ. On Cribl.Cloud, routing them to the existing `default_metrics` and `default_logs` datasets works: one Cribl Lake Destination per dataset and a Route per Source (filter `__inputId=='cribl:CriblMetrics'` or `__inputId=='cribl:CriblLogs'`).
* Collectors are checked by their latest run only; data they collect isn't counted per collector. Cribl keeps runs for the collector's time to live (4 hours by default), so the details list only those.
* A collector's runs older than its time to live show only as its last health in Cribl's metrics, which the Leader keeps for about a day on Cribl.Cloud; older than that, nothing is recorded.
* Sources not tracked and snoozed Sources were added in 1.7.0. Earlier versions show them as usual and would offer to create or turn on their alerts; saving allowances from an earlier version drops both lists.
* A snoozed Source's alert is paused and resumed by the app's backend, which needs an Enterprise plan. Without it, the Alerts page lists the pause and the resume for an administrator to apply.
* Cribl's Leader keeps about a day of per-Source metrics (28 hours on Cribl.Cloud). Without the Cribl Search look-back, a Source silent for longer, or one that sends less often, reads No data, and History and Last hour can't tell when such a Source last sent. With the look-back on, its last event comes from the `default_metrics` Cribl Lake dataset, as far back as that dataset keeps. That needs a Route sending the CriblMetrics Source to `default_metrics`: it's the only dataset the app is allowed to search. It runs at most once an hour; an administrator can run it at once with Search now (Settings › Cribl Search).
* Allowance rules were added in 1.5.0. An older version of the app reads the allowances without them, and saving allowances from an older version drops them.
* Alert profiles were added in 1.6.0. Once a profile is saved, versions before 1.6.0 can't read the alert choices and won't change alerts until they're upgraded, so they can't send profile Sources' alerts back to the default targets.
* The logs search finds a Source's cribl.log lines by their `input:<id>` channel, verified for streaming Sources. Scheduled-pull Sources (Office 365, Wiz, ServiceNow and similar) haven't been checked with live data.
* Source types that Cribl Stream's UI has no page for (Edge-only types and S3 Inventory) open the Worker Group's Sources list.
* Monitoring each token needs Cribl's "Emit per-token request metrics" on and deployed for that Source (off by default), and exists only for Splunk HEC, Zscaler HEC and Cloudflare HEC Sources. Until Cribl reports per-token data, the Source is monitored as a whole.
* Cribl's alerts watch whole Sources, so one token going quiet sends no Cribl alert; it shows in the app. A Source's own alert fires only once every token has stopped.
* A token whose settings reference a stored secret is matched to its metrics by its description. Without a unique description it can't be monitored by name; its traffic shows under the tokens Cribl reports, and only while they send. Rotating a token's value makes it a new token to the app: its per-token allowance override no longer applies.
* Faster alerts need the app's backend, which Cribl installs only on Enterprise plans. Without it, Cribl checks once per window as long as the allowance.
* Even with faster alerts, Cribl adds about five minutes between its check and the alert (measured on Cribl.Cloud), so an alert arrives about 7–8 minutes after a Source passes its allowance.
* A Source with an allowance of 6 hours or more is checked on a coarser query (5-minute windows for a day-long allowance), so its arming can be up to that much later; other Sources keep one-minute precision.
* Cribl keeps its metrics for about a day and a half. A Source silent for longer than that, inside a longer allowance, reads Unknown unless the Cribl Search look-back finds its last event.

## Troubleshooting

### The App Opens But Some Features Do Not Work
A yellow notice names the query that failed. Check that the installed app still has the grants listed under Permissions.

### The App Shows "Couldn't load Source activity"
A 401 or 403 means the app isn't allowed to read Worker Groups, Sources or metrics. Ask an admin to review the app's Permissions.

### A Page Shows "This page couldn't be shown"
Part of the page failed to draw. Try again usually draws it. If it comes back, press Copy details and send the text to support: it holds the app's version, the page, the time and where the error happened, nothing else from the page.

### Large Estates (Many Worker Groups)
The browser reads metrics in batches of Worker Groups of about 250 Sources each; a batch that can't be read after one retry leaves only its groups out, with a notice, until the next reload. The backend keeps within 50 Leader API calls a minute (Cribl's default App Settings limit): it lists at most 8 Worker Groups a run until the stored lists are complete (then only changed ones, and two a minute in turn; a group waiting its turn after a deploy uses its previous lists meanwhile), reads every group's notifications and collector runs in one call each, and makes at most 8 alert changes a run (arming first; the rest the next minute, so when a whole group stops its alerts arm over a few minutes). A run notes groups it didn't read. It's set to 512 MB of memory: at about 1,400 sending Sources one run needs close to 300 MB.

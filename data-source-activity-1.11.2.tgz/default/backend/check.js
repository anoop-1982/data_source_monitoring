var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/check.ts
var check_exports = {};
__export(check_exports, {
  onRequest: () => onRequest
});
module.exports = __toCommonJS(check_exports);

// src/api/client.ts
var ApiError = class extends Error {
  constructor(status, path, detail) {
    super(`${status} from ${path.split("?")[0]}${detail ? `: ${detail}` : ""}`);
    this.status = status;
  }
};
function errorDetail(body) {
  const text2 = body.trim();
  if (!text2 || text2.startsWith("<"))
    return "";
  try {
    const parsed = JSON.parse(text2);
    const said = typeof parsed?.message === "string" ? parsed.message : typeof parsed?.error === "string" ? parsed.error : void 0;
    if (said)
      return said.slice(0, 200);
  } catch {
  }
  return text2.slice(0, 200);
}
var unreadable = (path) => new Error(`Cribl's answer from ${path.split("?")[0]} wasn't in the form this app reads`);
async function parse(res, path) {
  if (!res.ok)
    throw new ApiError(res.status, path, errorDetail(await res.text().catch(() => "")));
  const text2 = await res.text();
  try {
    return JSON.parse(text2);
  } catch {
    throw unreadable(path);
  }
}
async function apiGet(t, path, signal) {
  return parse(await t(path, { signal }), path);
}
async function apiQuery(t, path, body, signal) {
  const res = await t(path, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    signal
  });
  const parsed = await parse(res, path);
  const results = parsed && typeof parsed === "object" ? parsed.results : null;
  if (results === null || results !== void 0 && !Array.isArray(results))
    throw unreadable(path);
  return parsed;
}
async function apiWrite(t, method, path, body) {
  const res = await t(path, {
    method,
    ...body === void 0 ? {} : { headers: { "content-type": "application/json" }, body: JSON.stringify(body) }
  });
  if (!res.ok)
    throw new ApiError(res.status, path, errorDetail(await res.text().catch(() => "")));
  const text2 = await res.text().catch(() => "");
  try {
    return text2 ? JSON.parse(text2) : void 0;
  } catch {
    return void 0;
  }
}
function itemsOf(payload) {
  if (payload === void 0)
    return [];
  if (Array.isArray(payload))
    return payload;
  if (payload && typeof payload === "object" && Array.isArray(payload.items)) {
    return payload.items;
  }
  throw new Error(`Cribl's answer wasn't in the form this app reads`);
}

// src/data/tokens.ts
var PER_TOKEN_TYPES = /* @__PURE__ */ new Set(["splunk_hec", "zscaler_hec", "cloudflare_hec"]);
function fingerprint(secret) {
  let h = 2166136261;
  for (let i = 0; i < secret.length; i++) {
    h ^= secret.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h.toString(16).padStart(8, "0");
}
var asRecord = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
var text = (v) => typeof v === "string" && v.trim() ? v.trim() : void 0;
function parseSourceTokens(type, item) {
  const raw = [...Array.isArray(item.authTokens) ? item.authTokens : [], ...Array.isArray(item.authTokensExt) ? item.authTokensExt : []];
  if (raw.length < 2)
    return void 0;
  if (!PER_TOKEN_TYPES.has(type))
    return { count: raw.length, perToken: "unsupported", tokens: [] };
  const tokens = raw.map((t) => {
    if (typeof t === "string")
      return { fp: t ? fingerprint(t) : "", enabled: true };
    const o = asRecord(t) ?? {};
    const secret = typeof o.token === "string" && o.token && o.authType !== "secret" ? o.token : void 0;
    return { fp: secret ? fingerprint(secret) : "", description: text(o.description), enabled: o.enabled !== false };
  });
  return { count: raw.length, perToken: item.emitTokenMetrics === true ? "on" : "off", tokens };
}
var KEEP = ["inputId", "tokenDescription", "__worker_group", "starttime", "endtime", "_time", "events", "bytes", "rejected", "recentEvents", "recentBytes"];
function scrubTokenRows(rows) {
  return rows.map((row) => {
    const out = { tokenFp: typeof row.token === "string" && row.token ? fingerprint(row.token) : "" };
    for (const k of KEEP)
      if (k in row)
        out[k] = row[k];
    return out;
  });
}
function tokenKey(t, index) {
  return t.fp ? `t${t.fp}` : t.description ? `d${fingerprint(t.description)}` : `n${index}`;
}
var tokenRowId = (sourceRowId, key) => `${sourceRowId}#${key}`;
var TOKEN_SUFFIX = /#(?:t[0-9a-f]{8}|d[0-9a-f]{8}|n\d+)$/;
var parentRowId = (rowId) => rowId.replace(TOKEN_SUFFIX, "");

// src/data/cron.ts
var RANGES = [
  [0, 59],
  [0, 23],
  [1, 31],
  [1, 12],
  [0, 7]
];
var NAMES = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6, jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function field(text2, [lo, hi]) {
  const out = /* @__PURE__ */ new Set();
  for (const part of text2.replace(/[A-Za-z]{3}/g, (n) => n.toLowerCase() in NAMES ? String(NAMES[n.toLowerCase()]) : n).split(",")) {
    const m = /^(\*|(\d+)(?:-(\d+))?)(?:\/(\d+))?$/.exec(part.trim());
    if (!m)
      return void 0;
    const step = m[4] ? Number(m[4]) : 1;
    const from = m[1] === "*" ? lo : Number(m[2]);
    const to = m[1] === "*" ? hi : m[3] !== void 0 ? Number(m[3]) : m[4] ? hi : from;
    if (step < 1 || from < lo || to > hi || from > to)
      return void 0;
    for (let v = from; v <= to; v += step)
      out.add(v);
  }
  return out.size ? out : void 0;
}
var DAY_MS = 864e5;
var HORIZON_DAYS = 400;
var known = /* @__PURE__ */ new Map();
function cronLongestGapMinutes(cron, from = Date.UTC(2026, 0, 5)) {
  const key = `${cron ?? ""}|${from}`;
  if (known.has(key))
    return known.get(key);
  const gap = longestGap(cron, from);
  known.set(key, gap);
  return gap;
}
function longestGap(cron, from) {
  const f = (cron ?? "").trim().split(/\s+/);
  if (f.length !== 5)
    return void 0;
  const sets = f.map((v, i) => field(v, RANGES[i]));
  if (sets.some((s) => !s))
    return void 0;
  const [mins, hours, doms, months, dows] = sets;
  if (dows.has(7))
    dows.add(0);
  const domAny = f[2] === "*";
  const dowAny = f[4] === "*";
  let previous;
  let longest = 0;
  let count = 0;
  const start = Math.floor(from / DAY_MS) * DAY_MS;
  const sortedHours = [...hours].sort((a, b) => a - b);
  const sortedMins = [...mins].sort((a, b) => a - b);
  for (let d = 0; d < HORIZON_DAYS; d++) {
    const day = new Date(start + d * DAY_MS);
    if (!months.has(day.getUTCMonth() + 1))
      continue;
    const domOk = doms.has(day.getUTCDate());
    const dowOk = dows.has(day.getUTCDay());
    if (!(domAny || dowAny ? domOk && dowOk : domOk || dowOk))
      continue;
    for (const h of sortedHours)
      for (const m of sortedMins) {
        const at = d * 1440 + h * 60 + m;
        if (previous !== void 0)
          longest = Math.max(longest, at - previous);
        previous = at;
        count++;
      }
  }
  return count < 2 ? void 0 : longest;
}

// src/data/thresholds.ts
var VOLUME_METHODS = ["sameKindOfDay", "flat24"];
var volumeChecksOn = (settings) => settings.volume.enabled !== false;
function knownTimeZone(tz) {
  if (typeof tz !== "string" || !tz || tz.length > 64)
    return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}
var DEFAULT_THRESHOLDS = { allowableSilenceMinutes: 15, expectedDelayMinutes: 0 };
var DEFAULT_VOLUME = { pct: 30, method: "sameKindOfDay", rules: {}, overrides: {} };
var DEFAULT_SETTINGS = { version: 1, defaults: DEFAULT_THRESHOLDS, rules: {}, overrides: {}, untracked: [], snoozed: {}, volume: DEFAULT_VOLUME, sourceGroups: [] };
var VOLUME_MIN_PCT = 5;
var VOLUME_MAX_PCT = 1e3;
var GROUP_ROW_PREFIX = "sg:";
var isGroupRowId = (rowId) => rowId.startsWith(GROUP_ROW_PREFIX) && /^sg:[a-z0-9-]{1,40}$/.test(rowId);
var SNOOZE_MAX_MINUTES = 30 * 24 * 60;
var SNOOZE_KEPT_MS = 7 * 24 * 60 * 6e4;
var snoozedUntil = (settings, rowId, now) => {
  const until = settings.snoozed[rowId];
  return until !== void 0 && until > now ? until : void 0;
};
var typeRule = (type) => `type:${type}`;
var groupRule = (group) => `group:${group}`;
var RULE_KEY = /^(type|group):./;
function rowScope(rowId) {
  const m = /^([^/]+)\/([^:/]+):/.exec(rowId);
  return m ? { group: m[1], type: m[2] } : void 0;
}
var MAX_MINUTES = 7 * 24 * 60;
var MIN_SILENCE = 1;
function minutes(v, min) {
  if (typeof v !== "number" || !Number.isFinite(v))
    return void 0;
  return Math.min(MAX_MINUTES, Math.max(min, Math.round(v)));
}
function parseSettings(raw) {
  const obj = raw && typeof raw === "object" ? raw : {};
  const d = obj.defaults && typeof obj.defaults === "object" ? obj.defaults : {};
  const defaults = {
    allowableSilenceMinutes: minutes(d.allowableSilenceMinutes, MIN_SILENCE) ?? DEFAULT_THRESHOLDS.allowableSilenceMinutes,
    expectedDelayMinutes: minutes(d.expectedDelayMinutes, 0) ?? DEFAULT_THRESHOLDS.expectedDelayMinutes
  };
  return {
    version: 1,
    defaults,
    rules: partials(obj.rules, (key) => RULE_KEY.test(key)),
    overrides: partials(obj.overrides, () => true),
    // Whole Sources only (`<group>/<type>:<id>`), or Source groups (`sg:<id>`): a token is tracked with its Source.
    untracked: Array.isArray(obj.untracked) ? [...new Set(obj.untracked.filter((x) => typeof x === "string" && wholeRow(x)))].sort() : [],
    snoozed: Object.fromEntries(
      Object.entries(obj.snoozed && typeof obj.snoozed === "object" && !Array.isArray(obj.snoozed) ? obj.snoozed : {}).filter(
        (e) => wholeRow(e[0]) && typeof e[1] === "number" && Number.isFinite(e[1])
      )
    ),
    volume: parseVolume(obj.volume),
    sourceGroups: parseSourceGroups(obj.sourceGroups),
    updatedAt: typeof obj.updatedAt === "number" ? obj.updatedAt : void 0,
    updatedBy: typeof obj.updatedBy === "string" ? obj.updatedBy : void 0
  };
}
var wholeRow = (id) => rowScope(id) !== void 0 && !id.includes("#") || isGroupRowId(id);
function pctOf(v) {
  if (typeof v !== "number" || !Number.isFinite(v))
    return void 0;
  const n = Math.round(v);
  return n <= 0 ? 0 : Math.min(VOLUME_MAX_PCT, Math.max(VOLUME_MIN_PCT, n));
}
function parseVolume(raw) {
  const o = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  const keyed = (m, keyOk) => {
    const out = {};
    if (!m || typeof m !== "object" || Array.isArray(m))
      return out;
    for (const [k, v] of Object.entries(m)) {
      const p = pctOf(v);
      if (keyOk(k) && p !== void 0)
        out[k] = p;
    }
    return out;
  };
  return {
    pct: pctOf(o.pct) ?? DEFAULT_VOLUME.pct,
    method: VOLUME_METHODS.includes(o.method) ? o.method : DEFAULT_VOLUME.method,
    rules: keyed(o.rules, (k) => RULE_KEY.test(k)),
    overrides: keyed(o.overrides, wholeRow),
    ...knownTimeZone(o.timeZone) ? { timeZone: o.timeZone } : {},
    // Stored only when off, so a document saved with checks on reads as before.
    ...o.enabled === false ? { enabled: false } : {}
  };
}
var GROUP_NAME_MAX = 80;
function parseSourceGroups(raw) {
  if (!Array.isArray(raw))
    return [];
  const out = [];
  const taken = /* @__PURE__ */ new Set();
  const ids = /* @__PURE__ */ new Set();
  const names = /* @__PURE__ */ new Set();
  for (const g of raw) {
    if (!g || typeof g !== "object")
      continue;
    const o = g;
    const id = typeof o.id === "string" ? o.id : "";
    const name = typeof o.name === "string" ? o.name.trim().replace(/\s+/g, " ").slice(0, GROUP_NAME_MAX) : "";
    if (!isGroupRowId(`${GROUP_ROW_PREFIX}${id}`) || !name || ids.has(id) || names.has(name.toLowerCase()))
      continue;
    const members = (Array.isArray(o.members) ? o.members : []).filter(
      (m) => typeof m === "string" && rowScope(m) !== void 0 && !m.includes("#") && !isCollectorRowId(m) && !taken.has(m)
    );
    const unique = [...new Set(members)].sort();
    if (unique.length === 0)
      continue;
    for (const m of unique)
      taken.add(m);
    ids.add(id);
    names.add(name.toLowerCase());
    out.push({ id, name, members: unique });
  }
  return out;
}
function groupScope(settings, id) {
  if (!isGroupRowId(id))
    return void 0;
  const def = settings.sourceGroups?.find((g) => `${GROUP_ROW_PREFIX}${g.id}` === id);
  const scopes = (def?.members ?? []).map(rowScope).filter((x) => x !== void 0);
  if (scopes.length === 0)
    return void 0;
  const same = (k) => scopes.every((x) => x[k] === scopes[0][k]) ? scopes[0][k] : "";
  return { group: same("group"), type: same("type") };
}
function volumePctFor(settings, rowId) {
  const v = settings.volume;
  if (v.enabled === false)
    return 0;
  const id = parentRowId(rowId);
  if (v.overrides[id] !== void 0)
    return v.overrides[id];
  const scope = rowScope(id) ?? groupScope(settings, id);
  if (scope && v.rules[typeRule(scope.type)] !== void 0)
    return v.rules[typeRule(scope.type)];
  if (scope && v.rules[groupRule(scope.group)] !== void 0)
    return v.rules[groupRule(scope.group)];
  return v.pct;
}
function partials(raw, keyOk) {
  const out = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    return out;
  for (const [key, value] of Object.entries(raw)) {
    if (!keyOk(key) || !value || typeof value !== "object")
      continue;
    const v = value;
    const o = {};
    const s = minutes(v.allowableSilenceMinutes, MIN_SILENCE);
    const dl = minutes(v.expectedDelayMinutes, 0);
    if (s !== void 0)
      o.allowableSilenceMinutes = s;
    if (dl !== void 0)
      o.expectedDelayMinutes = dl;
    if (Object.keys(o).length > 0)
      out[key] = o;
  }
  return out;
}
var schedules = /* @__PURE__ */ new Map();
var isCollectorRowId = (rowId) => /^[^/]+\/collection:/.test(rowId);
function registerCollectorSchedules(entries) {
  for (const [id, cron] of entries)
    schedules.set(id, { gap: cronLongestGapMinutes(cron), kind: "collector" });
}
function registerPullSchedules(entries) {
  for (const [id, gap] of entries) {
    if (gap !== void 0 && gap > 0)
      schedules.set(id, { gap, kind: "pull" });
    else
      schedules.delete(id);
  }
}
function scheduleBase(gapMinutes) {
  const gap = gapMinutes ?? 24 * 60;
  return { allowableSilenceMinutes: Math.min(MAX_MINUTES, Math.max(MIN_SILENCE, Math.ceil(2 * gap))), expectedDelayMinutes: 15 };
}
var isScheduledRowId = (rowId) => isCollectorRowId(rowId) || schedules.get(rowId)?.kind === "pull";
function levels(settings, rowId) {
  if (isCollectorRowId(rowId))
    return [
      { kind: "override", values: settings.overrides[rowId] },
      { kind: "schedule", values: scheduleBase(schedules.get(rowId)?.gap) }
    ];
  const parent = parentRowId(rowId);
  const scope = rowScope(rowId);
  const pull = schedules.get(rowId);
  return [
    { kind: "override", values: settings.overrides[rowId] },
    { kind: "source", values: parent !== rowId ? settings.overrides[parent] : void 0 },
    { kind: "type", key: scope?.type, values: scope ? settings.rules[typeRule(scope.type)] : void 0 },
    { kind: "group", key: scope?.group, values: scope ? settings.rules[groupRule(scope.group)] : void 0 },
    pull?.kind === "pull" ? { kind: "schedule", values: scheduleBase(pull.gap) } : { kind: "default", values: settings.defaults }
  ];
}
function thresholdsFor(settings, rowId) {
  const own = schedules.get(rowId);
  const merged = isCollectorRowId(rowId) || own?.kind === "pull" ? scheduleBase(own?.gap) : { ...settings.defaults };
  for (const level of levels(settings, rowId).reverse())
    Object.assign(merged, level.values);
  return merged;
}
function allowanceMs(t) {
  return (t.allowableSilenceMinutes + t.expectedDelayMinutes) * 6e4;
}
function maxAllowanceMs(settings, upToMs = Infinity) {
  let max = 0;
  const consider = (ms) => {
    if (ms <= upToMs)
      max = Math.max(max, ms);
  };
  consider(allowanceMs(settings.defaults));
  const rules = (prefix) => [void 0, ...Object.entries(settings.rules).filter(([k]) => k.startsWith(prefix)).map(([, v]) => v)];
  for (const g of rules("group:"))
    for (const t of rules("type:"))
      consider(allowanceMs({ ...settings.defaults, ...g, ...t }));
  for (const key of Object.keys(settings.overrides))
    if (!isScheduledRowId(key) && !isGroupRowId(key))
      consider(allowanceMs(thresholdsFor(settings, key)));
  return max;
}
var RECENT_MIN_LOOKBACK_SECONDS = 2 * 60 * 60;
var RECENT_MAX_LOOKBACK_SECONDS = 6 * 60 * 60;
function recentQueryShape(settings) {
  const fits2 = maxAllowanceMs(settings, (RECENT_MAX_LOOKBACK_SECONDS - 60) * 1e3);
  const lookbackSeconds = Math.min(RECENT_MAX_LOOKBACK_SECONDS, Math.max(RECENT_MIN_LOOKBACK_SECONDS, Math.ceil(fits2 / 1e3) + 60));
  return { lookbackSeconds, windowSeconds: 60 };
}
function longQueryShape(settings) {
  const lookbackSeconds = Math.ceil(maxAllowanceMs(settings) / 1e3) + 60;
  if (lookbackSeconds <= RECENT_MAX_LOOKBACK_SECONDS)
    return void 0;
  return { lookbackSeconds, windowSeconds: Math.ceil(lookbackSeconds / 360 / 60) * 60 };
}

// src/data/ranges.ts
var RANGES2 = [
  { key: "1h", label: "Last 1 hour", seconds: 3600, windowSeconds: 60 },
  { key: "6h", label: "Last 6 hours", seconds: 21600, windowSeconds: 600 },
  { key: "12h", label: "Last 12 hours", seconds: 43200, windowSeconds: 600 },
  { key: "24h", label: "Last 24 hours", seconds: 86400, windowSeconds: 600 },
  { key: "7d", label: "Last 7 days", seconds: 604800, windowSeconds: 7200 }
];
function rangeFor(key) {
  return RANGES2.find((r) => r.key === key) ?? RANGES2[3];
}
function bucketStarts(range, now) {
  const w = range.windowSeconds * 1e3;
  const count = Math.round(range.seconds / range.windowSeconds);
  const last = Math.floor(now / w) * w;
  return Array.from({ length: count }, (_, i) => last - (count - 1 - i) * w);
}

// src/data/criblNames.ts
var ALIASES = [{ inventory: "criblmetrics", cribl: "cribl", id: "CriblMetrics" }];
var NO_STREAM_PAGE = /* @__PURE__ */ new Set([
  "apple_unified_logs",
  "edge_prometheus",
  "exec",
  "file",
  "journal_files",
  "kube_events",
  "kube_logs",
  "kube_metrics",
  "s3_inventory",
  "system_metrics",
  "system_state",
  "win_event_logs",
  "windows_metrics"
]);
var criblType = (type) => ALIASES.find((a) => a.inventory === type)?.cribl ?? type;
var criblInput = (type, id) => `${criblType(type)}:${id}`;
function inventoryInput(input) {
  const i = input.indexOf(":");
  if (i < 0)
    return input;
  const type = input.slice(0, i);
  const id = input.slice(i + 1);
  const alias = ALIASES.find((a) => a.cribl === type && a.id === id);
  return alias ? `${alias.inventory}:${id}` : input;
}

// src/data/activity.ts
var FIELDS = { events: "events", bytes: "bytes", recent: "recentEvents", recentBytes: "recentBytes", health: "health", rejected: "rejected" };
function toEpochMs(t) {
  if (typeof t !== "number" || !Number.isFinite(t))
    return void 0;
  return t < 1e11 ? t * 1e3 : t;
}
function num(v) {
  return typeof v === "number" && Number.isFinite(v) && v > 0 ? v : 0;
}
function resolveKey(key, known2) {
  if (known2.has(key))
    return { base: key, variant: false };
  let k = key;
  for (let i = k.lastIndexOf(":"); i > 0; i = k.lastIndexOf(":")) {
    k = k.slice(0, i);
    if (known2.has(k))
      return { base: k, variant: true };
  }
  return void 0;
}
var Slot = class {
  constructor() {
    this.base = 0;
    this.variants = 0;
    this.hasBase = false;
  }
  add(value, variant) {
    if (variant)
      this.variants += value;
    else {
      this.base += value;
      this.hasBase = true;
    }
  }
  get value() {
    return this.hasBase ? this.base : this.variants;
  }
};
function rowTime(row) {
  return toEpochMs(row.starttime) ?? toEpochMs(row._time);
}
var UNTIMED = -1;
function rowKeys(row) {
  const input = row.input;
  const group = row.__worker_group;
  if (typeof input !== "string" || !input)
    return void 0;
  if (typeof group !== "string" || !group)
    return void 0;
  return { input, group };
}
function classify(s) {
  if (s.disabled)
    return "disabled";
  if (!s.recentAvailable)
    return s.events > 0 ? "unknown" : "nodata";
  if (s.lastActiveEnd !== void 0 && s.now - s.lastActiveEnd <= s.allowanceMs)
    return "active";
  if (s.events <= 0 && s.lastActiveEnd === void 0)
    return "nodata";
  return "overdue";
}
function healthLevel(level) {
  if (level === void 0)
    return void 0;
  if (level >= 2)
    return "error";
  if (level >= 1)
    return "degraded";
  return "healthy";
}
function buildActivity(input) {
  const { sources, range, now, seriesRows, recentRows, healthRows: healthRows2 } = input;
  const w = range.windowSeconds * 1e3;
  let anchor = now;
  for (const row of seriesRows) {
    const t = rowTime(row);
    if (t !== void 0 && t > anchor && t <= now + w)
      anchor = t;
  }
  const buckets = bucketStarts(range, anchor);
  const start = buckets[0];
  const knownByGroup = /* @__PURE__ */ new Map();
  const accs = /* @__PURE__ */ new Map();
  const collectors = input.collectors ?? [];
  for (const s of [...sources, ...collectors]) {
    const base = `${s.type}:${s.id}`;
    let known2 = knownByGroup.get(s.group);
    if (!known2)
      knownByGroup.set(s.group, known2 = /* @__PURE__ */ new Set());
    known2.add(base);
    const acc = { windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map() };
    accs.set(`${s.group}/${base}`, acc);
    const alias = criblInput(s.type, s.id);
    if (alias !== base) {
      known2.add(alias);
      accs.set(`${s.group}/${alias}`, acc);
    }
  }
  const unmatched = /* @__PURE__ */ new Set();
  const pullIds = /* @__PURE__ */ new Map();
  for (const s of sources)
    if (s.pull)
      pullIds.set(`${s.group}/${s.id}`, s);
  const parts = /* @__PURE__ */ new Map();
  const partAcc = (group, input2) => {
    const m = /^collection:([^:]+):(.+)$/.exec(input2);
    if (!m || !pullIds.has(`${group}/${m[1]}`))
      return void 0;
    const key = `${group}/${m[1]}`;
    let byPart = parts.get(key);
    if (!byPart)
      parts.set(key, byPart = /* @__PURE__ */ new Map());
    let acc = byPart.get(m[2]);
    if (!acc)
      byPart.set(m[2], acc = { windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map() });
    return acc;
  };
  const resolved = /* @__PURE__ */ new Map();
  const noneKnown = /* @__PURE__ */ new Set();
  const match = (row, hasData) => {
    const keys = rowKeys(row);
    if (!keys)
      return void 0;
    const k = `${keys.group}\0${keys.input}`;
    let hit = resolved.get(k);
    if (hit === void 0) {
      const r = resolveKey(keys.input, knownByGroup.get(keys.group) ?? noneKnown);
      const acc = r && accs.get(`${keys.group}/${r.base}`);
      const part = acc ? void 0 : partAcc(keys.group, keys.input);
      hit = r && acc ? { acc, variant: r.variant } : part ? { acc: part, variant: false } : null;
      resolved.set(k, hit);
    }
    if (!hit) {
      if (hasData && !keys.input.startsWith("collection:"))
        unmatched.add(`${keys.group}/${keys.input}`);
      return void 0;
    }
    return hit;
  };
  for (const row of seriesRows) {
    const events = num(row[FIELDS.events]);
    const bytes = num(row[FIELDS.bytes]);
    const m = match(row, events > 0 || bytes > 0);
    if (m)
      addSeries(m.acc, row, events, bytes, m.variant);
  }
  for (const row of input.statusRows ?? []) {
    const m = match(row, false);
    if (m)
      addBasis(m.acc, row, num(row[FIELDS.events]), m.variant, num(row[FIELDS.bytes]));
  }
  const rw = input.recentWindowSeconds * 1e3;
  let recentLast = Math.floor(now / rw) * rw;
  for (const row of recentRows ?? []) {
    const events = num(row[FIELDS.recent]);
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const m = match(row, events > 0);
    if (!m)
      continue;
    if (t > recentLast && t <= now + rw)
      recentLast = t;
    addRecent(m.acc, t, events, num(row[FIELDS.recentBytes]), m.variant);
  }
  for (const row of input.longRows ?? []) {
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const m = match(row, false);
    if (m)
      addLong(m.acc, t, num(row[FIELDS.recent]), m.variant);
  }
  const recentFirst = Math.floor(input.recentEarliest / rw) * rw;
  const recentBuckets = recentRows === void 0 || recentLast < recentFirst ? [] : Array.from({ length: (recentLast - recentFirst) / rw + 1 }, (_, i) => recentFirst + i * rw);
  for (const row of healthRows2 ?? []) {
    const level = row[FIELDS.health];
    if (typeof level !== "number" || !Number.isFinite(level))
      continue;
    const m = match(row, false);
    if (m && (m.acc.health === void 0 || level > m.acc.health))
      m.acc.health = level;
  }
  const ctx = {
    now,
    w,
    rw,
    start,
    buckets,
    recentBuckets,
    recentFirst,
    range,
    recentAvailable: recentRows !== void 0,
    recentEarliest: input.recentEarliest,
    recentWindowSeconds: input.recentWindowSeconds,
    basis: input.statusRows !== void 0,
    wb: (input.statusWindowSeconds ?? range.windowSeconds) * 1e3,
    ...input.longWindowSeconds !== void 0 ? { long: { windowMs: input.longWindowSeconds * 1e3, read: input.longRows !== void 0, from: oldestRow(input.longRows) } } : {}
  };
  for (const [key, byPart] of parts) {
    const s = pullIds.get(key);
    const own = accs.get(`${s.group}/${s.type}:${s.id}`);
    const together = mergeAccs([...byPart.values()], void 0);
    if (totalEvents(together) > totalEvents(own))
      accs.set(`${s.group}/${s.type}:${s.id}`, { ...together, health: own.health === void 0 ? together.health : Math.max(own.health, together.health ?? 0) });
  }
  const recentSpan = now - input.recentEarliest;
  const judgeLong = (row, rec4, acc) => rec4.pull && rec4.pullGapMinutes !== void 0 && row.allowanceMs > recentSpan && !row.disabled ? bySchedule(row, now, acc, ctx) : row;
  const out = sources.map((s) => {
    const id = `${s.group}/${s.type}:${s.id}`;
    const acc = accs.get(id);
    return {
      id,
      sourceId: s.id,
      name: s.id,
      group: s.group,
      type: s.type,
      disabled: s.disabled,
      ...s.port !== void 0 ? { port: s.port } : {},
      health: healthLevel(acc.health),
      ...summarize(acc, s.disabled, input.allowanceMs(id), ctx),
      ...(() => {
        const day = dayTotals(acc, ctx);
        return day ? { day } : {};
      })(),
      ...s.tokens ? { tokens: { count: s.tokens.count, perToken: s.tokens.perToken, split: false } } : {},
      ...s.pull ? { pull: true, ...s.pullGapMinutes !== void 0 ? { pullEveryMinutes: s.pullGapMinutes } : {} } : {}
    };
  });
  for (let i = 0; i < out.length; i++) {
    const s = sources[i];
    out[i] = s.pull && s.pullGapMinutes !== void 0 ? judgeLong(out[i], s, accs.get(out[i].id)) : judgeOnLong(out[i], accs.get(out[i].id), ctx);
  }
  const collectorRows = collectors.map((c) => {
    const id = `${c.group}/collection:${c.id}`;
    const summary = summarize(accs.get(id), false, input.allowanceMs(id), ctx);
    const row = {
      id,
      sourceId: c.id,
      name: c.id,
      group: c.group,
      type: "collection",
      disabled: false,
      health: healthLevel(accs.get(id).health),
      ...c.collector ? { collector: c.collector } : {},
      ...summary
    };
    if (c.collector?.scheduled === false)
      return { ...row, status: "untracked" };
    return bySchedule(row, now, accs.get(id), ctx);
  });
  const partRows = [];
  for (const parent of out) {
    const byPart = parts.get(`${parent.group}/${parent.sourceId}`);
    if (!byPart || !pullIds.has(`${parent.group}/${parent.sourceId}`))
      continue;
    for (const [key, acc] of [...byPart].sort(([a], [b]) => a.localeCompare(b))) {
      const label = key.replace(/_/g, " ");
      partRows.push({
        id: `${parent.id}~${key}`,
        sourceId: parent.sourceId,
        name: `${parent.sourceId} \u203A ${label}`,
        group: parent.group,
        type: parent.type,
        disabled: parent.disabled,
        part: { key, parentId: parent.id },
        health: healthLevel(acc.health),
        ...summarize(acc, parent.disabled, parent.allowanceMs, ctx)
      });
      if (!parent.disabled && parent.allowanceMs > recentSpan && pullIds.get(`${parent.group}/${parent.sourceId}`)?.pullGapMinutes !== void 0)
        partRows[partRows.length - 1] = bySchedule(partRows[partRows.length - 1], now, acc, ctx);
      else
        partRows[partRows.length - 1] = judgeOnLong(partRows[partRows.length - 1], acc, ctx);
    }
  }
  const tokens = [];
  const wantsSplit = sources.some((s) => s.tokens?.perToken === "on");
  const tokensFailed = wantsSplit && (input.tokenSeriesRows === void 0 || input.tokenRecentRows === void 0);
  if (wantsSplit && !tokensFailed) {
    sources.forEach((s, i) => {
      if (s.tokens?.perToken !== "on")
        return;
      const { rows, unmatched: unmatched2 } = buildTokenRows(s, out[i], input, { ...ctx, basis: ctx.basis && input.tokenStatusRows !== void 0 });
      if (unmatched2 > 0)
        out[i] = { ...out[i], tokens: { ...out[i].tokens, unmatched: unmatched2 } };
      if (rows.length === 0)
        return;
      tokens.push(...rows);
      out[i] = { ...out[i], tokens: { ...out[i].tokens, split: true } };
    });
  }
  const { untracked, snoozed } = input;
  const track = (s) => {
    if (s.disabled)
      return s;
    const root = s.token ? s.token.parentId : s.id;
    if (untracked?.(root))
      return { ...s, status: "untracked" };
    const until = snoozed?.(root);
    return until !== void 0 ? { ...s, status: "untracked", snoozedUntil: until } : s;
  };
  const sourcesOut = untracked || snoozed ? out.map(track) : out;
  const tokensOut = untracked || snoozed ? tokens.map(track) : tokens;
  const collectorsOut = untracked || snoozed ? collectorRows.map(track) : collectorRows;
  const partsOut = partRows.map((p) => {
    const parent = sourcesOut.find((s) => s.id === p.part.parentId);
    return parent && parent.status === "untracked" && !p.disabled ? { ...p, status: "untracked", ...parent.snoozedUntil !== void 0 ? { snoozedUntil: parent.snoozedUntil } : {} } : p;
  });
  let keptStart;
  if (ctx.basis) {
    for (const acc of accs.values())
      for (const [t, slot] of acc.basis ?? [])
        if (slot.value > 0 && (keptStart === void 0 || t < keptStart))
          keptStart = t;
  } else {
    const first = buckets.findIndex((_, i) => out.some((x) => (x.eventsSeries[i] ?? 0) > 0));
    if (first >= 0)
      keptStart = buckets[first];
  }
  const priorCoverage = {
    coversBefore: ctx.basis ? true : buckets.length > 0 && buckets[0] + w <= recentFirst,
    ...keptStart !== void 0 ? { keptFrom: keptStart + (ctx.basis ? ctx.wb : w) } : {}
  };
  return {
    buckets,
    windowSeconds: range.windowSeconds,
    sources: sourcesOut,
    ...tokensOut.length > 0 ? { tokens: tokensOut } : {},
    ...tokensFailed ? { tokensFailed } : {},
    ...input.collectors ? { collectors: collectorsOut } : {},
    ...partsOut.length > 0 ? { parts: partsOut } : {},
    unmatchedSeries: [...unmatched].sort(),
    recentAvailable: recentRows !== void 0,
    recentWindowSeconds: input.recentWindowSeconds,
    recentBuckets,
    healthAvailable: healthRows2 !== void 0,
    ...recentRows !== void 0 ? { priorCoverage } : {},
    generatedAt: now
  };
}
var COLLECTOR_STATUS_SPAN_MS = 24 * 36e5;
function bySchedule(input, now, acc, c) {
  let row = input;
  const last = row.lastSeen === void 0 && c?.long ? newestLong(acc) : void 0;
  if (last !== void 0)
    row = { ...row, lastSeen: last, lastSeenResolutionSeconds: c.long.windowMs / 1e3 };
  if (row.lastSeen === void 0)
    return { ...row, status: row.allowanceMs <= COLLECTOR_STATUS_SPAN_MS ? "nodata" : "unknown", silentMs: void 0 };
  const silent = Math.max(0, now - (row.lastSeen + (row.lastSeenResolutionSeconds ?? 60) * 1e3));
  return { ...row, silentMs: silent, status: silent > row.allowanceMs ? "overdue" : "active" };
}
function mergeAccs(list, health) {
  const out = { windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map(), health };
  for (const a of list) {
    for (const [t, x] of a.windows) {
      let w = out.windows.get(t);
      if (!w)
        out.windows.set(t, w = { events: new Slot(), bytes: new Slot() });
      w.events.add(x.events.value, false);
      w.bytes.add(x.bytes.value, false);
    }
    for (const [t, x] of a.recent) {
      let w = out.recent.get(t);
      if (!w)
        out.recent.set(t, w = { events: new Slot(), bytes: new Slot() });
      w.events.add(x.events.value, false);
      w.bytes.add(x.bytes.value, false);
    }
    for (const [t, x] of a.basis ?? []) {
      const basis = out.basis ??= /* @__PURE__ */ new Map();
      let slot = basis.get(t);
      if (!slot)
        basis.set(t, slot = new Slot());
      slot.add(x.value, false);
    }
    for (const [t, x] of a.long ?? []) {
      const long = out.long ??= /* @__PURE__ */ new Map();
      let slot = long.get(t);
      if (!slot)
        long.set(t, slot = new Slot());
      slot.add(x.value, false);
    }
    if (a.health !== void 0 && (out.health === void 0 || a.health > out.health))
      out.health = a.health;
  }
  return out;
}
function totalEvents(acc) {
  let n = 0;
  for (const w of acc.windows.values())
    n += w.events.value;
  if (n > 0)
    return n;
  for (const w of acc.basis?.values() ?? [])
    n += w.value;
  if (n > 0)
    return n;
  for (const w of acc.recent.values())
    n += w.events.value;
  if (n > 0)
    return n;
  for (const w of acc.long?.values() ?? [])
    n += w.value;
  return n;
}
function addSeries(acc, row, events, bytes, variant) {
  const t = rowTime(row) ?? UNTIMED;
  let win = acc.windows.get(t);
  if (!win)
    acc.windows.set(t, win = { events: new Slot(), bytes: new Slot() });
  win.events.add(events, variant);
  win.bytes.add(bytes, variant);
}
function addBasis(acc, row, events, variant, bytes = 0) {
  const t = rowTime(row);
  if (t === void 0)
    return;
  const basis = acc.basis ??= /* @__PURE__ */ new Map();
  let slot = basis.get(t);
  if (!slot)
    basis.set(t, slot = new Slot());
  slot.add(events, variant);
  const basisBytes = acc.basisBytes ??= /* @__PURE__ */ new Map();
  let bslot = basisBytes.get(t);
  if (!bslot)
    basisBytes.set(t, bslot = new Slot());
  bslot.add(bytes, variant);
}
var HOUR_MS = 36e5;
function coveredHours(spans, now) {
  let ms = 0;
  for (const k of spans.keys)
    ms += Math.max(0, Math.min((k + 1) * HOUR_MS, now) - Math.max(k * HOUR_MS, spans.first));
  return ms / HOUR_MS;
}
function dayTotals(acc, c) {
  let events = 0;
  let bytes = 0;
  const keys = /* @__PURE__ */ new Set();
  let first;
  const add = (t, v) => {
    events += v;
    if (v <= 0)
      return;
    keys.add(Math.floor(t / HOUR_MS));
    if (first === void 0 || t < first)
      first = t;
  };
  if (c.basis) {
    for (const [t, s] of acc.basis ?? [])
      add(t, s.value);
    for (const s of acc.basisBytes?.values() ?? [])
      bytes += s.value;
  } else {
    if (c.range.key !== "24h")
      return void 0;
    for (const [t, w] of acc.windows) {
      if (t === UNTIMED)
        continue;
      add(t, w.events.value);
      bytes += w.bytes.value;
    }
  }
  if (first === void 0)
    return { events, bytes, hours: 0 };
  const spans = { first, keys: [...keys].sort((a, b) => a - b) };
  return { events, bytes, hours: coveredHours(spans, c.now), spans };
}
function newestLong(acc) {
  let last;
  for (const [t, slot] of acc?.long ?? [])
    if (slot.value > 0 && (last === void 0 || t > last))
      last = t;
  return last;
}
function oldestRow(rows) {
  let first;
  for (const row of rows ?? []) {
    const t = rowTime(row);
    if (t !== void 0 && (first === void 0 || t < first))
      first = t;
  }
  return first;
}
function addLong(acc, t, events, variant) {
  const long = acc.long ??= /* @__PURE__ */ new Map();
  let slot = long.get(t);
  if (!slot)
    long.set(t, slot = new Slot());
  slot.add(events, variant);
}
function judgeOnLong(row, acc, c) {
  const recentSpan = c.now - c.recentEarliest;
  if (!c.long || !c.recentAvailable || row.disabled || row.allowanceMs <= recentSpan || row.status === "active")
    return row;
  const bounds = [];
  if (row.lastSeen !== void 0 && row.status !== "nodata") {
    const res = row.lastSeenResolutionSeconds ?? 60;
    bounds.push({ seen: row.lastSeen, res, end: row.lastSeen + res * 1e3 });
  }
  const last = newestLong(acc);
  if (last !== void 0)
    bounds.push({ seen: last, res: c.long.windowMs / 1e3, end: last + c.long.windowMs });
  if (bounds.length === 0) {
    const basisSpan = c.basis ? COLLECTOR_STATUS_SPAN_MS : c.range.seconds * 1e3;
    const reaches = row.allowanceMs <= basisSpan || c.long.read && c.long.from !== void 0 && c.long.from <= c.now - row.allowanceMs;
    return reaches ? row : { ...row, status: "unknown", silentMs: void 0, lastSeen: void 0, lastSeenResolutionSeconds: void 0 };
  }
  const b = bounds.reduce((x, y) => y.end < x.end ? y : x);
  const silentMs = Math.max(0, c.now - Math.min(b.end, c.now, c.recentEarliest));
  return { ...row, lastSeen: b.seen, lastSeenResolutionSeconds: b.res, silentMs, status: silentMs > row.allowanceMs ? "overdue" : "active" };
}
function addRecent(acc, t, events, bytes, variant) {
  let slot = acc.recent.get(t);
  if (!slot)
    acc.recent.set(t, slot = { events: new Slot(), bytes: new Slot() });
  slot.events.add(events, variant);
  slot.bytes.add(bytes, variant);
}
function summarize(acc, disabled, allowance, c) {
  const { now, w, rw, start, buckets, recentBuckets, recentFirst } = c;
  let events = 0;
  let bytes = 0;
  let lastSeen;
  const eventsSeries = buckets.map(() => 0);
  const bytesSeries = buckets.map(() => 0);
  for (const [t, win] of acc.windows) {
    const e = win.events.value;
    const b = win.bytes.value;
    events += e;
    bytes += b;
    if (t === UNTIMED)
      continue;
    if (e > 0 && (lastSeen === void 0 || t > lastSeen))
      lastSeen = t;
    const idx = Math.floor((t - start) / w);
    if (idx < 0 || idx >= buckets.length)
      continue;
    eventsSeries[idx] += e;
    bytesSeries[idx] += b;
  }
  let lastActive;
  const recentEvents = recentBuckets.map(() => 0);
  const recentBytes = recentBuckets.map(() => 0);
  for (const [t, slot] of acc.recent) {
    const e = slot.events.value;
    if (e > 0 && (lastActive === void 0 || t > lastActive))
      lastActive = t;
    const idx = (t - recentFirst) / rw;
    if (Number.isInteger(idx) && idx >= 0 && idx < recentBuckets.length) {
      recentEvents[idx] += e;
      recentBytes[idx] += slot.bytes.value;
    }
  }
  const lastActiveEnd = lastActive === void 0 ? void 0 : Math.min(lastActive + rw, now);
  let statusEvents = events;
  let seen = lastSeen;
  if (c.basis) {
    statusEvents = 0;
    seen = void 0;
    for (const [t, slot] of acc.basis ?? []) {
      statusEvents += slot.value;
      if (slot.value > 0 && (seen === void 0 || t > seen))
        seen = t;
    }
  }
  const basisWidth = c.basis ? c.wb : w;
  let seenWidth = basisWidth;
  if (c.basis && seen === void 0 && lastSeen !== void 0) {
    seen = lastSeen;
    seenWidth = w;
  }
  let priorEnd;
  const basisWindows = c.basis ? [...acc.basis ?? []].map(([t, slot]) => [t, slot.value]) : [...acc.windows].filter(([t]) => t !== UNTIMED).map(([t, win]) => [t, win.events.value]);
  for (const [t, e] of basisWindows) {
    if (e <= 0 || t >= recentFirst)
      continue;
    let end;
    if (t + basisWidth <= recentFirst)
      end = t + basisWidth;
    else {
      let inside = 0;
      for (const [rt, slot] of acc.recent)
        if (rt + rw <= t + basisWidth)
          inside += slot.events.value;
      if (e > inside)
        end = recentFirst;
    }
    if (end !== void 0 && (priorEnd === void 0 || end > priorEnd))
      priorEnd = end;
  }
  let lastEventEnd = lastActiveEnd;
  if (lastEventEnd === void 0 && seen !== void 0) {
    lastEventEnd = Math.min(seen + seenWidth, now);
    if (c.recentAvailable)
      lastEventEnd = Math.min(lastEventEnd, c.recentEarliest);
  }
  const precise = lastActive !== void 0 && (seen === void 0 || lastActive >= seen);
  return {
    status: classify({ disabled, events: statusEvents, recentAvailable: c.recentAvailable, lastActiveEnd, allowanceMs: allowance, now }),
    events,
    bytes,
    allowanceMs: allowance,
    lastSeen: precise ? lastActive : seen,
    lastSeenResolutionSeconds: precise ? c.recentWindowSeconds : seen !== void 0 ? seenWidth / 1e3 : void 0,
    silentMs: lastEventEnd === void 0 ? void 0 : Math.max(0, now - lastEventEnd),
    ...priorEnd !== void 0 ? { priorEnd, priorStraddles: priorEnd === recentFirst } : {},
    eventsSeries,
    bytesSeries,
    recentEvents,
    recentBytes
  };
}
var newAcc = () => ({ windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map() });
function buildTokenRows(s, parent, input, c) {
  const all = s.tokens.tokens;
  const descriptionCount = /* @__PURE__ */ new Map();
  for (const t of all)
    if (!t.fp && t.description)
      descriptionCount.set(t.description, (descriptionCount.get(t.description) ?? 0) + 1);
  const matchable = (t) => Boolean(t.fp) || t.description !== void 0 && descriptionCount.get(t.description) === 1;
  const units = [];
  const byKey = /* @__PURE__ */ new Map();
  all.forEach((t, i) => {
    if (!matchable(t))
      return;
    const key = tokenKey(t, i);
    const same = byKey.get(key);
    if (same)
      same.enabled ||= t.enabled;
    else {
      const unit = { key, fp: t.fp, description: t.description, enabled: t.enabled, acc: newAcc(), rejected: 0, listed: true };
      units.push(unit);
      byKey.set(key, unit);
    }
  });
  const unmatched = all.filter((t) => !matchable(t)).length;
  const byFp = new Map(units.filter((u) => u.fp).map((u) => [u.fp, u]));
  const byDescription = new Map(units.filter((u) => !u.fp && u.description).map((u) => [u.description, u]));
  let reported = false;
  const unitOf = (row) => {
    if (row.inputId !== s.id || row.__worker_group !== s.group)
      return void 0;
    reported = true;
    const fp = typeof row.tokenFp === "string" ? row.tokenFp : "";
    const description = typeof row.tokenDescription === "string" && row.tokenDescription.trim() ? row.tokenDescription.trim() : void 0;
    const found = (fp ? byFp.get(fp) : void 0) ?? (description ? byDescription.get(description) : void 0);
    if (found)
      return found;
    if (!fp)
      return void 0;
    const unit = { key: `t${fp}`, fp, description, enabled: true, acc: newAcc(), rejected: 0, listed: false };
    units.push(unit);
    byFp.set(fp, unit);
    return unit;
  };
  for (const row of input.tokenSeriesRows ?? []) {
    const u = unitOf(row);
    if (!u)
      continue;
    addSeries(u.acc, row, num(row[FIELDS.events]), num(row[FIELDS.bytes]), false);
    u.rejected += num(row[FIELDS.rejected]);
  }
  for (const row of input.tokenRecentRows ?? []) {
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const u = unitOf(row);
    if (u)
      addRecent(u.acc, t, num(row[FIELDS.recent]), num(row[FIELDS.recentBytes]), false);
  }
  for (const row of input.tokenStatusRows ?? []) {
    const u = unitOf(row);
    if (u)
      addBasis(u.acc, row, num(row[FIELDS.events]), false);
  }
  for (const row of input.tokenLongRows ?? []) {
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const u = unitOf(row);
    if (u)
      addLong(u.acc, t, num(row[FIELDS.recent]), false);
  }
  if (!reported)
    return { rows: [], unmatched };
  const sending = (u) => [...u.acc.windows.values(), ...u.acc.recent.values()].some((x) => x.events.value > 0);
  const shown = units.filter((u) => u.listed || sending(u));
  const labels = shown.map((u) => u.description ?? `token ${u.fp ? u.fp.slice(0, 6) : u.key}`);
  const rows = shown.map((u, i) => {
    const plain = labels[i];
    const label = labels.filter((l) => l === plain).length > 1 && u.fp ? `${plain} (${u.fp.slice(0, 6)})` : plain;
    const id = tokenRowId(parent.id, u.key);
    const disabled = parent.disabled || !u.enabled;
    return {
      id,
      sourceId: parent.sourceId,
      name: `${parent.sourceId} \u203A ${label}`,
      group: parent.group,
      type: parent.type,
      disabled,
      token: { key: u.key, label: u.listed ? label : `${label} (not in the Source's settings)`, parentId: parent.id, enabled: u.enabled, rejected: u.rejected },
      ...summarize(u.acc, disabled, input.allowanceMs(id), c)
    };
  });
  const tc = c.long ? { ...c, long: { ...c.long, read: input.tokenLongRows !== void 0, from: oldestRow(input.tokenLongRows) } } : c;
  return { rows: rows.map((r, i) => judgeOnLong(r, shown[i].acc, tc)), unmatched };
}

// src/data/sourceGroups.ts
var groupRowId = (id) => `${GROUP_ROW_PREFIX}${id}`;
var DAY_MS2 = 24 * 36e5;
var groupable = (s) => !s.token && !s.part && !s.collector && !s.pull && !s.sourceGroup && rowScope(s.id) !== void 0 && !isCollectorRowId(s.id);
var HEALTH_RANK = { healthy: 0, degraded: 1, error: 2 };
function sumSeries(list) {
  if (list.length === 0 || list.some((l) => l.length === 0))
    return [];
  const out = new Array(Math.max(...list.map((l) => l.length))).fill(0);
  for (const l of list)
    for (let i = 0; i < l.length; i++)
      out[i] += l[i] ?? 0;
  return out;
}
function groupDay(days, now) {
  const events = days.reduce((n, d) => n + d.events, 0);
  const bytes = days.reduce((n, d) => n + d.bytes, 0);
  const withEvents = days.filter((d) => d.events > 0);
  if (withEvents.length === 0 || !withEvents.every((d) => d.spans))
    return { events, bytes, hours: Math.max(...days.map((d) => d.hours)) };
  const most = /* @__PURE__ */ new Map();
  for (const d of withEvents)
    for (const k of d.spans.keys)
      most.set(k, Math.max(most.get(k) ?? 0, coveredHours({ first: d.spans.first, keys: [k] }, now)));
  const spans = { first: Math.min(...withEvents.map((d) => d.spans.first)), keys: [...most.keys()].sort((a, b) => a - b) };
  return { events, bytes, hours: [...most.values()].reduce((n, h) => n + h, 0), spans };
}
function applySourceGroups(model, settings, unreadGroups = []) {
  if (settings.sourceGroups.length === 0)
    return model;
  const byId = new Map(model.sources.map((s) => [s.id, s]));
  const unread = new Set(unreadGroups);
  const now = model.generatedAt;
  const grouped = /* @__PURE__ */ new Set();
  const rows = [];
  const members = [];
  for (const def of settings.sourceGroups) {
    const rowId = groupRowId(def.id);
    const found = def.members.map((m) => byId.get(m)).filter((s) => s !== void 0 && groupable(s) && !grouped.has(s.id));
    for (const s of found)
      grouped.add(s.id);
    const missing = def.members.filter((m) => !found.some((s) => s.id === m));
    const enabled = found.filter((s) => !s.disabled && s.status !== "untracked");
    const allQuietByChoice = found.some((s) => !s.disabled) && enabled.length === 0;
    const allowance = allowanceMs(thresholdsFor(settings, rowId));
    const snooze = settings.snoozed[rowId];
    const snoozedUntil2 = snooze !== void 0 && snooze > now ? snooze : void 0;
    const untracked = settings.untracked.includes(rowId) || snoozedUntil2 !== void 0;
    const silent = enabled.map((s) => s.silentMs).filter((v) => v !== void 0);
    const minSilent = silent.length ? Math.min(...silent) : void 0;
    const newest = enabled.filter((s) => s.lastSeen !== void 0).sort((a, b) => b.lastSeen - a.lastSeen)[0];
    const prior = enabled.filter((s) => s.priorEnd !== void 0).sort((a, b) => b.priorEnd - a.priorEnd)[0];
    const events = enabled.reduce((n, s) => n + s.events, 0);
    let status = classify({
      disabled: found.length > 0 && enabled.length === 0 && !allQuietByChoice,
      // Whether any sent within the day statuses are judged on (their own statuses), not the chart range's events.
      events: enabled.some((s) => s.status !== "nodata") ? 1 : 0,
      recentAvailable: model.recentAvailable,
      lastActiveEnd: minSilent === void 0 ? void 0 : now - minSilent,
      allowanceMs: allowance,
      now
    });
    const unsure = enabled.some((s) => s.status === "unknown") || missing.some((m) => unread.has(rowScope(m)?.group ?? ""));
    if (status !== "active" && status !== "disabled" && unsure)
      status = "unknown";
    if (found.length === 0 && !unsure)
      status = "nodata";
    if (status === "nodata" && allowance > DAY_MS2)
      status = "unknown";
    if ((untracked || allQuietByChoice) && status !== "disabled")
      status = "untracked";
    const live = found.filter((s) => !s.disabled);
    const membersSnoozed = allQuietByChoice && live.every((s) => s.snoozedUntil !== void 0) ? Math.min(...live.map((s) => s.snoozedUntil)) : void 0;
    const healths = enabled.map((s) => s.health).filter((h) => h !== void 0);
    const groups = [...new Set(def.members.map((m) => rowScope(m)?.group).filter((g) => Boolean(g)))].sort();
    const types = [...new Set(found.map((s) => s.type))];
    const day = enabled.every((s) => s.day) && enabled.length > 0 ? groupDay(enabled.map((s) => s.day), now) : void 0;
    rows.push({
      id: rowId,
      sourceId: def.name,
      name: def.name,
      group: groups.length === 1 ? groups[0] : "",
      type: types.length === 1 ? types[0] : types.length === 0 ? "\u2014" : "mixed",
      disabled: status === "disabled",
      status,
      ...healths.length ? { health: healths.sort((a, b) => HEALTH_RANK[b] - HEALTH_RANK[a])[0] } : {},
      events,
      bytes: enabled.reduce((n, s) => n + s.bytes, 0),
      allowanceMs: allowance,
      ...newest ? { lastSeen: newest.lastSeen, ...newest.lastSeenResolutionSeconds !== void 0 ? { lastSeenResolutionSeconds: newest.lastSeenResolutionSeconds } : {}, ...newest.lastSeenFromSearch ? { lastSeenFromSearch: true } : {} } : {},
      ...minSilent !== void 0 && status !== "disabled" ? { silentMs: minSilent } : {},
      ...prior ? { priorEnd: prior.priorEnd, ...prior.priorStraddles ? { priorStraddles: true } : {} } : {},
      ...(snoozedUntil2 ?? membersSnoozed) !== void 0 ? { snoozedUntil: snoozedUntil2 ?? membersSnoozed } : {},
      eventsSeries: sumSeries(enabled.map((s) => s.eventsSeries)).length ? sumSeries(enabled.map((s) => s.eventsSeries)) : model.buckets.map(() => 0),
      bytesSeries: sumSeries(enabled.map((s) => s.bytesSeries)).length ? sumSeries(enabled.map((s) => s.bytesSeries)) : model.buckets.map(() => 0),
      recentEvents: model.recentAvailable ? enabled.length ? sumSeries(enabled.map((s) => s.recentEvents)) : model.recentBuckets.map(() => 0) : [],
      recentBytes: model.recentAvailable ? enabled.length ? sumSeries(enabled.map((s) => s.recentBytes)) : model.recentBuckets.map(() => 0) : [],
      ...day ? { day } : {},
      sourceGroup: { id: def.id, members: found.map((s) => s.id), missing, groups }
    });
    for (const s of found)
      members.push({ ...s, memberOf: rowId });
  }
  if (grouped.size === 0 && rows.length === 0)
    return model;
  return {
    ...model,
    sources: [...model.sources.filter((s) => !grouped.has(s.id)), ...rows],
    members: [...model.members ?? [], ...members],
    // A grouped Source's tokens go with it: the group is what's watched for silence.
    ...model.tokens ? { tokens: model.tokens.filter((t) => !grouped.has(t.token.parentId)) } : {}
  };
}

// src/data/urgency.ts
var MIN = 6e4;
var NEW_MS = 60 * MIN;
var CHANGE_WINDOW_MS = 60 * MIN;
var TOGETHER_GAP_MS = 5 * MIN;
var TOGETHER_SPAN_MS = 10 * MIN;
var TOGETHER_MAX_RESOLUTION_S = 15 * 60;
var CHART_WINDOW_MS = 5 * MIN;

// src/data/alerts.ts
var ALERT_PREFIX = "dsh-";
var NO_DATA = "no-data";
var ARMED_WINDOW = "1m";
var SYSTEM_TARGET = "system_notifications";
function asRecord2(v) {
  return v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
}
function parseTargets(payload) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const o = asRecord2(item);
    if (typeof o?.id === "string" && o.id && typeof o.type === "string" && o.type)
      out.push({ id: o.id, type: o.type });
  }
  return out.sort((a, b) => a.id === SYSTEM_TARGET ? -1 : b.id === SYSTEM_TARGET ? 1 : a.id.localeCompare(b.id));
}
var SOURCE_LINK = "{source_link}";
var SUBJECT_MAX = 300;
var BODY_MAX = 8e3;
function defaultEmailMessage(cribleCloud) {
  return {
    subject: "Cribl ${status}: ${input} in ${__worker_group}",
    body: [
      "Cribl reports ${status} for Source ${input} in Worker Group ${__worker_group}: no data for ${timewindow} (OK means its data is flowing again).",
      "",
      "Source: ${input}",
      "Worker Group: ${__worker_group}",
      ...cribleCloud ? ["Workspace: ${workspace}", "Organization: ${organization}"] : [],
      "Time window: ${timewindow}",
      "Status: ${status}",
      "Sent: ${timestamp}",
      "",
      "Sent by Data Source Health and Activity (Cribl notification ${cribl_notification})."
    ].join("\n")
  };
}
function legacyEmailMessage(cribleCloud) {
  const m = defaultEmailMessage(cribleCloud);
  const lines = m.body.split("\n");
  lines.splice(lines.length - 1, 0, `Open in Cribl: ${SOURCE_LINK}`, "");
  return { subject: m.subject, body: lines.join("\n") };
}
var DESCRIPTION_MAX = 500;
var isCollectorRow = (rowId) => /^[^/]+\/collection:/.test(rowId);
var defaultDescription = (rowId) => `Link to access this ${isCollectorRow(rowId) ? "collector" : "Source"} in Cribl: ${SOURCE_LINK}`;
function descriptionFor(settings, rowId) {
  const own = settings.descriptions[rowId];
  return own === void 0 ? defaultDescription(rowId) : own || void 0;
}
var cleanDescription = (text2) => text2.replace(/\r\n?/g, "\n").split("\n").map((l) => l.trimEnd()).filter((l) => l.trim()).join("\n").trim().slice(0, DESCRIPTION_MAX);
var DESCRIPTION_LABEL = "Description: ";
function extractDescription(body) {
  const lines = body.split("\n");
  if (lines.length < 3 || lines[1] !== "" || !lines[2].startsWith(DESCRIPTION_LABEL))
    return { body };
  let end = 3;
  while (end < lines.length && lines[end] !== "")
    end++;
  const description = [lines[2].slice(DESCRIPTION_LABEL.length), ...lines.slice(3, end)].join("\n");
  const rest = lines.slice(end + 1);
  return { body: [lines[0], ...rest.length ? ["", ...rest] : []].join("\n"), description };
}
var sourcePathFor = () => void 0;
var viewerBase = () => void 0;
var linkBaseFor = (settings) => settings.linkBase ?? viewerBase() ?? void 0;
var escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
var unfillLink = (s, onBase) => {
  const path = sourcePathFor(s);
  if (!path) {
    const plain = new RegExp(escapeRe(`${s.group} \u203A ${criblInput(s.type, s.sourceId)}`), "g");
    return (text2) => text2.replace(plain, SOURCE_LINK);
  }
  const re = new RegExp(`(https?://[^\\s"'<>]*?)${escapeRe(path)}(?![\\w/-]|\\.\\w)`, "g");
  return (text2) => text2.replace(re, (_m, base) => {
    onBase?.(base);
    return SOURCE_LINK;
  });
};
function parseMessage(v, cap = true) {
  const m = asRecord2(v);
  const subject = typeof m?.subject === "string" ? m.subject.replace(/\s+/g, " ").trim().slice(0, cap ? SUBJECT_MAX : void 0) : "";
  const body = typeof m?.body === "string" ? m.body.replace(/\r\n/g, "\n").replace(/\s+$/, "").slice(0, cap ? BODY_MAX : void 0) : "";
  return subject || body ? { ...subject ? { subject } : {}, ...body ? { body } : {} } : void 0;
}
var sameMessage = (a, b) => (a?.subject ?? "") === (b?.subject ?? "") && (a?.body ?? "") === (b?.body ?? "");
function str(v) {
  return typeof v === "string" && v.trim() ? v.trim() : void 0;
}
function parseNotifications(group, payload) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const o = asRecord2(item);
    if (typeof o?.id !== "string" || !o.id || typeof o.condition !== "string")
      continue;
    if (typeof o.group === "string" && o.group && o.group !== group)
      continue;
    const conf = asRecord2(o.conf) ?? {};
    const emailByTarget = {};
    const messageByTarget = {};
    for (const tc of Array.isArray(o.targetConfigs) ? o.targetConfigs : []) {
      const c = asRecord2(tc);
      const r = asRecord2(asRecord2(c?.conf)?.emailRecipient);
      const to = str(r?.to);
      if (typeof c?.id === "string" && to)
        emailByTarget[c.id] = { to, cc: str(r?.cc), bcc: str(r?.bcc) };
      const m = parseMessage(asRecord2(c?.conf), false);
      if (typeof c?.id === "string" && m)
        messageByTarget[c.id] = m;
    }
    const metadata = (Array.isArray(o.metadata) ? o.metadata : []).map(asRecord2).flatMap((m) => m && typeof m.name === "string" && typeof m.value === "string" ? [{ name: unquotedName(m.name), value: m.value }] : []);
    out.push({
      id: o.id,
      group,
      condition: o.condition,
      disabled: o.disabled === true,
      targets: Array.isArray(o.targets) ? o.targets.filter((t) => typeof t === "string") : [],
      emailByTarget,
      messageByTarget,
      input: str(conf.name),
      timeWindow: str(conf.timeWindow),
      notifyOnResolution: typeof conf.notifyOnResolution === "boolean" ? conf.notifyOnResolution : void 0,
      ...metadata.length ? { metadata } : {},
      raw: o
    });
  }
  return out;
}
function alertIdForInput(group, input) {
  const i = input.indexOf(":");
  return i > 0 ? alertId(group, input.slice(0, i), input.slice(i + 1)) : `${ALERT_PREFIX}?`;
}
var isOwnAlert = (n) => n.id.startsWith(ALERT_PREFIX) && n.condition === NO_DATA && Boolean(n.input) && n.id === alertIdForInput(n.group, n.input);
var DEFAULT_ALERTS = { version: 3, enabled: false, targets: [SYSTEM_TARGET], profiles: [], assigned: {}, alerting: [], health: [], volume: [], tokens: {}, descriptions: {} };
var sourceRowOrGroup = (id, groups) => id.includes("/") && !id.includes("#") || groups && isGroupRowId(id);
var tokenChoice = (settings, tokenRowId2) => settings.tokens[tokenRowId2] ?? "source";
var PROFILE_ID = /^[A-Za-z0-9_-]{1,40}$/;
var RESERVED = /* @__PURE__ */ new Set(["off", "default"]);
var PROFILE_NAME_MAX = 60;
var cleanName = (name) => name.trim().replace(/\s+/g, " ");
function profileOf(settings, sourceRowId) {
  const id = settings.assigned[sourceRowId];
  return id === void 0 ? void 0 : settings.profiles.find((p) => p.id === id);
}
function isAlertSettingsDoc(raw) {
  const o = asRecord2(raw);
  if (!o || typeof o.enabled !== "boolean" || !Array.isArray(o.targets))
    return false;
  return o.version === 3 ? Array.isArray(o.alerting) : (o.version === 1 || o.version === 2) && Array.isArray(o.excluded);
}
var strings = (v) => Array.isArray(v) ? [...new Set(v.filter((x) => typeof x === "string" && x.length > 0))] : [];
function parseEmail(v) {
  const e = asRecord2(v);
  const to = str(e?.to);
  return to ? { to, cc: str(e?.cc), bcc: str(e?.bcc) } : void 0;
}
function parseProfiles(v) {
  const out = [];
  for (const item of Array.isArray(v) ? v : []) {
    const p = asRecord2(item);
    if (typeof p?.id !== "string" || !PROFILE_ID.test(p.id) || RESERVED.has(p.id.toLowerCase()) || out.some((x) => x.id === p.id))
      continue;
    const name = cleanName(typeof p.name === "string" ? p.name : "").slice(0, PROFILE_NAME_MAX) || "Profile";
    const fields = parseFields(p.fields);
    out.push({ id: p.id, name, targets: strings(p.targets), email: parseEmail(p.email), message: parseMessage(p.message), ...fields.length ? { fields } : {} });
  }
  return out;
}
function upgradeMessage(m) {
  for (const cloud of [false, true])
    if (m && sameMessage(m, legacyEmailMessage(cloud)))
      return defaultEmailMessage(cloud);
  return m;
}
function parseAlertSettings(raw) {
  const o = asRecord2(raw) ?? {};
  const current = o.version === 3;
  const profiles = parseProfiles(o.profiles).map((p) => current ? p : { ...p, message: upgradeMessage(p.message) });
  const known2 = new Set(profiles.map((p) => p.id));
  const assigned = Object.fromEntries(Object.entries(asRecord2(o.assigned) ?? {}).filter((e) => typeof e[1] === "string" && known2.has(e[1]) && e[0].length > 0));
  const tokens = current ? Object.fromEntries(
    Object.entries(asRecord2(o.tokens) ?? {}).filter((e) => typeof e[1] === "string" && e[0].includes("#") && e[0].indexOf("#") > 0).map(([k, v]) => [k, v === "off" || v === "default" || v === "source" || known2.has(v) ? v : "source"]).filter(([, v]) => v !== "source")
  ) : {};
  const descriptions = current ? Object.fromEntries(
    Object.entries(asRecord2(o.descriptions) ?? {}).filter((e) => typeof e[1] === "string" && e[0].includes("/")).map(([k, v]) => [k, cleanDescription(v)]).filter(([k, v]) => v !== cleanDescription(defaultDescription(k)))
  ) : {};
  const message3 = parseMessage(o.message);
  const fields = parseFields(o.fields);
  const inUse = [fields, ...profiles.map((p) => p.fields ?? [])].flat().map((f) => f.name);
  const fieldNames = [.../* @__PURE__ */ new Set([...inUse, ...strings(o.fieldNames).filter((n) => isFieldName(n) && !inUse.includes(n)).slice(0, FIELD_NAMES_KEPT)])].sort();
  return {
    version: 3,
    enabled: o.enabled === true,
    targets: Array.isArray(o.targets) ? strings(o.targets) : DEFAULT_ALERTS.targets,
    email: parseEmail(o.email),
    message: current ? message3 : upgradeMessage(message3),
    ...fields.length ? { fields } : {},
    ...fieldNames.length ? { fieldNames } : {},
    linkBase: typeof o.linkBase === "string" && /^https?:\/\/[^\s]+$/.test(o.linkBase) ? o.linkBase.replace(/\/+$/, "") : void 0,
    defaultName: typeof o.defaultName === "string" && cleanName(o.defaultName) && cleanName(o.defaultName).toLowerCase() !== "default" ? cleanName(o.defaultName).slice(0, PROFILE_NAME_MAX) : void 0,
    profiles,
    assigned,
    alerting: current ? strings(o.alerting).filter((id) => sourceRowOrGroup(id, true)).sort() : [],
    health: current ? strings(o.health).filter((id) => sourceRowOrGroup(id, false) && !isCollectorRow(id)).sort() : [],
    volume: current ? strings(o.volume).filter((id) => sourceRowOrGroup(id, true) && !isCollectorRow(id)).sort() : [],
    tokens,
    descriptions,
    updatedAt: typeof o.updatedAt === "number" ? o.updatedAt : void 0,
    updatedBy: typeof o.updatedBy === "string" ? o.updatedBy : void 0
  };
}
var rowOfNotification = (n) => `${n.group}/${inventoryInput(n.input ?? "")}`;
function currentIdOf(n) {
  const inv = inventoryInput(n.input ?? "");
  const i = inv.indexOf(":");
  return i > 0 ? alertId(n.group, criblType(inv.slice(0, i)), inv.slice(i + 1)) : "";
}
function adoptAlertSettings(own, sources) {
  if (own.length === 0)
    return DEFAULT_ALERTS;
  const byRow = /* @__PURE__ */ new Map();
  for (const n of own) {
    const row = rowOfNotification(n);
    const prev = byRow.get(row);
    if (!prev || prev.id !== currentIdOf(prev) && n.id === currentIdOf(n))
      byRow.set(row, n);
  }
  const emailOf = (n) => n.targets.map((t) => n.emailByTarget[t]).find(Boolean);
  const bases = /* @__PURE__ */ new Map();
  const rowById = new Map(sources.map((s) => [s.id, s]));
  const descriptions = {};
  const messageOf = (n, row) => {
    const m = n.targets.map((t) => n.messageByTarget?.[t]).find(Boolean);
    const inv = inventoryInput(n.input ?? "");
    const i = inv.indexOf(":");
    if (!m || i <= 0)
      return m;
    const known2 = row ? rowById.get(row) : void 0;
    const back = unfillLink({ group: n.group, type: inv.slice(0, i), sourceId: inv.slice(i + 1), ...known2?.collector ? { collector: known2.collector } : {} }, (b) => bases.set(b, (bases.get(b) ?? 0) + 1));
    const split = m.body ? extractDescription(back(m.body)) : { body: "" };
    if (row)
      descriptions[row] = split.description ?? "";
    return { ...m.subject ? { subject: back(m.subject) } : {}, ...split.body ? { body: split.body } : {} };
  };
  const sig = (n, row) => JSON.stringify([[...n.targets].sort(), emailOf(n) ?? null, messageOf(n, row) ?? null]);
  const combos = /* @__PURE__ */ new Map();
  for (const [row, n] of byRow) {
    if (!n.targets.some((t) => n.messageByTarget?.[t]))
      descriptions[row] = "";
    const k = sig(n, row);
    const c = combos.get(k);
    if (c)
      c.rows.push(row);
    else
      combos.set(k, { n, rows: [row] });
  }
  const ordered = [...combos.entries()].sort(([ka, a], [kb, b]) => b.rows.length - a.rows.length || ka.localeCompare(kb));
  const [[, common], ...others] = ordered;
  const names = [];
  const assigned = {};
  const profiles = others.map(([k, c]) => {
    const base = targetList(c.n.targets).slice(0, PROFILE_NAME_MAX - 6);
    let name = base;
    for (let i = 2; names.some((x) => x.toLowerCase() === name.toLowerCase()) || RESERVED.has(name.toLowerCase()); i++)
      name = `${base} (${i})`;
    names.push(name);
    const id = `adopted-${hash(k)}`;
    for (const row of c.rows)
      assigned[row] = id;
    return { id, name, targets: [...c.n.targets], email: emailOf(c.n), message: messageOf(c.n) };
  });
  return {
    version: 3,
    enabled: true,
    targets: [...common.n.targets],
    email: emailOf(common.n),
    message: messageOf(common.n),
    profiles,
    assigned,
    // What Cribl holds alerts, and nothing else: rows without one stay off.
    alerting: [...byRow.keys()].sort(),
    // Health and volume alerts leave nothing in Cribl to adopt them from: off.
    health: [],
    volume: [],
    // Which tokens alerted isn't recorded in Cribl: they follow their Source (their searches are kept meanwhile).
    tokens: {},
    // Only descriptions that differ from the default are kept.
    descriptions: Object.fromEntries(Object.entries(descriptions).filter(([k, v]) => v !== cleanDescription(defaultDescription(k)))),
    ...bases.size ? { linkBase: [...bases].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0][0].replace(/\/+$/, "") } : {}
  };
}
function effectiveAlertSettings(saved, all, sources) {
  return saved ? { settings: saved, adopted: false } : { settings: adoptAlertSettings(all.filter(isOwnAlert), sources), adopted: true };
}
var FIELD_FROMS = ["link", "description", "kind", "text"];
var WEBHOOK_FIELDS_MAX = 10;
var FIELD_NAME_MAX = 64;
var FIELD_TEXT_MAX = 200;
var FIELD_NAMES_KEPT = 100;
var FIELD_NAME = /^[A-Za-z][A-Za-z0-9_]*$/;
var isFieldName = (n) => n.length <= FIELD_NAME_MAX && FIELD_NAME.test(n);
var TAKEN_FIELD_NAMES = /* @__PURE__ */ new Set([
  ...["health", "starttime", "endtime", "input", "bytes", "events", "lag", "timewindow", "status", "generated_at", "origin_metadata", "host", "source", "sourcetype", "index"],
  ...["id", "severity", "title", "message", "now", "group", "searchid", "savedqueryid", "searchresultsurl", "notificationid", "resultset", "tenantid"],
  ...["token", "detail", "link", "summary", "descriptionblock", "linkblock"]
]);
function webhookFieldErrors(fields) {
  const seen = /* @__PURE__ */ new Set();
  const each = fields.map((f) => {
    const e = {};
    const name = f.name.trim();
    const lower = name.toLowerCase();
    if (!name)
      e.name = "Give the field a name.";
    else if (name.length > FIELD_NAME_MAX)
      e.name = `Use at most ${FIELD_NAME_MAX} characters.`;
    else if (!FIELD_NAME.test(name))
      e.name = "Use letters, digits and _, starting with a letter.";
    else if (TAKEN_FIELD_NAMES.has(lower) || lower.startsWith("cribl_"))
      e.name = `The alert already has a field named ${name}. Use another name.`;
    else if (seen.has(lower))
      e.name = "Another field has this name.";
    if (name)
      seen.add(lower);
    if (f.from === "text") {
      const text2 = f.text ?? "";
      if (!text2.trim())
        e.text = "Give the field its text.";
      else if (/[\r\n]/.test(text2))
        e.text = "Put the text on one line.";
      else if (text2.trim().length > FIELD_TEXT_MAX)
        e.text = `Use at most ${FIELD_TEXT_MAX} characters.`;
    }
    return e;
  });
  return { each, ...fields.length > WEBHOOK_FIELDS_MAX ? { list: `Use at most ${WEBHOOK_FIELDS_MAX} fields.` } : {} };
}
function parseFields(v) {
  const out = [];
  for (const item of Array.isArray(v) ? v : []) {
    if (out.length === WEBHOOK_FIELDS_MAX)
      break;
    const f = asRecord2(item);
    const from = FIELD_FROMS.find((x) => x === f?.from);
    if (!f || !from || typeof f.name !== "string")
      continue;
    if (from !== "text" && out.some((x) => x.from === from))
      continue;
    const field2 = { name: f.name.trim(), from, ...from === "text" ? { text: typeof f.text === "string" ? f.text.trim() : "" } : {} };
    const e = webhookFieldErrors([...out, field2]).each[out.length];
    if (!e.name && !e.text)
      out.push(field2);
  }
  return out;
}
function alertKindValue(kind) {
  switch (kind) {
    case "silence":
      return "silence";
    case "group":
      return "source_group";
    case "health":
    case "volume":
    case "collector":
      return kind;
    case "part":
      return "pull_source";
    default:
      return "token";
  }
}
function fieldValues(fields, values) {
  const out = [];
  for (const f of fields) {
    const v = f.from === "text" ? (f.text ?? "").trim() : values[f.from];
    if (v)
      out.push([f.name.trim(), v]);
  }
  return out;
}
function unquotedName(name) {
  const n = name.trim();
  return /^'[^']*'$/.test(n) || /^"[^"]*"$/.test(n) ? n.slice(1, -1) : n;
}
var criblTime = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", timeZone: "UTC" });
function alertId(group, type, id) {
  const raw = `${group}--${type}--${id}`;
  let safe = raw.replace(/[^A-Za-z0-9_-]/g, "_");
  if (safe !== raw || safe.length > 80)
    safe = `${safe.slice(0, 70)}-${hash(raw)}`;
  return `${ALERT_PREFIX}${safe}`;
}
function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++)
    h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return (h >>> 0).toString(16).padStart(8, "0");
}
var timeWindowFor = (allowanceMs2) => `${Math.max(1, Math.ceil(allowanceMs2 / 6e4))}m`;
var targetList = (ids) => ids.length ? [...ids].sort().join(", ") : "System Messages (default)";

// src/data/arming.ts
var ARM_STATE_KEY = "state/arming";
var ARM_RUN_KEY = "state/arming-run";
var RUN_STALE_MS = 3 * 6e4;
function fitRunRecord(run, limit = 9e4) {
  const size = (r) => new TextEncoder().encode(JSON.stringify(r)).length;
  if (size(run) <= limit)
    return run;
  const cut = (list, keep) => list.length > keep ? [...list.slice(0, keep), `\u2026 and ${list.length - keep} more`] : list;
  for (let keep = 200; ; keep = Math.floor(keep / 2)) {
    const out = { ...run, done: cut(run.done, keep), failed: cut(run.failed, keep) };
    if (size(out) <= limit || keep === 0)
      return out;
  }
}
var isArmed = (n) => n.timeWindow === ARMED_WINDOW;
var isRecord = (v) => Boolean(v) && typeof v === "object" && !Array.isArray(v);
var strings2 = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
function parseArmState(raw) {
  const out = {};
  if (!isRecord(raw))
    return out;
  for (const [id, v] of Object.entries(raw)) {
    if (!isRecord(v) || typeof v.armedAt !== "number")
      continue;
    out[id] = typeof v.restWindow === "string" && /^\d+m$/.test(v.restWindow) ? { armedAt: v.armedAt, restWindow: v.restWindow } : { armedAt: v.armedAt };
  }
  return out;
}
function parseArmRun(raw) {
  if (!isRecord(raw) || typeof raw.at !== "number")
    return void 0;
  return {
    at: raw.at,
    own: typeof raw.own === "number" ? raw.own : 0,
    armed: typeof raw.armed === "number" ? raw.armed : 0,
    done: strings2(raw.done),
    failed: strings2(raw.failed),
    skipped: typeof raw.skipped === "string" ? raw.skipped : void 0
  };
}
var pastAllowance = (s) => s.status === "overdue" || s.status === "nodata";
function planArming(sources, notifications, state, now) {
  const byRow = new Map(sources.map((s) => [s.id, s]));
  const actions = [];
  const next = {};
  for (const n of notifications) {
    if (!isOwnAlert(n) || n.condition !== NO_DATA || n.disabled || !n.input)
      continue;
    const s = byRow.get(`${n.group}/${inventoryInput(n.input)}`);
    const prior = state[n.id];
    if (!s || s.disabled || s.status === "unknown") {
      if (prior)
        next[n.id] = prior;
      continue;
    }
    const resting = timeWindowFor(s.allowanceMs);
    if (resting === ARMED_WINDOW)
      continue;
    if (pastAllowance(s)) {
      if (!isArmed(n)) {
        actions.push({ kind: "arm", notification: n, timeWindow: ARMED_WINDOW, reason: `${n.input} in ${n.group} is past its ${resting} allowance` });
        next[n.id] = { armedAt: now, restWindow: n.timeWindow && n.timeWindow !== ARMED_WINDOW ? n.timeWindow : resting };
      } else {
        next[n.id] = prior ?? { armedAt: now, restWindow: resting };
      }
      continue;
    }
    if (!isArmed(n))
      continue;
    actions.push({ kind: "disarm", notification: n, timeWindow: prior?.restWindow ?? resting, reason: `${n.input} in ${n.group} is sending again` });
  }
  return { actions, next };
}
var SNOOZE_PAUSED_KEY = "state/snooze-paused";
function parseSnoozePaused(raw) {
  if (!isRecord(raw))
    return {};
  return Object.fromEntries(Object.entries(raw).filter((e) => typeof e[1] === "number" && Number.isFinite(e[1])));
}
function planSnooze(notifications, snoozed, paused, now) {
  const pause = [];
  const resume = [];
  for (const n of notifications) {
    if (!isOwnAlert(n) || n.condition !== NO_DATA || !n.input)
      continue;
    const until = snoozed[`${n.group}/${inventoryInput(n.input)}`];
    const snoozedNow = until !== void 0 && until > now;
    if (snoozedNow && !n.disabled)
      pause.push(n);
    else if (!snoozedNow && n.disabled && paused[n.id] !== void 0)
      resume.push(n);
  }
  return { pause, resume };
}
function disabledBody(raw, disabled, timeWindow) {
  const conf = isRecord(raw.conf) ? raw.conf : {};
  return timeWindow ? { ...raw, disabled, conf: { ...conf, timeWindow } } : { ...raw, disabled };
}
function windowBody(raw, timeWindow) {
  const conf = isRecord(raw.conf) ? raw.conf : {};
  return { ...raw, conf: { ...conf, timeWindow } };
}

// src/data/format.ts
var intFmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 0 });
var compactFmt = new Intl.NumberFormat(void 0, { notation: "compact", maximumFractionDigits: 1 });
var dec2Fmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 2 });
var plural = (n, word, many = `${word}s`) => n === 1 ? word : many;
function formatInt(n) {
  return intFmt.format(Math.round(n));
}
var timeFmt = new Intl.DateTimeFormat(void 0, { hour: "numeric", minute: "2-digit" });
var dateTimeFmt = new Intl.DateTimeFormat(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
var dateFmt = new Intl.DateTimeFormat(void 0, { month: "short", day: "numeric", year: "numeric" });
var clockFmt = new Intl.DateTimeFormat(void 0, { hour: "numeric", minute: "2-digit", second: "2-digit" });
function formatDuration(ms) {
  const min = Math.floor(Math.max(0, ms) / 6e4);
  if (min < 1)
    return "less than 1 min";
  if (min < 60)
    return `${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24)
    return min % 60 ? `${h} h ${min % 60} min` : `${h} h`;
  const d = Math.floor(h / 24);
  return h % 24 ? `${d} d ${h % 24} h` : `${d} d`;
}
var pctFmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 0, signDisplay: "exceptZero" });
var pctFineFmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 1, signDisplay: "exceptZero" });

// src/data/pieces.ts
function splitPieces(text2, stamp, limit) {
  const out = [];
  let at = 0;
  while (at < text2.length) {
    let take = Math.min(text2.length - at, limit);
    for (; ; ) {
      const piece = { s: stamp, i: out.length, d: text2.slice(at, at + take) };
      const over = JSON.stringify(piece).length - limit;
      if (over <= 0) {
        out.push(piece);
        break;
      }
      take = Math.max(1, take - over - 16);
    }
    at += take;
  }
  if (out.length === 0)
    out.push({ s: stamp, i: 0, d: "" });
  return out;
}

// src/data/settingsStore.ts
var SETTINGS_KEY = "settings/thresholds";
function unwrapKvValue(text2) {
  let v = text2;
  for (let i = 0; i < 3 && typeof v === "string"; i++) {
    try {
      v = JSON.parse(v);
    } catch {
      return void 0;
    }
  }
  if (v && typeof v === "object" && !("defaults" in v)) {
    const o = v;
    if ("value" in o)
      return unwrapKvValue(typeof o.value === "string" ? o.value : JSON.stringify(o.value));
    if (Array.isArray(o.items) && o.items.length === 1)
      return unwrapKvValue(JSON.stringify(o.items[0]));
  }
  return v;
}
var KEY_LIST_TTL_MS = 5e3;
var keyLists = /* @__PURE__ */ new WeakMap();
async function listKeys(t, signal) {
  try {
    const res = await t("/kvstore/keys", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ prefix: "" }),
      signal
    });
    if (!res.ok)
      return void 0;
    const body = await res.json();
    const list = Array.isArray(body) ? body : Array.isArray(body?.items) ? body.items : void 0;
    if (!list)
      return void 0;
    const keys = /* @__PURE__ */ new Set();
    for (const k of list) {
      const name = typeof k === "string" ? k : k?.key;
      if (typeof name === "string")
        keys.add(name);
    }
    return keys;
  } catch {
    return void 0;
  }
}
async function keyExists(t, key, signal) {
  const now = Date.now();
  let entry = keyLists.get(t);
  if (!entry || now - entry.at >= KEY_LIST_TTL_MS || now < entry.at) {
    entry = { at: now, keys: listKeys(t, signal) };
    keyLists.set(t, entry);
  }
  const keys = await entry.keys;
  if (keys === void 0) {
    if (keyLists.get(t) === entry)
      keyLists.delete(t);
    return void 0;
  }
  return keys.has(key);
}
function noteKey(t, key) {
  void keyLists.get(t)?.keys.then((keys) => keys?.add(key));
}
async function kvRead(t, key, signal) {
  if (key.startsWith("cache/") && await keyExists(t, key, signal) === false)
    return void 0;
  const res = await t(`/kvstore/${key}`, { signal });
  if (res.status === 404)
    return void 0;
  if (!res.ok)
    throw new ApiError(res.status, "/kvstore", errorDetail(await res.text().catch(() => "")));
  const text2 = await res.text();
  if (!text2.trim())
    return void 0;
  const value = unwrapKvValue(text2);
  return value === void 0 ? UNREADABLE_VALUE : value;
}
var UNREADABLE_VALUE = Object.freeze({});
var UnreadableSettingsError = class extends Error {
  constructor(what = "allowances") {
    super(`The saved ${what} are not in a form this app can read`);
  }
};
async function kvWrite(t, key, value) {
  const res = await t(`/kvstore/${key}`, {
    method: "PUT",
    headers: { "content-type": "text/plain" },
    body: JSON.stringify(value)
  });
  if (!res.ok)
    throw new ApiError(res.status, "/kvstore", errorDetail(await res.text().catch(() => "")));
  noteKey(t, key);
}
function isSettingsDoc(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    return false;
  const o = raw;
  return o.version === 1 || o.defaults !== null && typeof o.defaults === "object";
}
async function loadSettings(t, signal) {
  const raw = await kvReadLarge(t, SETTINGS_KEY, signal);
  if (raw === void 0)
    return DEFAULT_SETTINGS;
  if (!isSettingsDoc(raw))
    throw new UnreadableSettingsError();
  return parseSettings(raw);
}
var PIECE_LIMIT = 9e4;
var PIECE_FLOOR = 8e3;
var MAX_PIECES = 40;
var asciiJson = (v) => JSON.stringify(v).replace(/[\u007f-\uffff]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, "0")}`);
var isObj = (v) => Boolean(v) && typeof v === "object" && !Array.isArray(v);
async function writeShards(t, prefix, value) {
  const text2 = asciiJson(value);
  const stamp = `${fingerprint(text2)}${text2.length.toString(36)}`;
  let limit = PIECE_LIMIT;
  for (; ; ) {
    const pieces = splitPieces(text2, stamp, limit).map((p, _i, all) => ({ ...p, n: all.length }));
    if (pieces.length > MAX_PIECES)
      throw new Error(`${prefix} is too large to store (${pieces.length} pieces)`);
    try {
      for (const p of [...pieces.slice(1), pieces[0]])
        await kvWrite(t, `${prefix}/${p.i}`, p);
      return stamp;
    } catch (err) {
      const status = err?.status;
      if (status !== 413 || limit <= PIECE_FLOOR)
        throw err;
      limit = Math.max(PIECE_FLOOR, Math.floor(limit / 2));
    }
  }
}
async function readShards(t, prefix, signal) {
  try {
    const first = await kvRead(t, `${prefix}/0`, signal);
    if (first === void 0)
      return { state: "absent" };
    if (!isObj(first) || typeof first.s !== "string" || first.i !== 0 || typeof first.d !== "string" || typeof first.n !== "number" || first.n < 1 || first.n > MAX_PIECES)
      return { state: "bad" };
    const rest = await Promise.all(Array.from({ length: first.n - 1 }, (_, k) => kvRead(t, `${prefix}/${k + 1}`, signal)));
    let text2 = first.d;
    for (const [k, p] of rest.entries()) {
      if (!isObj(p) || p.s !== first.s || p.i !== k + 1 || typeof p.d !== "string")
        return { state: "bad" };
      text2 += p.d;
    }
    if (`${fingerprint(text2)}${text2.length.toString(36)}` !== first.s)
      return { state: "bad" };
    return { state: "ok", value: JSON.parse(text2), stamp: first.s };
  } catch (err) {
    if (signal?.aborted)
      throw err;
    return err instanceof SyntaxError ? { state: "bad" } : { state: "failed", reason: err instanceof Error ? err.message : String(err) };
  }
}
var SINGLE_LIMIT = 95e3;
var fitsOneValue = (value) => new TextEncoder().encode(JSON.stringify(value)).length <= SINGLE_LIMIT;
var POINTER = "__pieces";
var slotOf = (key, slot) => `${key}.p${slot}`;
async function kvWriteLarge(t, key, value) {
  if (fitsOneValue(value))
    return kvWrite(t, key, value);
  const current = await kvRead(t, key);
  const slot = isObj(current) && current.slot === 1 ? 2 : 1;
  const stamp = await writeShards(t, slotOf(key, slot), value);
  await kvWrite(t, key, { [POINTER]: stamp, slot });
}
async function kvReadLarge(t, key, signal) {
  for (let attempt = 0; ; attempt++) {
    const raw = await kvRead(t, key, signal);
    if (!isObj(raw) || typeof raw[POINTER] !== "string")
      return raw;
    const r = await readShards(t, slotOf(key, raw.slot === 2 ? 2 : 1), signal);
    if (r.state === "failed")
      throw new Error(r.reason);
    if (r.state === "ok" && r.stamp === raw[POINTER])
      return r.value;
    if (attempt >= 1)
      return UNREADABLE_VALUE;
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
}

// src/data/tokenAlerts.ts
var TOKEN_SEARCH_PREFIX = "dsh_tokens_";
var TOKEN_ALERTS_KEY = "state/token-alerts";
var SAVED = "/m/default_search/search/saved";
var FORWARD = "/search/notifications";
function shortHash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++)
    h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return (h >>> 0).toString(16).padStart(8, "0").slice(0, 6);
}
function tokenSearchId(deliveryKey) {
  if (deliveryKey === "default")
    return `${TOKEN_SEARCH_PREFIX}default`;
  const safe = deliveryKey.replace(/[^A-Za-z0-9_]/g, "_").slice(0, 40);
  return `${TOKEN_SEARCH_PREFIX}p_${safe}${safe === deliveryKey ? "" : `_${shortHash(deliveryKey)}`}`;
}
var tokenNotifyId = (searchId) => `${searchId}_notify`;
function chosenTokens(model, settings, implicit = true) {
  if (!settings.enabled)
    return [];
  const bySource = new Map(model.sources.map((s) => [s.id, s]));
  const byToken = new Map((model.tokens ?? []).map((t) => [t.id, t]));
  const alertingRows = new Set(settings.alerting);
  const ids = new Set(Object.keys(settings.tokens));
  if (implicit)
    for (const t of model.tokens ?? [])
      ids.add(t.id);
  const out = [];
  for (const rowId of ids) {
    const choice = tokenChoice(settings, rowId);
    if (choice === "off")
      continue;
    const hash2 = rowId.indexOf("#");
    const source = hash2 > 0 ? bySource.get(rowId.slice(0, hash2)) : void 0;
    if (!source || source.disabled || source.status === "untracked" && source.snoozedUntil === void 0)
      continue;
    if (choice === "source" && !alertingRows.has(source.id))
      continue;
    const token = byToken.get(rowId);
    if (token && (token.disabled || token.status === "untracked" && token.snoozedUntil === void 0))
      continue;
    const profile = choice === "default" ? void 0 : choice === "source" ? profileOf(settings, source.id) : settings.profiles.find((p) => p.id === choice);
    const deliveryKey = profile ? profile.id : "default";
    out.push({ rowId, source, deliveryKey, searchId: tokenSearchId(deliveryKey), ...token ? { token } : {} });
  }
  return out.sort((x, y) => x.rowId.localeCompare(y.rowId));
}
function chosenPullSources(model, settings) {
  if (!settings.enabled)
    return [];
  const on = new Set(settings.alerting);
  return model.sources.filter((s) => s.pull && on.has(s.id) && !s.disabled && !(s.status === "untracked" && s.snoozedUntil === void 0)).map((source) => {
    const deliveryKey = profileOf(settings, source.id)?.id ?? "default";
    return { source, deliveryKey, searchId: tokenSearchId(deliveryKey) };
  });
}
function chosenCollectors(model, settings) {
  if (!settings.enabled)
    return [];
  const on = new Set(settings.alerting);
  return (model.collectors ?? []).filter((c) => c.collector?.scheduled && on.has(c.id) && !c.disabled && !(c.status === "untracked" && c.snoozedUntil === void 0)).map((row) => {
    const deliveryKey = profileOf(settings, row.id)?.id ?? "default";
    return { row, deliveryKey, searchId: tokenSearchId(deliveryKey) };
  }).sort((a, b) => a.row.id.localeCompare(b.row.id));
}
function chosenMonitoring(model, settings) {
  if (!settings.enabled)
    return [];
  const live = (s) => !s.disabled && !(s.status === "untracked" && s.snoozedUntil === void 0);
  const out = [];
  const add = (kind, row) => {
    const deliveryKey = profileOf(settings, row.id)?.id ?? "default";
    out.push({ kind, row, deliveryKey, searchId: tokenSearchId(deliveryKey) });
  };
  const health = new Set(settings.health);
  const volume = new Set(settings.volume);
  const silence = new Set(settings.alerting);
  const groupRows = new Map(model.sources.filter((s) => s.sourceGroup).map((s) => [s.id, s]));
  for (const s of [...model.sources, ...model.members ?? []]) {
    if (!live(s) || s.collector)
      continue;
    const group = s.memberOf ? groupRows.get(s.memberOf) : void 0;
    const row = group && (group.status === "untracked" || group.snoozedUntil !== void 0) ? { ...s, snoozedUntil: group.snoozedUntil ?? Number.MAX_SAFE_INTEGER } : s;
    if (health.has(s.id) && !s.sourceGroup)
      add("health", row);
    if (volume.has(s.id) && !s.memberOf && !s.pull)
      add("volume", row);
    if (silence.has(s.id) && s.sourceGroup)
      add("group", row);
  }
  return out.sort((a, b) => a.row.id.localeCompare(b.row.id) || a.kind.localeCompare(b.kind));
}
var alertingTokens = (model, settings) => chosenTokens(model, settings).filter((c) => c.token !== void 0);
var rec = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
var str2 = (v) => typeof v === "string" ? v : void 0;
function parseTokenSearches(payload) {
  if (!Array.isArray(rec(payload)?.items) && !Array.isArray(payload))
    throw new Error("Cribl Search's saved searches weren't in the form this app reads");
  const items = Array.isArray(payload) ? payload : rec(payload).items;
  const out = [];
  for (const it of items) {
    const o = rec(it);
    const id = str2(o?.id);
    if (!o || !id || !id.startsWith(TOKEN_SEARCH_PREFIX))
      continue;
    const schedule = rec(o.schedule);
    const n = (Array.isArray(rec(schedule?.notifications)?.items) ? rec(schedule.notifications).items : []).map(rec).find((x) => x && str2(x.id) === tokenNotifyId(id));
    const emailByTarget = {};
    let subject;
    let body;
    for (const c of Array.isArray(n?.targetConfigs) ? n.targetConfigs : []) {
      const conf = rec(rec(c)?.conf);
      const r = rec(conf?.emailRecipient);
      const to = str2(r?.to);
      const tid = str2(rec(c)?.id);
      if (tid && to)
        emailByTarget[tid] = { to, ...str2(r?.cc) ? { cc: str2(r?.cc) } : {}, ...str2(r?.bcc) ? { bcc: str2(r?.bcc) } : {} };
      subject ??= str2(conf?.subject);
      body ??= str2(conf?.body);
    }
    out.push({
      id,
      name: str2(o.name) ?? "",
      query: str2(o.query) ?? "",
      ...schedule?.enabled === true ? { scheduled: true } : {},
      ...n ? {
        notification: {
          id: str2(n.id),
          targets: Array.isArray(n.targets) ? n.targets.filter((x) => typeof x === "string") : [],
          emailByTarget,
          message: str2(rec(n.conf)?.message),
          subject,
          body
        }
      } : {},
      raw: o
    });
  }
  return out;
}
async function loadTokenSearches(t, signal) {
  return parseTokenSearches(await apiGet(t, SAVED, signal));
}
var TOKEN_ALERT_STATUSES = ["Overdue", "Back", "Failed", "Unhealthy", "Volume"];
var TOKEN_ALERT_KINDS = ["collector", "part", "health", "volume", "group"];
var FORWARD_ROWS = 40;
var FORWARD_MAX_BYTES = 9e4;
function utf8Length(text2) {
  let n = 0;
  for (let i = 0; i < text2.length; i++) {
    const c = text2.charCodeAt(i);
    if (c < 128)
      n += 1;
    else if (c < 2048)
      n += 2;
    else if (c >= 55296 && c <= 56319 && i + 1 < text2.length && (text2.charCodeAt(i + 1) & 64512) === 56320) {
      n += 4;
      i++;
    } else
      n += 3;
  }
  return n;
}
var forwardBytes = (body) => utf8Length(JSON.stringify(body));
function chunkRows(rows, body, most = Infinity) {
  const chunks = [];
  let cur = [];
  let i = 0;
  for (; i < rows.length && chunks.length < most; i++) {
    const next = [...cur, rows[i]];
    if (cur.length > 0 && (next.length > FORWARD_ROWS || forwardBytes(body(next)) > FORWARD_MAX_BYTES)) {
      chunks.push(cur);
      cur = [];
      i--;
      continue;
    }
    cur = next;
  }
  if (cur.length && chunks.length < most) {
    chunks.push(cur);
    cur = [];
  }
  return { chunks, rest: [...cur, ...rows.slice(i)] };
}
var MAX_FORWARDS_PER_RUN = 8;
var ALONE = /* @__PURE__ */ new Set(["collector", "part"]);
var QUEUE_LIMIT_MS = 60 * 6e4;
var SEND_LIMIT_MS = 55e3;
async function readQueue(t, share) {
  if (share?.queue)
    return share.queue;
  const raw = await kvReadLarge(t, TOKEN_ALERTS_KEY);
  if (raw === UNREADABLE_VALUE)
    return void 0;
  let q = parseTokenAlertState(raw);
  if (Object.keys(q.pending).length > 0 || q.sending !== void 0) {
    const sentBefore = parseSentKeys(await kvRead(t, TOKEN_ALERTS_SENT_KEY));
    if (sentBefore.size) {
      const carried = /* @__PURE__ */ new Set();
      const unsent = (rows) => rows.filter((r) => {
        const k = rowKey(r);
        if (!sentBefore.has(k))
          return true;
        carried.add(k);
        return false;
      });
      const dropSent = (m) => Object.fromEntries(Object.entries(m).map(([k, v]) => [k, unsent(v)]).filter(([, v]) => v.length > 0));
      const sendingRows = q.sending ? dropSent(q.sending.rows) : {};
      q = { seen: q.seen, pending: dropSent(q.pending), ...q.sending && Object.keys(sendingRows).length ? { sending: { at: q.sending.at, rows: sendingRows } } : {} };
      if (share)
        share.carried = carried;
    }
  }
  if (share)
    share.queue = q;
  return q;
}
function copyQueue(q) {
  return { ...q, pending: Object.fromEntries(Object.entries(q.pending).map(([k, v]) => [k, [...v]])) };
}
function queueText(q) {
  const sorted = (o, f) => Object.keys(o).sort().map((k) => [k, f(o[k])]);
  const rows = (rs) => rs.map((r) => JSON.stringify(r, Object.keys(r).sort())).sort();
  return JSON.stringify([sorted(q.seen, (v) => v.overdue), sorted(q.pending, rows), q.sending ? [q.sending.at, sorted(q.sending.rows, rows)] : null]);
}
var TOKEN_ALERTS_SENT_KEY = "state/token-alerts-sent";
var KEY_CHARS = 12;
var MAX_SENT_KEYS = 7e3;
var rowKey = (r) => {
  const s = `${r.rowId}|${r.status}|${r.at}|${r.job ?? ""}`;
  return `${fingerprint(s)}${fingerprint(`~${s}`)}`.slice(0, KEY_CHARS);
};
var parseSentKeys = (raw) => {
  const keys = rec(raw)?.keys;
  const out = /* @__PURE__ */ new Set();
  if (typeof keys === "string")
    for (let i = 0; i + KEY_CHARS <= keys.length; i += KEY_CHARS)
      out.add(keys.slice(i, i + KEY_CHARS));
  return out;
};
function parseRows(v) {
  return (Array.isArray(v) ? v : []).map(rec).filter((r) => Boolean(r && typeof r.rowId === "string" && TOKEN_ALERT_STATUSES.includes(r.status))).map((r) => ({
    rowId: String(r.rowId),
    status: r.status,
    ...TOKEN_ALERT_KINDS.includes(r.kind) ? { kind: r.kind } : {},
    ...typeof r.description === "string" && r.description ? { description: r.description } : {},
    ...typeof r.job === "string" && r.job ? { job: r.job } : {},
    token: String(r.token ?? ""),
    source: String(r.source ?? ""),
    group: String(r.group ?? ""),
    detail: String(r.detail ?? ""),
    link: String(r.link ?? ""),
    at: Number(r.at) || 0
  }));
}
function parseTokenAlertState(raw) {
  const o = rec(raw);
  const seen = {};
  for (const [k, v] of Object.entries(rec(o?.seen) ?? {}))
    if (typeof rec(v)?.overdue === "boolean")
      seen[k] = { overdue: rec(v).overdue };
  const pending = {};
  for (const [k, v] of Object.entries(rec(o?.pending) ?? {})) {
    const rows = parseRows(v);
    if (k.startsWith(TOKEN_SEARCH_PREFIX) && rows.length)
      pending[k] = rows;
  }
  const sendingRaw = rec(o?.sending);
  const sendingRows = {};
  for (const [k, v] of Object.entries(rec(sendingRaw?.rows) ?? {})) {
    const rows = parseRows(v);
    if (k.startsWith(TOKEN_SEARCH_PREFIX) && rows.length)
      sendingRows[k] = rows;
  }
  const sending = typeof sendingRaw?.at === "number" && Object.keys(sendingRows).length ? { at: sendingRaw.at, rows: sendingRows } : void 0;
  return { seen, pending, ...sending ? { sending } : {} };
}
function alertSummary(rows) {
  const cap = (v) => v.length > 200 ? `${v.slice(0, 199)}\u2026` : v;
  const parts = rows.map(
    (r) => cap(
      r.kind === "collector" ? `collector ${r.source.replace(/^collection:/, "")} in ${r.group}: ${r.detail}` : r.kind === "group" ? `Source group ${r.source} (${r.group}): ${r.detail}` : r.kind ? `${r.source} in ${r.group}: ${r.detail}` : `${r.token} of ${r.source} in ${r.group}: ${r.detail}`
    )
  );
  let out = "";
  for (let i = 0; i < parts.length; i++) {
    const next = out ? `${out}; ${parts[i]}` : parts[i];
    if (out && next.length > 400)
      return `${out}; and ${parts.length - i} more`;
    out = next;
  }
  return out;
}
function sourceLink(linkBase, s) {
  if (!linkBase)
    return "";
  let host = "";
  try {
    host = new URL(linkBase).hostname;
  } catch {
    return "";
  }
  const cloud = /\.cribl\.cloud$/i.test(host);
  const g = encodeURIComponent(s.group);
  return cloud && NO_STREAM_PAGE.has(s.type) ? `${linkBase}/stream/m/${g}/inputs` : `${linkBase}/stream/m/${g}/inputs/${encodeURIComponent(criblType(s.type))}/${encodeURIComponent(s.sourceId)}`;
}
function nextTokenAlerts(state, alerting, settings, now, readable) {
  const seen = {};
  const pending = Object.fromEntries(Object.entries(state.pending).map(([k, v]) => [k, [...v]]));
  const present = new Set(alerting.map((a) => a.token.id));
  const stillOn = (id) => {
    const choice = tokenChoice(settings, id);
    return choice !== "off" && (choice !== "source" || settings.alerting.includes(id.slice(0, Math.max(0, id.indexOf("#")))));
  };
  for (const [id, v] of Object.entries(state.seen))
    if (!present.has(id) && (!settings || stillOn(id)))
      seen[id] = v;
  for (const a of alerting) {
    const t = a.token;
    const prev = state.seen[t.id];
    if (!readable || t.status === "unknown" || t.snoozedUntil !== void 0 || a.source.snoozedUntil !== void 0) {
      if (prev)
        seen[t.id] = prev;
      continue;
    }
    const overdue = t.status === "overdue" || t.status === "nodata";
    seen[t.id] = { overdue };
    if (prev ? prev.overdue === overdue : !overdue)
      continue;
    const queued = pending[a.searchId] ??= [];
    const status = overdue ? "Overdue" : "Back";
    if (queued.some((r) => r.rowId === t.id && r.status === status))
      continue;
    const opposite = queued.findIndex((r) => r.rowId === t.id && r.status !== status);
    if (opposite >= 0) {
      queued.splice(opposite, 1);
      continue;
    }
    queued.push({
      rowId: t.id,
      status: overdue ? "Overdue" : "Back",
      token: t.token.label,
      source: criblInput(a.source.type, a.source.sourceId),
      group: a.source.group,
      detail: overdue ? `Overdue, no events for longer than its ${formatDuration(t.allowanceMs)} allowance` : "Back, sending again",
      link: sourceLink(settings?.linkBase, a.source),
      at: now
    });
  }
  for (const [k, v] of Object.entries(pending))
    if (v.length === 0)
      delete pending[k];
  return { seen, pending, ...state.sending ? { sending: state.sending } : {} };
}
function fieldsBySearch(settings) {
  const out = /* @__PURE__ */ new Map();
  if (settings?.fields?.length)
    out.set(tokenSearchId("default"), settings.fields);
  for (const p of settings?.profiles ?? [])
    if (p.fields?.length)
      out.set(tokenSearchId(p.id), p.fields);
  return out;
}
var rowDescription = (settings) => (r) => {
  if (r.description !== void 0)
    return r.description;
  const hash2 = r.rowId.indexOf("#");
  const base = hash2 >= 0 ? r.rowId.slice(0, hash2) : r.rowId;
  const sourceRow = r.kind && r.kind !== "collector" && base.includes("~") ? base.slice(0, base.lastIndexOf("~")) : base;
  if (!settings || !sourceRow.includes("/"))
    return void 0;
  return descriptionFor(settings, sourceRow)?.split(SOURCE_LINK).join(r.link || `${r.group} \u203A ${r.source}`);
};
function addFields(into, extra) {
  for (const [k, v] of extra)
    if (!Object.prototype.hasOwnProperty.call(into, k))
      into[k] = v;
  return into;
}
function forwardBody(searchId, rows, now, batch = 0, fields) {
  const summary = alertSummary(rows);
  const message3 = `Cribl alert: ${summary}`.slice(0, 1e3);
  const description = rows.length === 1 ? rows[0].description : void 0;
  const notificationId = tokenNotifyId(searchId);
  const ref = `${searchId}_${now}${batch ? `_${batch}` : ""}`;
  const text2 = fields ? fieldValues(fields.fields.filter((f) => f.from === "text"), {}) : [];
  const perRow = fields?.fields.filter((f) => f.from !== "text") ?? [];
  const rowFields = (r) => perRow.length ? fieldValues(perRow, { link: r.link || void 0, description: fields.descriptionOf(r), kind: alertKindValue(r.kind) }) : [];
  const body = {
    id: `SEARCH_NOTIFICATION_${notificationId}_${now}${batch ? `_${batch}` : ""}`,
    severity: "warn",
    title: "Cribl alert",
    _raw: message3,
    message: message3,
    _time: now,
    now,
    group: "default_search",
    searchId: ref,
    savedQueryId: searchId,
    searchResultsUrl: "",
    notificationId,
    __attachments: [],
    resultSet: rows.map(
      (r) => addFields(
        {
          status: r.status,
          token: r.token,
          source: r.source,
          group: r.group,
          detail: r.detail,
          link: r.link,
          summary,
          descriptionBlock: description ? `

Description: ${description}` : "",
          linkBlock: description ? "" : r.link ? `

Open in Cribl: ${r.link}` : ""
        },
        rowFields(r)
      )
    ),
    origin_metadata: { itemType: "link", id: ref, type: "search", product: "search", groupId: "" }
  };
  return addFields(body, text2);
}
async function runTokenAlerts(t, model, settings, now, readable, share) {
  const done = [];
  const failed = [];
  share ??= {};
  let read;
  try {
    read = await readQueue(t, share);
  } catch (err) {
    return { done, failed: [`alerts: the record of alerts already sent couldn't be read (${err instanceof Error ? err.message : String(err)}), so nothing was sent this run`] };
  }
  if (!read)
    return { done, failed: ["alerts: the stored alert queue couldn't be read, so nothing was sent this run"] };
  const carried = share.carried ?? /* @__PURE__ */ new Set();
  const stored = read;
  const webhookFields = fieldsBySearch(settings);
  const descriptionOf = rowDescription(settings);
  const chosen = settings ? settings.enabled && (Object.keys(settings.tokens).length > 0 || settings.alerting.length > 0) : false;
  if (!chosen && Object.keys(stored.pending).length === 0 && Object.keys(stored.seen).length === 0 && !stored.sending)
    return { done, failed };
  const before = { seen: stored.seen, pending: { ...stored.pending } };
  if (stored.sending && now - stored.sending.at >= SEND_LIMIT_MS) {
    for (const [id, rows] of Object.entries(stored.sending.rows))
      before.pending[id] = [...rows, ...before.pending[id] ?? []];
  } else if (stored.sending)
    before.sending = stored.sending;
  if (share.dropVolume) {
    for (const [id, rows] of Object.entries(before.pending)) {
      const kept = rows.filter((r) => !(r.kind === "volume" && r.status === "Volume"));
      if (kept.length)
        before.pending[id] = kept;
      else
        delete before.pending[id];
    }
  }
  const alerting = model && settings ? alertingTokens(model, settings) : [];
  const next = nextTokenAlerts(before, alerting, settings, now, readable && model !== void 0 && !model.tokensFailed);
  if (Object.keys(next.pending).length === 0) {
    if (queueText(next) !== queueText(read))
      await kvWriteLarge(t, TOKEN_ALERTS_KEY, next).catch((err) => failed.push(`token alerts: couldn't record them (${err instanceof Error ? err.message : String(err)})`));
    return { done, failed };
  }
  let existing = /* @__PURE__ */ new Set();
  try {
    existing = new Set(share?.searches ?? (await loadTokenSearches(t)).filter((e) => e.notification).map((e) => e.id));
  } catch (err) {
    failed.push(`alerts: Cribl Search's saved searches couldn't be read (${err instanceof Error ? err.message : String(err)}), so nothing was sent`);
  }
  const sending = [];
  const after = { seen: next.seen, pending: {} };
  for (const [id, rows] of Object.entries(next.pending)) {
    if (existing.has(id))
      sending.push([id, rows]);
    else {
      const kept = rows.filter((r) => now - r.at < QUEUE_LIMIT_MS);
      if (kept.length)
        after.pending[id] = kept;
    }
  }
  if (sending.length === 0) {
    if (queueText(after) !== queueText(read))
      await kvWriteLarge(t, TOKEN_ALERTS_KEY, after).catch((err) => failed.push(`token alerts: couldn't record them (${err instanceof Error ? err.message : String(err)})`));
    return { done, failed };
  }
  after.sending = { at: now, rows: Object.fromEntries(sending) };
  const writeFirst = fitsOneValue(after);
  if (!writeFirst && share?.callsLeft && share.callsLeft() < 4) {
    failed.push(`alerts: ${sending.reduce((n, [, rows]) => n + rows.length, 0)} waiting, with no Leader calls left this run to send them; a later run sends them`);
    return { done, failed };
  }
  const sentNow = [];
  const recordSent = () => kvWrite(t, TOKEN_ALERTS_SENT_KEY, { at: now, keys: [...carried, ...sentNow].join("") });
  try {
    if (writeFirst)
      await kvWriteLarge(t, TOKEN_ALERTS_KEY, after);
    else
      await recordSent();
  } catch (err) {
    failed.push(`token alerts: couldn't record them (${err instanceof Error ? err.message : String(err)}), so nothing was sent`);
    return { done, failed };
  }
  let forwards = 0;
  let outOfCalls = 0;
  const writeCost = writeFirst ? 1 : 3 + Math.ceil(JSON.stringify(after).length / 9e4);
  const skipFull = !writeFirst && share?.callsLeft !== void 0 && share.callsLeft() - writeCost - 1 < 1;
  const storedKeys = skipFull ? new Set([...Object.values(stored.pending), ...Object.values(stored.sending?.rows ?? {})].flat().map(rowKey)) : void 0;
  const room = () => share?.callsLeft ? share.callsLeft() - (skipFull ? 1 : writeCost) - 1 : Infinity;
  for (const [id, rows] of sending) {
    const sendable = storedKeys ? rows.filter((r) => storedKeys.has(rowKey(r))) : rows;
    if (sendable.length < rows.length)
      (after.pending[id] ??= []).push(...rows.filter((r) => !sendable.includes(r)));
    const together = sendable.filter((r) => !ALONE.has(r.kind));
    const fields = webhookFields.get(id);
    const withFields = fields ? { fields, descriptionOf } : void 0;
    const { chunks, rest } = chunkRows(together, (rows2) => forwardBody(id, rows2, now, 0, withFields), Math.max(0, MAX_FORWARDS_PER_RUN - forwards));
    const later = rest.length ? rest : void 0;
    const batches = [...chunks, ...later ? [later] : [], ...sendable.filter((r) => ALONE.has(r.kind)).map((r) => [r])];
    for (const [n, batch] of batches.entries()) {
      const noCalls = room() < 1 || !writeFirst && carried.size + sentNow.length + batch.length > MAX_SENT_KEYS;
      if (batch === later || forwards >= MAX_FORWARDS_PER_RUN || noCalls) {
        if (noCalls)
          outOfCalls += batch.length;
        if (after.sending) {
          const left = (after.sending.rows[id] ?? []).filter((r) => !batch.includes(r));
          if (left.length)
            after.sending.rows[id] = left;
          else
            delete after.sending.rows[id];
        }
        (after.pending[id] ??= []).push(...batch);
        continue;
      }
      forwards++;
      let ok = false;
      try {
        await apiWrite(t, "POST", FORWARD, forwardBody(id, batch, now, n, withFields));
        done.push(`sent ${alertSummary(batch)} through ${id}`);
        ok = true;
        if (!writeFirst)
          sentNow.push(...batch.map(rowKey));
      } catch (err) {
        failed.push(`alerts ${id}: ${err instanceof Error ? err.message : String(err)}`);
      }
      if (after.sending) {
        const left = (after.sending.rows[id] ?? []).filter((r) => !batch.includes(r));
        if (left.length)
          after.sending.rows[id] = left;
        else
          delete after.sending.rows[id];
      }
      if (!ok)
        (after.pending[id] ??= []).push(...batch);
      if ((batches.length > 1 || sending.length > 1) && fitsOneValue(after))
        await kvWriteLarge(t, TOKEN_ALERTS_KEY, after).catch(() => void 0);
    }
  }
  delete after.sending;
  if (outOfCalls > 0 && forwards === 0)
    failed.push(`alerts: ${outOfCalls} waiting, with no Leader calls left this run to send them; a later run sends them`);
  if (!writeFirst) {
    if (sentNow.length) {
      try {
        await recordSent();
      } catch (err) {
        failed.push(`token alerts: couldn't record what was sent (${err instanceof Error ? err.message : String(err)}); a later run may send it again`);
      }
    }
    if (skipFull || forwards === 0 && queueText(after) === queueText(read))
      return { done, failed };
  }
  await kvWriteLarge(t, TOKEN_ALERTS_KEY, after).catch((err) => failed.push(`token alerts: couldn't record what was sent (${err instanceof Error ? err.message : String(err)}); a later run may send it again`));
  return { done, failed };
}

// src/data/pool.ts
var HEALTH_WINDOW_SECONDS = 120;
async function mapPool(items, limit, fn) {
  const results = new Array(items.length);
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      results[i] = await fn(items[i], i);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}

// src/data/alertsApi.ts
var ALERTS_KEY = "settings/alerts";
var READ_CONCURRENCY = 4;
var notificationsPath = (group, id) => `/m/${encodeURIComponent(group)}/notifications${id ? `/${encodeURIComponent(id)}` : ""}`;
async function readAllNotifications(t, groups, signal, expected = /* @__PURE__ */ new Set()) {
  if (groups.length === 0)
    return void 0;
  let items;
  try {
    const payload = await apiGet(t, "/notifications", signal);
    items = itemsOf(payload);
    const count = payload?.count;
    if (typeof count === "number" && count > items.length)
      return void 0;
  } catch (err) {
    if (signal?.aborted)
      throw err;
    return void 0;
  }
  const byGroup = new Map(groups.map((g) => [g, []]));
  let attributed = 0;
  for (const item of items) {
    const g = item?.group;
    if (typeof g !== "string" || !byGroup.has(g))
      continue;
    byGroup.get(g).push(item);
    attributed++;
  }
  const out = new Map([...byGroup].map(([g, its]) => [g, parseNotifications(g, { items: its })]));
  if (items.length > 0 && attributed === 0)
    return void 0;
  const check = new Set(groups.filter((g) => expected.has(g) && byGroup.get(g).length === 0));
  if (attributed === 0 && check.size === 0)
    check.add(groups[0]);
  let covered = true;
  await mapPool([...check], READ_CONCURRENCY, async (g) => {
    try {
      const own = parseNotifications(g, await apiGet(t, notificationsPath(g), signal));
      if (own.length > 0)
        covered = false;
      out.set(g, own);
    } catch (err) {
      if (signal?.aborted)
        throw err;
      out.set(g, void 0);
    }
  });
  return covered ? out : void 0;
}
function expectedGroups(groups, raw, armIds) {
  const out = /* @__PURE__ */ new Set();
  const saved = raw !== void 0 && isAlertSettingsDoc(raw) ? parseAlertSettings(raw) : void 0;
  if (saved?.enabled) {
    for (const id of saved.alerting)
      if (id.includes("/") && !id.includes("/collection:"))
        out.add(id.slice(0, id.indexOf("/")));
  }
  for (const g of groups)
    if (armIds.some((id) => id.startsWith(`${ALERT_PREFIX}${g}--`)))
      out.add(g);
  return out;
}
async function loadAlertState(t, groups, signal, withTargets = true) {
  const rawAsked = kvReadLarge(t, ALERTS_KEY, signal);
  const armAsked = kvRead(t, ARM_STATE_KEY, signal).then(parseArmState, () => ({}));
  const [targets, raw, perGroup, lastRun, armState, tokenSearches] = await Promise.all([
    withTargets ? apiGet(t, "/notification-targets", signal).then(parseTargets) : Promise.resolve([]),
    rawAsked,
    Promise.all([rawAsked.catch(() => void 0), armAsked]).then(([r, arm]) => readAllNotifications(t, groups, signal, expectedGroups(groups, r, Object.keys(arm)))).then(
      (all) => all ? groups.map((g) => ({ group: g, notifications: all.get(g) })) : mapPool(
        groups,
        READ_CONCURRENCY,
        (g) => apiGet(t, notificationsPath(g), signal).then(
          (payload) => ({ group: g, notifications: parseNotifications(g, payload) }),
          () => ({ group: g, notifications: void 0 })
        )
      )
    ),
    kvRead(t, ARM_RUN_KEY, signal).then(parseArmRun, () => void 0),
    armAsked,
    loadTokenSearches(t, signal).catch(() => void 0)
  ]);
  const running = lastRun !== void 0 && Date.now() - lastRun.at <= RUN_STALE_MS;
  const savedUnreadable = raw !== void 0 && !isAlertSettingsDoc(raw);
  return {
    targets,
    saved: raw !== void 0 && !savedUnreadable ? parseAlertSettings(raw) : void 0,
    savedUnreadable,
    notifications: perGroup.flatMap((p) => p.notifications ?? []),
    failedGroups: perGroup.filter((p) => !p.notifications).map((p) => p.group),
    lastRun,
    armedIds: running ? Object.keys(armState) : [],
    backendRunning: running,
    withTargets,
    ...tokenSearches ? { tokenSearches } : {}
  };
}

// src/data/redact.ts
function redactUrls(text2) {
  return text2.replace(/\b([a-z][a-z0-9+.-]*:\/\/)[^\s/@]*@/gi, "$1").replace(/(\b[a-z][a-z0-9+.-]*:\/\/[^\s?#]*)\?[^\s#]*/gi, "$1?\u2026").replace(/(^|\s)(\/[^\s?#]*)\?[^\s#]*/g, "$1$2?\u2026");
}

// src/data/collectors.ts
var SIGNAL_WINDOW_MS = 36e5;
var SIGNAL_LOOKBACK_MS = 7 * 24 * SIGNAL_WINDOW_MS;
function collectorSignalsQuery(groups, now) {
  return {
    earliest: Math.floor((now - SIGNAL_LOOKBACK_MS) / SIGNAL_WINDOW_MS) * SIGNAL_WINDOW_MS,
    latest: now,
    where: `(${groups.map((g) => `__worker_group == ${JSON.stringify(g)}`).join(" || ")}) && !!input && input.startsWith("collection:")`,
    aggs: { aggregations: ['max("health.inputs").as("health")', 'sum("total.in_events").as("events")'], splitBys: ["input", "__worker_group"], timeWindowSeconds: SIGNAL_WINDOW_MS / 1e3 }
  };
}
function collectorSignals(rows) {
  const out = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const input = typeof r.input === "string" ? r.input : "";
    const group = typeof r.__worker_group === "string" ? r.__worker_group : "";
    if (!group || !input.startsWith("collection:"))
      continue;
    const start = rowTime(r);
    if (start === void 0)
      continue;
    const end = toEpochMs(r.endtime) ?? start + SIGNAL_WINDOW_MS;
    const key = `${group}/${input.slice("collection:".length)}`;
    const health = typeof r.health === "number" ? r.health : void 0;
    const cur = out.get(key) ?? { at: 0 };
    if (end > cur.at) {
      cur.at = end;
      cur.health = health;
    } else if (end === cur.at && health !== void 0)
      cur.health = Math.max(cur.health ?? health, health);
    if (typeof r.events === "number" && r.events > 0 && end > (cur.eventsAt ?? 0))
      cur.eventsAt = end;
    out.set(key, cur);
  }
  return out;
}
var RUNS_KEPT = 10;
function runOutcome(r) {
  if (/fail|error|orphan/i.test(r.state))
    return "failed";
  if (/finish|complete|success/i.test(r.state))
    return (r.failedTasks ?? 0) > 0 ? "failed" : "succeeded";
  if (/run|pending|initializ|paused/i.test(r.state))
    return "running";
  return "other";
}
var asRecord3 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
function parseCollectors(group, payload, sorted = true) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const o = asRecord3(item);
    if (!o || typeof o.id !== "string" || o.type !== void 0 && o.type !== "collection")
      continue;
    const schedule = asRecord3(o.schedule);
    const run = asRecord3(schedule?.run);
    const kind = asRecord3(o.collector)?.type;
    const bound = (v) => typeof v === "string" && v.trim() ? v.trim() : typeof v === "number" && Number.isFinite(v) ? v : void 0;
    const earliest = bound(run?.earliest);
    const latest = bound(run?.latest);
    out.push({
      id: o.id,
      group,
      kind: typeof kind === "string" ? kind : "collector",
      scheduled: schedule?.enabled === true,
      cron: typeof schedule?.cronSchedule === "string" ? schedule.cronSchedule : void 0,
      ...typeof o.description === "string" && o.description.trim() ? { description: o.description.trim() } : {},
      ...earliest !== void 0 || latest !== void 0 ? { range: { earliest: earliest ?? "", latest: latest ?? "now" } } : {},
      ...typeof o.ttl === "string" && o.ttl ? { ttl: o.ttl } : {}
    });
  }
  return sorted ? out.sort((a, b) => a.id.localeCompare(b.id)) : out;
}
function runTime(id, stats) {
  const states = asRecord3(stats?.state);
  for (const k of ["initializing", "pending", "running"]) {
    const v = states?.[k];
    if (typeof v === "number" && v > 0)
      return v > 1e11 ? v : v * 1e3;
  }
  for (const k of ["startTime", "startedAt", "start", "launchTime"]) {
    const v = stats?.[k];
    if (typeof v === "number" && v > 0)
      return v > 1e11 ? v : v * 1e3;
  }
  const m = id.match(/^(?:[a-z]+:)?(\d{10,14})\./);
  if (!m)
    return void 0;
  const n = Number(m[1]);
  return n > 1e11 ? n : n * 1e3;
}
var num2 = (v) => typeof v === "number" && Number.isFinite(v) ? v : void 0;
var JOB_STATES = ["initializing", "pending", "running", "paused", "cancelled", "finished", "failed", "orphaned", "unknown"];
var stateName = (v) => typeof v === "number" ? JOB_STATES[v] ?? "unknown" : typeof v === "string" && v ? v : "unknown";
function pullRuns(payload) {
  const all = collectorRuns(payload);
  const types = /* @__PURE__ */ new Map();
  for (const item of itemsOf(payload)) {
    const args = asRecord3(asRecord3(item)?.args);
    const type = asRecord3(args?.input)?.type;
    if (typeof args?.id === "string" && typeof type === "string" && type)
      types.set(args.id, type);
  }
  const out = /* @__PURE__ */ new Map();
  for (const [id, runs] of all) {
    const m = /^([^:]+):(.+)$/.exec(id);
    const type = types.get(id);
    if (!m || !type)
      continue;
    let entry = out.get(m[1]);
    if (!entry)
      out.set(m[1], entry = { type, parts: /* @__PURE__ */ new Map() });
    entry.parts.set(m[2], runs);
  }
  return out;
}
function collectorRuns(payload) {
  const out = /* @__PURE__ */ new Map();
  for (const item of itemsOf(payload)) {
    const o = asRecord3(item);
    const args = asRecord3(o?.args);
    if (!o || typeof o.id !== "string" || typeof args?.id !== "string")
      continue;
    const mode = asRecord3(args.run)?.mode;
    if (mode === "preview" || mode === "list")
      continue;
    const status = asRecord3(o.status);
    const reason = asRecord3(status?.reason);
    const stats = asRecord3(o.stats);
    const tasks = asRecord3(stats?.tasks);
    const finishedAt = num2(asRecord3(stats?.state)?.finished);
    const run = {
      jobId: o.id,
      state: stateName(status?.state),
      at: runTime(o.id, stats),
      ...finishedAt ? { finishedAt } : {},
      ...num2(tasks?.count) !== void 0 ? { tasks: num2(tasks?.count), failedTasks: num2(tasks?.failed) ?? 0 } : {},
      ...num2(stats?.collectedEvents) !== void 0 ? { events: num2(stats?.collectedEvents) } : {},
      ...(num2(stats?.collectedBytes) ?? 0) > 0 ? { bytes: num2(stats?.collectedBytes) } : {},
      reason: typeof reason?.message === "string" ? redactUrls(reason.message) : void 0
    };
    out.set(args.id, [...out.get(args.id) ?? [], run]);
  }
  for (const [id, runs] of out)
    out.set(id, runs.sort((a, b) => (b.at ?? 0) - (a.at ?? 0)).slice(0, RUNS_KEPT));
  return out;
}
var JOBS_PAGE = 1e3;
var JOBS_MAX_PAGES = 10;
var errorText = (err) => err instanceof Error ? err.message : String(err);
async function ownJobs(t, group, signal) {
  try {
    return { payload: await apiGet(t, `/m/${encodeURIComponent(group)}/jobs`, signal), own: true };
  } catch (err) {
    if (signal?.aborted)
      throw err;
    return { error: errorText(err) };
  }
}
async function readJobs(t, groups, signal) {
  const out = /* @__PURE__ */ new Map();
  if (groups.length === 0)
    return out;
  try {
    const byGroup = new Map(groups.map((g) => [g, []]));
    let offset = 0;
    for (let page = 0; ; page++) {
      if (page === JOBS_MAX_PAGES)
        throw new Error("more jobs than one read pages through");
      const payload = await apiGet(t, `/jobs?limit=${JOBS_PAGE}&offset=${offset}`, signal);
      const items = itemsOf(payload);
      for (const item of items) {
        const g = item?.args?.groupId;
        if (typeof g === "string")
          byGroup.get(g)?.push(item);
      }
      const used = payload?.limit;
      const limit = typeof used === "number" && used > 0 ? Math.min(used, JOBS_PAGE) : JOBS_PAGE;
      offset += items.length;
      if (items.length === 0 || items.length < limit)
        break;
    }
    for (const [g, items] of byGroup)
      out.set(g, { payload: { items } });
    return out;
  } catch (err) {
    if (signal?.aborted)
      throw err;
    await mapPool(groups, 4, async (g) => {
      out.set(g, await ownJobs(t, g, signal));
    });
    return out;
  }
}
async function groupJobs(t, group, all, expectRuns, signal) {
  const got = all.get(group) ?? { error: "not read" };
  if ("payload" in got && expectRuns && !got.own) {
    const items = got.payload?.items;
    if (Array.isArray(items) && items.length === 0)
      return ownJobs(t, group, signal);
  }
  return got;
}
var COLLECTOR_FILTER_PARAMS = { kind: "ckind", schedule: "csched", run: "crun", status: "cstatus" };
var COLLECTOR_FILTER_KEYS = Object.values(COLLECTOR_FILTER_PARAMS);

// src/data/inventoryCache.ts
var INVENTORY_INDEX = "cache/inv2/index";
var INVENTORY_VERSION = 1;
var INVENTORY_PARSER = 2;
var PIECE_LIMIT2 = 9e4;
var PIECE_FLOOR2 = 8e3;
var pieceKey = (slot, i) => `cache/inv2/${slot}/${i}`;
var isObj2 = (v) => !!v && typeof v === "object" && !Array.isArray(v);
var str3 = (v) => typeof v === "string";
var optStr = (v) => v === void 0 || str3(v);
function validTokens(v) {
  if (!isObj2(v) || typeof v.count !== "number" || !["on", "off", "unsupported"].includes(v.perToken) || !Array.isArray(v.tokens))
    return false;
  return v.tokens.every((t) => isObj2(t) && str3(t.fp) && optStr(t.description) && typeof t.enabled === "boolean" && Object.keys(t).every((k) => k === "fp" || k === "description" || k === "enabled"));
}
function validSource(v) {
  if (!isObj2(v) || !str3(v.id) || !v.id || !str3(v.type) || !v.type || typeof v.disabled !== "boolean")
    return false;
  if (v.pull !== void 0 && typeof v.pull !== "boolean")
    return false;
  if (v.pullGapMinutes !== void 0 && (typeof v.pullGapMinutes !== "number" || !Number.isFinite(v.pullGapMinutes)))
    return false;
  if (v.port !== void 0 && (typeof v.port !== "number" || !Number.isInteger(v.port)))
    return false;
  if (v.tokens !== void 0 && !validTokens(v.tokens))
    return false;
  return v.collector === void 0;
}
function validCollector(v) {
  if (!isObj2(v) || !str3(v.id) || !v.id || !str3(v.kind) || typeof v.scheduled !== "boolean" || !optStr(v.cron) || !optStr(v.description) || !optStr(v.ttl))
    return false;
  if (v.range !== void 0) {
    const r = v.range;
    if (!isObj2(r) || !(str3(r.earliest) || typeof r.earliest === "number") || !(str3(r.latest) || typeof r.latest === "number"))
      return false;
  }
  return true;
}
function parseInventory(raw) {
  if (!isObj2(raw) || !isObj2(raw.groups))
    return void 0;
  const out = {};
  for (const [g, v] of Object.entries(raw.groups)) {
    if (!isObj2(v) || !str3(v.v) || !v.v || !Array.isArray(v.s) || !(v.c === null || Array.isArray(v.c)))
      continue;
    if (!v.s.every(validSource) || v.c !== null && !v.c.every(validCollector))
      continue;
    out[g] = { configVersion: v.v, sources: v.s, collectors: v.c };
  }
  return out;
}
function asciiJson2(v) {
  return JSON.stringify(v).replace(/[\u007f-￿]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, "0")}`);
}
function serializeInventory(inv) {
  const groups = {};
  for (const g of Object.keys(inv).sort())
    groups[g] = { v: inv[g].configVersion, s: inv[g].sources, c: inv[g].collectors };
  const body = asciiJson2(groups);
  const stamp = `${fingerprint(body)}${body.length.toString(36)}`;
  return { stamp, text: `{"stamp":${JSON.stringify(stamp)},"groups":${body}}` };
}
function sourceEntry(s) {
  return {
    id: s.id,
    type: s.type,
    disabled: s.disabled,
    ...s.tokens ? { tokens: s.tokens } : {},
    ...s.pull ? { pull: s.pull } : {},
    ...s.pullGapMinutes !== void 0 ? { pullGapMinutes: s.pullGapMinutes } : {},
    ...s.port !== void 0 ? { port: s.port } : {}
  };
}
function collectorDef(c) {
  return {
    id: c.id,
    kind: c.kind,
    scheduled: c.scheduled,
    ...c.cron !== void 0 ? { cron: c.cron } : {},
    ...c.description !== void 0 ? { description: c.description } : {},
    ...c.range ? { range: c.range } : {},
    ...c.ttl !== void 0 ? { ttl: c.ttl } : {}
  };
}
async function readOnce(t, signal) {
  let index;
  try {
    index = await kvRead(t, INVENTORY_INDEX, signal);
  } catch {
    return { state: "unreadable", transient: true };
  }
  if (index === void 0)
    return { state: "absent" };
  if (!isObj2(index))
    return { state: "absent" };
  const ix = index;
  if (ix.version !== INVENTORY_VERSION || ix.parser !== INVENTORY_PARSER)
    return { state: "absent" };
  if (!str3(ix.stamp) || ix.slot !== "slot1" && ix.slot !== "slot2" || typeof ix.pieces !== "number" || ix.pieces < 1 || ix.pieces > 200 || typeof ix.length !== "number" || !isObj2(ix.groups))
    return { state: "absent" };
  const slot = ix.slot;
  let pieces;
  try {
    pieces = await Promise.all(Array.from({ length: ix.pieces }, (_, i) => kvRead(t, pieceKey(slot, i), signal)));
  } catch {
    return { state: "unreadable", slot, transient: true };
  }
  try {
    let text2 = "";
    for (let i = 0; i < pieces.length; i++) {
      const p = pieces[i];
      if (!isObj2(p) || p.s !== ix.stamp || p.i !== i || !str3(p.d))
        return { state: "unreadable", slot };
      text2 += p.d;
    }
    if (text2.length !== ix.length)
      return { state: "unreadable", slot };
    const doc = JSON.parse(text2);
    if (!isObj2(doc) || doc.stamp !== ix.stamp)
      return { state: "unreadable", slot };
    const all = parseInventory(doc);
    if (!all)
      return { state: "unreadable", slot };
    const inventory = {};
    for (const [g, v] of Object.entries(all))
      if (ix.groups[g] === v.configVersion)
        inventory[g] = v;
    return { state: "ok", inventory, stamp: ix.stamp, slot };
  } catch {
    return { state: "unreadable", slot };
  }
}
async function readInventory(t, signal) {
  const first = await readOnce(t, signal);
  return first.state === "unreadable" && !signal?.aborted ? readOnce(t, signal) : first;
}
async function writeInventory(t, inv, current) {
  const { stamp, text: text2 } = serializeInventory(inv);
  const groups = Object.fromEntries(Object.entries(inv).map(([g, v]) => [g, v.configVersion]));
  const slot = current === "slot1" ? "slot2" : "slot1";
  let limit = PIECE_LIMIT2;
  for (; ; ) {
    const pieces = splitPieces(text2, stamp, limit);
    try {
      for (const p of pieces)
        await kvWrite(t, pieceKey(slot, p.i), p);
      const index = { version: INVENTORY_VERSION, parser: INVENTORY_PARSER, stamp, slot, pieces: pieces.length, length: text2.length, groups };
      await kvWrite(t, INVENTORY_INDEX, index);
      return stamp;
    } catch (err) {
      const status = err?.status;
      if (status !== 413 || limit <= PIECE_FLOOR2)
        throw err;
      limit = Math.max(PIECE_FLOOR2, Math.floor(limit / 2));
    }
  }
}
function rotation(groups, now, perRun = 2) {
  if (groups.length === 0)
    return /* @__PURE__ */ new Set();
  const sorted = [...groups].sort();
  const slots = Math.ceil(sorted.length / perRun);
  const slot = Math.floor(now / 6e4) % slots;
  return new Set(sorted.slice(slot * perRun, slot * perRun + perRun));
}

// src/data/load.ts
var INVENTORY_CONCURRENCY = 4;
var GROUP_ID = /^[A-Za-z0-9._-]+$/;
var INVENTORY_TTL_MS = 5 * 6e4;
var seriesTtlMs = (range) => Math.min(5 * 6e4, range.windowSeconds * 1e3);
var STATUS_RANGE = rangeFor("24h");
var LIVE_REUSE_MS = 3e4;
function asRecord4(v) {
  return v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
}
function parseGroups(payload) {
  const ids = /* @__PURE__ */ new Set();
  for (const item of itemsOf(payload)) {
    const obj = asRecord4(item);
    const id = obj?.id;
    if (typeof id !== "string" || !GROUP_ID.test(id) || id === "." || id === "..")
      continue;
    if (typeof obj?.type === "string" && obj.type !== "stream")
      continue;
    if (obj?.isFleet === true || obj?.isSearch === true)
      continue;
    ids.add(id);
  }
  return [...ids].sort();
}
function parseGroupVersions(payload) {
  const ids = new Set(parseGroups(payload));
  const out = /* @__PURE__ */ new Map();
  for (const item of itemsOf(payload)) {
    const obj = asRecord4(item);
    if (typeof obj?.id === "string" && ids.has(obj.id) && typeof obj.configVersion === "string" && obj.configVersion)
      out.set(obj.id, obj.configVersion);
  }
  return out;
}
function pullGapMinutes(o) {
  const intervals = (Array.isArray(o.contentConfig) ? o.contentConfig : []).map(asRecord4).filter((c) => Boolean(c) && c.enabled !== false && typeof c.interval === "number" && Number.isFinite(c.interval) && c.interval > 0).map((c) => c.interval);
  if (intervals.length)
    return Math.max(...intervals);
  if (typeof o.interval === "number" && Number.isFinite(o.interval) && o.interval > 0) {
    const unit = typeof o.intervalUnit === "string" ? o.intervalUnit.toLowerCase() : "m";
    return unit.startsWith("s") ? o.interval / 60 : unit.startsWith("h") ? o.interval * 60 : o.interval;
  }
  return typeof o.cronSchedule === "string" ? cronLongestGapMinutes(o.cronSchedule) : void 0;
}
function parseInputs(group, payload) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const obj = asRecord4(item);
    const id = obj?.id;
    const type = obj?.type;
    if (typeof id !== "string" || !id || typeof type !== "string" || !type)
      continue;
    const tokens = parseSourceTokens(type, obj);
    const pull = "keepAliveTime" in obj || "maxMissedKeepAlives" in obj;
    const gap = pull ? pullGapMinutes(obj) : void 0;
    const asPort = (v) => {
      const n = typeof v === "string" && v.trim() !== "" ? Number(v) : v;
      return typeof n === "number" && Number.isInteger(n) && n > 0 && n < 65536 ? n : void 0;
    };
    const port = asPort(obj.port) ?? asPort(obj.tcpPort) ?? asPort(obj.udpPort);
    out.push({ group, id, type, disabled: obj?.disabled === true, ...tokens ? { tokens } : {}, ...pull ? { pull } : {}, ...gap !== void 0 ? { pullGapMinutes: gap } : {}, ...port !== void 0 ? { port } : {} });
  }
  return out;
}
function collectorRecord(group, d) {
  const cron = typeof d.cron === "string" && d.cron.trim() ? d.cron.trim() : void 0;
  return { group, id: d.id, type: "collection", disabled: false, collector: { kind: d.kind, scheduled: d.scheduled, ...cron ? { cron } : {} } };
}
function groupFilter(groups) {
  return groups.map((g) => `__worker_group == ${JSON.stringify(g)}`).join(" || ");
}
function seriesQuery(range, groups, now) {
  return {
    earliest: bucketStarts(range, now)[0],
    latest: now,
    where: groupFilter(groups),
    aggs: {
      aggregations: [`sum("total.in_events").as("${FIELDS.events}")`, `sum("total.in_bytes").as("${FIELDS.bytes}")`],
      splitBys: ["input", "__worker_group"],
      timeWindowSeconds: range.windowSeconds
    }
  };
}
function recentQuery(groups, now, shape) {
  const w = shape.windowSeconds * 1e3;
  return {
    earliest: Math.floor((now - shape.lookbackSeconds * 1e3) / w) * w,
    latest: now,
    where: groupFilter(groups),
    aggs: {
      aggregations: [`sum("total.in_events").as("${FIELDS.recent}")`, `sum("total.in_bytes").as("${FIELDS.recentBytes}")`],
      splitBys: ["input", "__worker_group"],
      timeWindowSeconds: shape.windowSeconds
    }
  };
}
var LONG_FILTER_MAX = 300;
var STATUS_SPAN_MS = 864e5;
function longInputFilter(settings, rows, recentLookbackSeconds, longLookbackSeconds) {
  if (longLookbackSeconds !== void 0 && longLookbackSeconds * 1e3 > STATUS_SPAN_MS + 6e4)
    return void 0;
  const limit = recentLookbackSeconds * 1e3 - 6e4;
  const overrides = Object.keys(settings.overrides);
  let longest = 0;
  const long = (rowId) => {
    const ms = allowanceMs(thresholdsFor(settings, rowId));
    if (ms > limit && !isScheduledRowId(rowId))
      longest = Math.max(longest, ms);
    return ms > limit;
  };
  const needs = (rowId) => {
    const own = long(rowId);
    const child = overrides.filter((k) => k.startsWith(`${rowId}~`) || k.startsWith(`${rowId}#`)).map(long).some(Boolean);
    return own || child;
  };
  const clauses = /* @__PURE__ */ new Set();
  let named = 0;
  for (const s of rows) {
    const rowId = s.collector ? `${s.group}/collection:${s.id}` : `${s.group}/${s.type}:${s.id}`;
    if (!needs(rowId))
      continue;
    named++;
    if (s.collector) {
      clauses.add(`input == ${JSON.stringify(`collection:${s.id}`)}`);
      continue;
    }
    const base = criblInput(s.type, s.id);
    clauses.add(`input == ${JSON.stringify(base)}`);
    clauses.add(`input.startsWith(${JSON.stringify(`${base}:`)})`);
    if (s.pull)
      clauses.add(`input.startsWith(${JSON.stringify(`collection:${s.id}:`)})`);
  }
  if (named === 0 || named > LONG_FILTER_MAX || longest > STATUS_SPAN_MS)
    return void 0;
  return `(!input || ${[...clauses].join(" || ")})`;
}
var TOKEN_SPLIT = ["inputId", "token", "tokenDescription", "__worker_group"];
function tokenSeriesQuery(range, groups, now) {
  return {
    earliest: bucketStarts(range, now)[0],
    latest: now,
    where: groupFilter(groups),
    aggs: {
      aggregations: [`sum("http.perToken.numEvents").as("${FIELDS.events}")`, `sum("http.perToken.bytesReceived").as("${FIELDS.bytes}")`, `sum("http.perToken.numErrors").as("${FIELDS.rejected}")`],
      splitBys: TOKEN_SPLIT,
      timeWindowSeconds: range.windowSeconds
    }
  };
}
function tokenRecentQuery(groups, now, shape) {
  const base = recentQuery(groups, now, shape);
  return {
    ...base,
    aggs: {
      aggregations: [`sum("http.perToken.numEvents").as("${FIELDS.recent}")`, `sum("http.perToken.bytesReceived").as("${FIELDS.recentBytes}")`],
      splitBys: TOKEN_SPLIT,
      timeWindowSeconds: shape.windowSeconds
    }
  };
}
function healthQuery(groups, now) {
  return {
    earliest: now - HEALTH_WINDOW_SECONDS * 1e3,
    latest: now,
    where: groupFilter(groups),
    aggs: { aggregations: [`max("health.inputs").as("${FIELDS.health}")`], cumulative: true, splitBys: ["input", "__worker_group"] }
  };
}
function describe(err) {
  return err instanceof Error ? err.message : String(err);
}
function groupBatches(groups, sources, size) {
  const count = /* @__PURE__ */ new Map();
  for (const s of sources)
    count.set(s.group, (count.get(s.group) ?? 0) + 1);
  const out = [];
  let cur = [];
  let n = 0;
  for (const g of groups) {
    const c = count.get(g) ?? 0;
    if (cur.length > 0 && n + c > size) {
      out.push(cur);
      cur = [];
      n = 0;
    }
    cur.push(g);
    n += c;
  }
  if (cur.length)
    out.push(cur);
  return out;
}
var BATCH_CONCURRENCY = 4;
async function batchedQuery(t, batches, build, signal) {
  if (batches.length === 1) {
    const r = await apiQuery(t, "/system/metrics/query", build(batches[0]), signal);
    return { rows: r.results ?? [], failed: [] };
  }
  const outcomes = await mapPool(batches, BATCH_CONCURRENCY, async (gs) => {
    for (let attempt = 0; ; attempt++) {
      if (signal?.aborted)
        return { err: new DOMException("Aborted", "AbortError") };
      try {
        const r = await apiQuery(t, "/system/metrics/query", build(gs), signal);
        return { rows: r.results ?? [] };
      } catch (err) {
        if (signal?.aborted || attempt === 1)
          return { err };
      }
    }
  });
  if (signal?.aborted)
    throw new DOMException("Aborted", "AbortError");
  const failed = batches.filter((_, i) => outcomes[i].rows === void 0).flat();
  const firstErr = outcomes.find((o) => o.rows === void 0);
  if (failed.length === batches.flat().length)
    throw firstErr?.err;
  return { rows: outcomes.flatMap((o) => o.rows ?? []), failed, ...firstErr ? { reason: describe(firstErr.err) } : {} };
}
async function loadActivity(t, range, settings, signal, cache = {}, options = {}) {
  const warnings = [];
  const now = Date.now();
  let shape = recentQueryShape(settings);
  let base = {
    range,
    now,
    recentWindowSeconds: shape.windowSeconds,
    recentEarliest: recentQuery([], now, shape).earliest,
    allowanceMs: (id) => allowanceMs(thresholdsFor(settings, id)),
    untracked: settings.untracked.length ? ((untrackedIds) => (id) => untrackedIds.has(id))(new Set(settings.untracked)) : void 0,
    snoozed: Object.keys(settings.snoozed).length ? (id) => snoozedUntil(settings, id, now) : void 0
  };
  let inventory = cache.inventory && now - cache.inventory.at < INVENTORY_TTL_MS ? cache.inventory : void 0;
  if (!inventory) {
    const groupsPayload = await apiGet(t, "/products/stream/groups", signal);
    const groups2 = parseGroups(groupsPayload);
    const versions = parseGroupVersions(groupsPayload);
    const useStore = options.inventoryCache !== false;
    const read = useStore && versions.size > 0 ? await readInventory(t, signal) : { state: "absent" };
    const stored = read.state === "ok" ? read : void 0;
    const refreshing = options.inventoryCache === "refresh";
    const refresh = rotation(groups2, now);
    const cachedFor = (g) => {
      const v = versions.get(g);
      const c = v !== void 0 && !refreshing ? stored?.inventory[g] : void 0;
      return c && c.configVersion === v && c.collectors !== null ? c : void 0;
    };
    const uncached = groups2.filter((g) => !cachedFor(g));
    const start = uncached.length > 0 ? Math.floor(now / 6e4) * Math.max(1, options.maxListedGroups ?? 1) % uncached.length : 0;
    const wanted = [...uncached.slice(start), ...uncached.slice(0, start), ...groups2.filter((g) => cachedFor(g) && refresh.has(g))];
    const limit = options.maxListedGroups !== void 0 && useStore && versions.size > 0 ? options.maxListedGroups : void 0;
    const toList = new Set(limit === void 0 ? wanted : wanted.slice(0, Math.max(0, limit)));
    const kept = {};
    const unread2 = [];
    const byReason = /* @__PURE__ */ new Map();
    const perGroup = await mapPool(groups2, INVENTORY_CONCURRENCY, async (group) => {
      const version = versions.get(group);
      const prior = version !== void 0 && stored?.inventory[group]?.configVersion === version ? stored.inventory[group] : void 0;
      const cached = refreshing ? void 0 : prior;
      const fromCache = (c) => ({ sources: c.sources.map((s) => ({ ...s, group })), defs: c.collectors ?? void 0 });
      if (cached && cached.collectors !== null && !toList.has(group)) {
        kept[group] = cached;
        return fromCache(cached);
      }
      const previous = stored?.inventory[group];
      if (!toList.has(group) && previous && previous.collectors !== null) {
        kept[group] = previous;
        return fromCache(previous);
      }
      if (!toList.has(group)) {
        const reason = "left for the next check, which lists a few Worker Groups at a time";
        byReason.set(reason, [...byReason.get(reason) ?? [], group]);
        unread2.push(group);
        return { sources: [], defs: void 0, deferred: true };
      }
      const defsAsked = apiGet(t, `/m/${encodeURIComponent(group)}/lib/jobs`, signal).then((payload) => parseCollectors(group, payload, false).filter((c) => c.id).map(collectorDef)).catch(() => void 0);
      try {
        const sources2 = parseInputs(group, await apiGet(t, `/m/${encodeURIComponent(group)}/system/inputs`, signal));
        if (sources2.length === 0 && prior && prior.sources.length > 0) {
          const merged = { ...prior, collectors: await defsAsked ?? prior.collectors };
          kept[group] = merged;
          return fromCache(merged);
        }
        const defs = await defsAsked ?? prior?.collectors ?? void 0;
        if (version !== void 0)
          kept[group] = { configVersion: version, sources: sources2.map(sourceEntry), collectors: defs ?? null };
        return { sources: sources2, defs };
      } catch (err) {
        const defs = await defsAsked;
        if (signal?.aborted)
          throw err;
        if (prior) {
          const merged = { ...prior, collectors: defs ?? prior.collectors };
          kept[group] = merged;
          return fromCache(merged);
        }
        const reason = describe(err);
        byReason.set(reason, [...byReason.get(reason) ?? [], group]);
        unread2.push(group);
        return { sources: [], defs };
      }
    });
    const listWarnings = [...byReason].map(
      ([reason, gs]) => gs.length === 1 ? `Couldn't list Sources in Worker Group "${gs[0]}" (${reason}).` : `Couldn't list Sources in Worker Groups ${gs.map((g) => `"${g}"`).join(", ")} (${reason}).`
    );
    const collectorsRead = perGroup.every((r) => r.defs !== void 0 || "deferred" in r && r.deferred);
    const collectorDefs2 = /* @__PURE__ */ new Map();
    groups2.forEach((g, i) => {
      const defs = perGroup[i].defs;
      if (defs)
        collectorDefs2.set(g, defs);
    });
    inventory = {
      at: now,
      groups: groups2,
      sources: perGroup.flatMap((r) => r.sources),
      readable: groups2.filter((_, i) => perGroup[i].sources.length > 0),
      unread: unread2,
      warnings: listWarnings,
      ...collectorsRead ? { collectors: groups2.flatMap((g, i) => (perGroup[i].defs ?? []).filter((d) => d.id).map((d) => collectorRecord(g, d))) } : {},
      collectorDefs: collectorDefs2
    };
    if (unread2.length === 0 && inventory.collectors !== void 0)
      cache.inventory = inventory;
    const complete = groups2.every((g) => !versions.has(g) || g in kept);
    const liveSlot = stored?.slot ?? (read.state === "unreadable" ? read.slot : void 0);
    const rebuild = read.state === "unreadable" && !read.transient && read.slot !== void 0;
    if (useStore && Object.keys(kept).length > 0 && (read.state !== "unreadable" || complete || rebuild) && serializeInventory(kept).stamp !== stored?.stamp) {
      const write = writeInventory(t, kept, liveSlot).then(
        () => void 0,
        (err) => `Couldn't store the Worker Groups' Source lists (${describe(err)}), so they're listed again next time.`
      );
      if (options.awaitCacheWrite) {
        const failed = await write;
        if (failed)
          inventory.warnings = [...inventory.warnings, failed];
      }
    }
  }
  const { groups, sources, readable, unread, collectorDefs } = inventory;
  const collectors = inventory.collectors?.filter((c) => readable.includes(c.group));
  registerCollectorSchedules((collectors ?? []).map((c) => [`${c.group}/collection:${c.id}`, c.collector?.cron]));
  registerPullSchedules(sources.filter((s) => s.pull).map((s) => [`${s.group}/${s.type}:${s.id}`, s.pullGapMinutes]));
  shape = recentQueryShape(settings);
  const long = longQueryShape(settings);
  base = { ...base, recentWindowSeconds: shape.windowSeconds, recentEarliest: recentQuery([], now, shape).earliest };
  warnings.push(...inventory.warnings);
  if (!collectors)
    warnings.push("Collectors couldn't be listed, so they aren't shown with Cribl's metrics.");
  if (groups.length === 0) {
    return { model: buildActivity({ ...base, sources: [], collectors: [], seriesRows: [], recentRows: [], healthRows: [] }), groups, unreadGroups: unread, warnings, collectorDefs, activityUnreadGroups: [] };
  }
  if (readable.length === 0) {
    return { model: buildActivity({ ...base, sources, collectors, seriesRows: [], recentRows: [], healthRows: [] }), groups, unreadGroups: unread, warnings, collectorDefs, activityUnreadGroups: [] };
  }
  const seriesKey = `${range.key}|${readable.join(",")}`;
  const cachedSeries = cache.series && cache.series.key === seriesKey && now - cache.series.at < seriesTtlMs(range) ? cache.series : void 0;
  const tokenGroups = options.perToken === false ? [] : [...new Set(sources.filter((s) => s.tokens?.perToken === "on" && readable.includes(s.group)).map((s) => s.group))];
  const tokenKey2 = `${range.key}|${tokenGroups.join(",")}`;
  const cachedTokens = cache.tokenSeries && cache.tokenSeries.key === tokenKey2 && now - cache.tokenSeries.at < seriesTtlMs(range) ? cache.tokenSeries : void 0;
  const none = Promise.resolve(void 0);
  const liveKey = `${readable.join(",")}|${tokenGroups.join(",")}|${shape.lookbackSeconds}|${shape.windowSeconds}|${long ? `${long.lookbackSeconds}/${long.windowSeconds}/${fingerprint(longInputFilter(settings, [...sources, ...collectors ?? []].filter((s) => readable.includes(s.group)), shape.lookbackSeconds, long.lookbackSeconds) ?? "")}` : ""}`;
  const cachedLive = cache.live && cache.live.key === liveKey && now - cache.live.at >= 0 && now - cache.live.at < LIVE_REUSE_MS ? cache.live : void 0;
  const statusRange = range.key === STATUS_RANGE.key ? void 0 : STATUS_RANGE;
  const fresh = (c) => c !== void 0 && now - c.at < seriesTtlMs(STATUS_RANGE);
  const statusKey = readable.join(",");
  const cachedStatus = fresh(cache.status) && cache.status.key === statusKey ? cache.status : cache.series && fresh(cache.series) && cache.series.key === `${STATUS_RANGE.key}|${statusKey}` ? cache.series : void 0;
  const tokenStatusKey = tokenGroups.join(",");
  const cachedTokenStatus = fresh(cache.tokenStatus) && cache.tokenStatus.key === tokenStatusKey ? cache.tokenStatus : cache.tokenSeries && fresh(cache.tokenSeries) && cache.tokenSeries.key === `${STATUS_RANGE.key}|${tokenStatusKey}` ? cache.tokenSeries : void 0;
  const longFilter = long ? longInputFilter(settings, [...sources, ...collectors ?? []].filter((s) => readable.includes(s.group)), shape.lookbackSeconds, long.lookbackSeconds) : void 0;
  const longQuery = (gs) => (({ where, ...rest }) => ({ ...rest, where: longFilter ? `(${String(where)}) && ${longFilter}` : where }))(recentQuery(gs, now, long));
  const batches = options.batchSources ? groupBatches(readable, sources, options.batchSources) : [readable];
  const metricsFailed = /* @__PURE__ */ new Map();
  const ask = (core, build) => batchedQuery(t, batches, build, signal).then((r) => {
    if (r.failed.length > 0) {
      if (!core)
        throw new Error(r.reason ?? "part of the query failed");
      for (const g of r.failed)
        metricsFailed.set(g, r.reason ?? "the query failed");
    }
    return { results: r.rows };
  });
  const [series, recent, health, tokenSeries, tokenRecent, statusSeries, tokenStatusSeries, longRecent, tokenLongRecent] = await Promise.allSettled([
    cachedSeries ? Promise.resolve({ results: cachedSeries.rows }) : ask(true, (gs) => seriesQuery(range, gs, cachedLive ? cachedLive.at : now)),
    cachedLive ? Promise.resolve({ results: cachedLive.recent }) : ask(true, (gs) => recentQuery(gs, now, shape)),
    cachedLive ? Promise.resolve({ results: cachedLive.health }) : ask(false, (gs) => healthQuery(gs, now)),
    tokenGroups.length === 0 ? none : cachedTokens ? Promise.resolve({ results: cachedTokens.rows }) : apiQuery(t, "/system/metrics/query", tokenSeriesQuery(range, tokenGroups, now), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) })),
    tokenGroups.length === 0 ? none : cachedLive?.tokenRecent ? Promise.resolve({ results: cachedLive.tokenRecent }) : apiQuery(t, "/system/metrics/query", tokenRecentQuery(tokenGroups, now, shape), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) })),
    !statusRange ? none : cachedStatus ? Promise.resolve({ results: cachedStatus.rows }) : ask(false, (gs) => seriesQuery(statusRange, gs, now)),
    !statusRange || tokenGroups.length === 0 ? none : cachedTokenStatus ? Promise.resolve({ results: cachedTokenStatus.rows }) : apiQuery(t, "/system/metrics/query", tokenSeriesQuery(statusRange, tokenGroups, now), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) })),
    !long ? none : cachedLive?.long ? Promise.resolve({ results: cachedLive.long }) : ask(false, longQuery),
    !long || tokenGroups.length === 0 ? none : cachedLive?.tokenLong ? Promise.resolve({ results: cachedLive.tokenLong }) : apiQuery(t, "/system/metrics/query", tokenRecentQuery(tokenGroups, now, long), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) }))
  ]);
  if (signal?.aborted)
    throw new DOMException("Aborted", "AbortError");
  if (statusRange && statusSeries.status === "fulfilled" && statusSeries.value && cachedStatus !== cache.status)
    cache.status = { at: cachedStatus?.at ?? now, key: statusKey, rows: statusSeries.value.results ?? [] };
  if (statusRange && tokenStatusSeries.status === "fulfilled" && tokenStatusSeries.value && cachedTokenStatus !== cache.tokenStatus)
    cache.tokenStatus = { at: cachedTokenStatus?.at ?? now, key: tokenStatusKey, rows: tokenStatusSeries.value.results ?? [] };
  if (statusRange && statusSeries.status === "rejected")
    warnings.push(`The last day's activity couldn't be read, so statuses use the selected range (${describe(statusSeries.reason)}).`);
  if (statusRange && tokenStatusSeries.status === "rejected")
    warnings.push(`The last day's per-token activity couldn't be read, so tokens' statuses use the selected range (${describe(tokenStatusSeries.reason)}).`);
  if (tokenGroups.length > 0) {
    if (tokenSeries.status === "fulfilled" && tokenSeries.value && !cachedTokens)
      cache.tokenSeries = { at: now, key: tokenKey2, rows: tokenSeries.value.results ?? [] };
    if (tokenSeries.status === "rejected")
      warnings.push(`Per-token query failed, so Sources with several tokens are monitored as a whole (${describe(tokenSeries.reason)}).`);
    if (tokenRecent.status === "rejected")
      warnings.push(`Per-token recent-activity query failed, so Sources with several tokens are monitored as a whole (${describe(tokenRecent.reason)}).`);
  }
  if (series.status === "rejected")
    throw series.reason;
  const failedGroups = [...metricsFailed.keys()];
  if (failedGroups.length > 0 && readable.every((g) => metricsFailed.has(g))) {
    throw new Error(`Activity couldn't be read for any Worker Group (${[...new Set(metricsFailed.values())].join("; ")})`);
  }
  if (failedGroups.length > 0) {
    const reasons = /* @__PURE__ */ new Map();
    for (const [g, why] of metricsFailed)
      reasons.set(why, [...reasons.get(why) ?? [], g]);
    for (const [why, gs] of reasons)
      warnings.push(`Couldn't read activity for Worker Group${gs.length === 1 ? "" : "s"} ${gs.map((g) => `"${g}"`).join(", ")} (${why}), so ${gs.length === 1 ? "its" : "their"} Sources aren't shown until a reload reads ${gs.length === 1 ? "it" : "them"}.`);
  }
  if (!cachedSeries && failedGroups.length === 0)
    cache.series = { at: now, key: seriesKey, rows: series.value.results ?? [] };
  if (recent.status === "rejected")
    warnings.push(`Recent-activity query failed, so Active and Overdue can't be told apart (${describe(recent.reason)}).`);
  if (health.status === "rejected")
    warnings.push(`Health query failed, so Source health isn't shown (${describe(health.reason)}).`);
  if (long && longRecent.status === "rejected")
    warnings.push(`The query for allowances of 6 hours or more failed, so a Source with one longer than a day and no events in it reads Unknown (${describe(longRecent.reason)}).`);
  if (long && tokenGroups.length > 0 && tokenLongRecent.status === "rejected")
    warnings.push(`The per-token query for allowances of 6 hours or more failed, so a token with one longer than a day and no events in it reads Unknown (${describe(tokenLongRecent.reason)}).`);
  const longRows = long && longRecent.status === "fulfilled" && longRecent.value ? longRecent.value.results ?? [] : void 0;
  const tokenLongRows = long && tokenLongRecent.status === "fulfilled" && tokenLongRecent.value ? tokenLongRecent.value.results ?? [] : void 0;
  if (!cachedLive && failedGroups.length === 0 && recent.status === "fulfilled" && health.status === "fulfilled" && (tokenGroups.length === 0 || tokenRecent.status === "fulfilled" && tokenRecent.value) && (!long || longRows !== void 0 && (tokenGroups.length === 0 || tokenLongRows !== void 0))) {
    cache.live = {
      at: now,
      key: liveKey,
      recent: recent.value.results ?? [],
      health: health.value.results ?? [],
      tokenRecent: tokenRecent.status === "fulfilled" && tokenRecent.value ? tokenRecent.value.results ?? [] : void 0,
      ...longRows ? { long: longRows } : {},
      ...tokenLongRows ? { tokenLong: tokenLongRows } : {}
    };
  }
  const asOf = cachedLive ? { now: cachedLive.at, recentEarliest: recentQuery([], cachedLive.at, shape).earliest } : {};
  const model = buildActivity({
    ...base,
    ...asOf,
    sources: failedGroups.length ? sources.filter((s) => !metricsFailed.has(s.group)) : sources,
    collectors: failedGroups.length ? collectors?.filter((c) => !metricsFailed.has(c.group)) : collectors,
    seriesRows: series.value.results ?? [],
    recentRows: recent.status === "fulfilled" ? recent.value.results ?? [] : void 0,
    healthRows: health.status === "fulfilled" ? health.value.results ?? [] : void 0,
    tokenSeriesRows: tokenSeries.status === "fulfilled" && tokenSeries.value ? tokenSeries.value.results ?? [] : void 0,
    tokenRecentRows: tokenRecent.status === "fulfilled" && tokenRecent.value ? tokenRecent.value.results ?? [] : void 0,
    ...long ? { longWindowSeconds: long.windowSeconds, longRows, tokenLongRows } : {},
    ...statusRange && statusSeries.status === "fulfilled" && statusSeries.value ? {
      statusRows: statusSeries.value.results ?? [],
      statusWindowSeconds: statusRange.windowSeconds,
      ...tokenStatusSeries.status === "fulfilled" && tokenStatusSeries.value ? { tokenStatusRows: tokenStatusSeries.value.results ?? [] } : {}
    } : {}
  });
  const missing = [...unread, ...failedGroups];
  const listed = missing.length ? { ...model, unmatchedSeries: model.unmatchedSeries.filter((k) => !missing.includes(k.slice(0, k.indexOf("/")))) } : model;
  return { model: listed, groups, unreadGroups: missing, warnings, collectorDefs, activityUnreadGroups: failedGroups };
}

// src/data/searchSettings.ts
var SEARCH_KEY = "settings/search";
var DEFAULT_METRICS_QUERY = 'dataset={dataset} | where _metric == "cribl.logstream.total.in_events" and (input == {input} or input startswith {prefix}) and group == {group} | timestats span={span} events=sum(_value)';
var DEFAULT_LOGS_QUERY = "dataset={dataset} | where channel == {channel} | sort by _time desc";
var FORMER_DEFAULTS = /* @__PURE__ */ new Set([
  'dataset={dataset} | where _metric == "cribl.logstream.total.in_events" and input == {input} | timestats span={span} events=sum(_value)',
  'dataset={dataset} | where _metric == "cribl.logstream.total.in_events" and input == {input} and group == {group} | timestats span={span} events=sum(_value)'
]);
var DEFAULT_SEARCH = {
  version: 1,
  metricsEnabled: false,
  metricsDataset: "cribl_metrics",
  logsEnabled: false,
  logsDataset: "cribl_logs",
  metricsQuery: DEFAULT_METRICS_QUERY,
  logsQuery: DEFAULT_LOGS_QUERY,
  lookbackEnabled: false,
  lookbackDays: 30
};
var TOKENS = {
  dataset: "the dataset above",
  input: "Cribl's name for the Source, such as http:in_http or cribl:CriblMetrics",
  prefix: "that name and a colon, to match its protocol variants such as http:in_http:cribl",
  id: "the Source ID",
  channel: "its log channel, input:<Source ID>",
  group: "its Worker Group",
  span: "the chart interval, such as 60s (not quoted)"
};
var DATASET = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/;
var MAX_QUERY = 2e3;
function datasetError(value, required = true) {
  const v = value.trim();
  if (!v)
    return required ? "Enter the dataset to search, or turn this search off." : void 0;
  return DATASET.test(v) ? void 0 : "Use letters, digits, underscores, dots and dashes.";
}
function queryError(value) {
  const v = value.trim();
  if (!v)
    return "Enter a query, or reset it to the default.";
  if (v.length > MAX_QUERY)
    return `Keep it under ${MAX_QUERY} characters.`;
  if (!v.includes("{dataset}"))
    return "Include {dataset}.";
  const unknown = [...v.matchAll(/\{([a-z]+)\}/g)].map((m) => m[1]).find((t) => !(t in TOKENS));
  return unknown ? `Unknown placeholder {${unknown}}.` : void 0;
}
function parseSearchSettings(raw) {
  const o = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  const ds = (v, fallback) => typeof v === "string" && v.trim() && !datasetError(v) ? v.trim() : fallback;
  const on = (v, dataset) => typeof v === "boolean" ? v : typeof dataset === "string" && dataset.trim() !== "" && !datasetError(dataset);
  const q = (v, fallback) => typeof v === "string" && !queryError(v) && !FORMER_DEFAULTS.has(v.trim()) ? v.trim() : fallback;
  return {
    version: 1,
    metricsEnabled: on(o.metricsEnabled, o.metricsDataset),
    metricsDataset: ds(o.metricsDataset, DEFAULT_SEARCH.metricsDataset),
    logsEnabled: on(o.logsEnabled, o.logsDataset),
    logsDataset: ds(o.logsDataset, DEFAULT_SEARCH.logsDataset),
    metricsQuery: q(o.metricsQuery, DEFAULT_METRICS_QUERY),
    logsQuery: q(o.logsQuery, DEFAULT_LOGS_QUERY),
    lookbackEnabled: o.lookbackEnabled === true,
    lookbackDays: typeof o.lookbackDays === "number" && Number.isInteger(o.lookbackDays) && o.lookbackDays >= 1 && o.lookbackDays <= 90 ? o.lookbackDays : DEFAULT_SEARCH.lookbackDays,
    updatedAt: typeof o.updatedAt === "number" ? o.updatedAt : void 0,
    updatedBy: typeof o.updatedBy === "string" ? o.updatedBy : void 0
  };
}
function isSearchDoc(raw) {
  return !!raw && typeof raw === "object" && !Array.isArray(raw) && raw.version === 1;
}
async function loadSearchSettings(t, signal) {
  const raw = await kvRead(t, SEARCH_KEY, signal);
  if (raw === void 0)
    return DEFAULT_SEARCH;
  if (!isSearchDoc(raw))
    throw new UnreadableSettingsError("search settings");
  return parseSearchSettings(raw);
}

// src/data/lookback.ts
var LOOKBACK_KEY = "state/lookback";
var LOOKBACK_DATASET = "default_metrics";
var CLAIM_MS = 5 * 6e4;
var SKEW_MS = 5 * 6e4;
var LAKE_LAG_MS = 10 * 6e4;
var OVERLAP_MS = LAKE_LAG_MS + 5 * 6e4;
function parseLookbackState(raw) {
  const o = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : void 0;
  if (!o || o.version !== 1 || typeof o.at !== "number" || typeof o.dataset !== "string" || typeof o.days !== "number" || !o.last || typeof o.last !== "object")
    return void 0;
  const last = {};
  for (const [k, v] of Object.entries(o.last))
    if (typeof v === "number" && Number.isFinite(v) && k.includes("/"))
      last[k] = v;
  return {
    version: 1,
    at: o.at,
    dataset: o.dataset,
    days: o.days,
    last,
    ...typeof o.failedAt === "number" ? { failedAt: o.failedAt, error: typeof o.error === "string" ? o.error : "The look-back failed." } : {},
    ...typeof o.startedAt === "number" ? { startedAt: o.startedAt } : {}
  };
}
var fits = (s, days) => s !== void 0 && s.dataset === LOOKBACK_DATASET && s.days === days;
function usableLookback(s, days) {
  return fits(s, days) && s.at > 0 ? s : void 0;
}
function coveredFrom(model) {
  const sw = model.windowSeconds * 1e3;
  const i = model.buckets.findIndex((_, j) => model.sources.some((s) => (s.eventsSeries[j] ?? 0) > 0));
  const fromSeries = i >= 0 ? model.buckets[i] + sw : model.generatedAt;
  const fromRecent = model.recentAvailable && model.recentBuckets.length ? model.recentBuckets[0] : model.generatedAt;
  return Math.min(fromSeries, fromRecent);
}
function lookbackApplies(model, state) {
  return state !== void 0 && state.at > 0 && state.at - LAKE_LAG_MS >= coveredFrom(model);
}
function applyLookback(model, state) {
  if (!lookbackApplies(model, state) || Object.keys(state.last).length === 0)
    return model;
  const byName = /* @__PURE__ */ new Map();
  for (const s of model.sources) {
    if (s.token)
      continue;
    const k = byName.get(s.group) ?? /* @__PURE__ */ new Map();
    k.set(`${s.type}:${s.sourceId}`, s);
    k.set(criblInput(s.type, s.sourceId), s);
    byName.set(s.group, k);
  }
  const lastBy = /* @__PURE__ */ new Map();
  for (const [key, at] of Object.entries(state.last)) {
    const i = key.indexOf("/");
    const names = byName.get(key.slice(0, i));
    if (!names)
      continue;
    const r = resolveKey(key.slice(i + 1), new Set(names.keys()));
    const s = r ? names.get(r.base) : void 0;
    if (s)
      lastBy.set(s.id, Math.max(lastBy.get(s.id) ?? 0, at));
  }
  let changed = false;
  const sources = model.sources.map((s) => {
    const at = lastBy.get(s.id);
    const judged = s.lastSeen !== void 0 && s.status !== "nodata";
    if (at === void 0 || s.disabled || s.status === "untracked" || judged || at > model.generatedAt)
      return s;
    changed = true;
    if (s.lastSeen !== void 0 && s.lastSeen > at) {
      const end = Math.min(s.lastSeen + (s.lastSeenResolutionSeconds ?? 60) * 1e3, model.generatedAt - 24 * 60 * 6e4);
      const silent = model.generatedAt - end;
      return { ...s, silentMs: silent, status: silent > s.allowanceMs ? "overdue" : "active" };
    }
    const silentMs = model.generatedAt - at;
    return { ...s, lastSeen: at, lastSeenResolutionSeconds: 60, silentMs, lastSeenFromSearch: true, status: silentMs > s.allowanceMs ? "overdue" : "active" };
  });
  return changed ? { ...model, sources } : model;
}

// src/data/collectorAlerts.ts
var COLLECTOR_RUNS_KEY = "state/collector-runs";
var FRESH_FAILURE_MS = 15 * 6e4;
var STATUS_SPAN_MS2 = 24 * 36e5;
function pastAllowance2(row, now = Date.now(), long) {
  if (row.status === "untracked" || row.status === "disabled" || row.snoozedUntil !== void 0)
    return void 0;
  if (row.status === "unknown" || row.status === "nodata" && row.allowanceMs > STATUS_SPAN_MS2) {
    if (row.allowanceMs <= STATUS_SPAN_MS2 || !long)
      return void 0;
    if (long.eventsAt !== void 0)
      return now - long.eventsAt > row.allowanceMs;
    return long.from !== void 0 && now - long.from >= row.allowanceMs ? true : void 0;
  }
  if (row.status === "nodata")
    return true;
  return row.status === "overdue";
}
var rec2 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
function parseCollectorRunState(raw) {
  const seen = {};
  for (const [k, v] of Object.entries(rec2(rec2(raw)?.seen) ?? {})) {
    const o = rec2(v);
    if (!o)
      continue;
    const entry = {
      ...typeof o.job === "string" && typeof o.failed === "boolean" ? { job: o.job, failed: o.failed, ...o.alerted === true ? { alerted: true } : {} } : {},
      ...typeof o.overdue === "boolean" ? { overdue: o.overdue } : {},
      ...o.overdueSent === true ? { overdueSent: true } : {},
      ...typeof o.lastEventAt === "number" && Number.isFinite(o.lastEventAt) ? { lastEventAt: o.lastEventAt } : {}
    };
    if (Object.keys(entry).length)
      seen[k] = entry;
  }
  return { seen };
}
var latestSettled = (runs) => runs?.find((r) => r.jobId.includes(".scheduled.") && (runOutcome(r) === "succeeded" || runOutcome(r) === "failed"));
var failure = (r) => r.failedTasks ? `run failed, ${formatInt(r.failedTasks)} of ${formatInt(r.tasks ?? r.failedTasks)} ${r.tasks === 1 ? "task" : "tasks"} failed` : r.reason ? `run failed: ${r.reason.slice(0, 160)}` : "run failed";
function collectorLink(settings, row) {
  const g = encodeURIComponent(row.group);
  if (!row.collector)
    return settings.linkBase ? `${settings.linkBase}/stream/m/${g}/inputs/${encodeURIComponent(row.type)}/${encodeURIComponent(row.sourceId)}` : `${row.group} \u203A ${row.type}:${row.sourceId}`;
  if (!settings.linkBase)
    return `${row.group} \u203A collection:${row.sourceId}`;
  return `${settings.linkBase}/stream/m/${g}/inputs/collectors/${encodeURIComponent(row.collector.kind)}/${encodeURIComponent(row.sourceId)}`;
}
function nextCollectorAlerts(state, chosen, latest, settings, now, readable = true, long = /* @__PURE__ */ new Map()) {
  const seen = {};
  const rows = {};
  for (const c of chosen) {
    const prev = state.seen[c.row.id] ?? {};
    const next = { ...prev };
    const snoozed = c.row.snoozedUntil !== void 0;
    const link = collectorLink(settings, c.row);
    const description = descriptionFor(settings, c.part?.sourceRowId ?? c.row.id);
    const queue = (status, detail, job) => {
      if (snoozed)
        return;
      (rows[c.searchId] ??= []).push({
        rowId: c.row.id,
        kind: c.part ? "part" : "collector",
        status,
        ...job ? { job } : {},
        ...description ? { description: description.split(SOURCE_LINK).join(link) } : {},
        token: "",
        source: c.part ? `${c.row.type}:${c.row.sourceId} \u203A ${c.part.label}` : `collection:${c.row.sourceId}`,
        group: c.row.group,
        detail,
        link: /^https?:/.test(link) ? link : "",
        at: now
      });
    };
    const run = latest.get(c.row.id);
    let runBack = false;
    if (run && prev.job !== run.jobId) {
      const failed = runOutcome(run) === "failed";
      next.job = run.jobId;
      next.failed = failed;
      if (failed) {
        const alreadyAlerted = prev.failed === true && prev.alerted === true;
        const fresh = now - (run.finishedAt ?? run.at ?? 0) <= FRESH_FAILURE_MS;
        const send = !snoozed && !alreadyAlerted && (prev.job !== void 0 || fresh);
        if (send)
          queue("Failed", failure(run), run.jobId);
        if (alreadyAlerted || send)
          next.alerted = true;
        else
          delete next.alerted;
      } else {
        if (prev.failed && prev.alerted) {
          queue("Back", "Back, a run succeeded", run.jobId);
          runBack = true;
        }
        delete next.alerted;
      }
    }
    const lv = long.get(c.row.id);
    if (lv?.eventsAt !== void 0 && lv.eventsAt > (prev.lastEventAt ?? 0))
      next.lastEventAt = lv.eventsAt;
    const past = readable && !c.part ? pastAllowance2(c.row, now, lv ? { ...lv, eventsAt: lv.eventsAt ?? prev.lastEventAt } : prev.lastEventAt !== void 0 ? { eventsAt: prev.lastEventAt } : void 0) : void 0;
    if (past !== void 0) {
      const held = next.failed && next.alerted || runBack;
      if (past && !prev.overdue) {
        if (!held) {
          next.overdue = true;
          queue("Overdue", `Overdue, no events for longer than its ${formatDuration(c.row.allowanceMs)} allowance`);
          if (!snoozed)
            next.overdueSent = true;
        }
      } else if (!past && prev.overdue) {
        next.overdue = false;
        if (prev.overdueSent && !runBack)
          queue("Back", "Back, collecting again");
        delete next.overdueSent;
      } else
        next.overdue = past;
    }
    if (Object.keys(next).length)
      seen[c.row.id] = next;
  }
  return { state: { seen }, rows };
}
async function runCollectorAlerts(t, model, settings, now, readable = false, unreadGroups = [], share) {
  const done = [];
  const failed = [];
  if (!model || !settings)
    return { done, failed };
  const chosen = chosenCollectors(model, settings);
  const pulls = "sources" in model ? chosenPullSources(model, settings) : [];
  const stored = parseCollectorRunState(await kvRead(t, COLLECTOR_RUNS_KEY));
  if (chosen.length === 0 && pulls.length === 0 && Object.keys(stored.seen).length === 0)
    return { done, failed };
  const latest = /* @__PURE__ */ new Map();
  const groups = [.../* @__PURE__ */ new Set([...chosen.map((c) => c.row.group), ...pulls.map((p) => p.source.group)])];
  const jobsByGroup = await readJobs(t, groups);
  for (const group of groups) {
    try {
      const got = await groupJobs(t, group, jobsByGroup, true);
      if ("error" in got)
        throw new Error(got.error);
      const payload = got.payload;
      const runs = collectorRuns(payload);
      for (const c of chosen)
        if (c.row.group === group)
          latest.set(c.row.id, latestSettled(runs.get(c.row.sourceId)));
      const byPull = pullRuns(payload);
      for (const p of pulls) {
        if (p.source.group !== group)
          continue;
        for (const [key, partRuns] of byPull.get(p.source.sourceId)?.parts ?? []) {
          const id = `${p.source.id}~${key}`;
          chosen.push({ row: { ...p.source, id, status: "unknown", part: { key, parentId: p.source.id } }, deliveryKey: p.deliveryKey, searchId: p.searchId, part: { key, label: key.replace(/_/g, " "), sourceRowId: p.source.id } });
          latest.set(id, latestSettled(partRuns));
        }
      }
    } catch (err) {
      failed.push(`collector runs in ${group}: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
  const long = /* @__PURE__ */ new Map();
  const longOnes = chosen.filter((c) => !c.part && c.row.allowanceMs > STATUS_SPAN_MS2 && (c.row.status === "unknown" || c.row.status === "nodata"));
  if (readable && longOnes.length) {
    try {
      const groups2 = [...new Set(longOnes.map((c) => c.row.group))];
      const r = await apiQuery(t, "/system/metrics/query", collectorSignalsQuery(groups2, now));
      const rows = r.results ?? [];
      const signals = collectorSignals(rows);
      let from = now;
      for (const x of rows)
        from = Math.min(from, rowTime(x) ?? now);
      for (const c of longOnes)
        long.set(c.row.id, { eventsAt: signals.get(`${c.row.group}/${c.row.sourceId}`)?.eventsAt, ...rows.length ? { from } : {} });
    } catch (err) {
      failed.push(`collector hourly metrics: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
  const next = nextCollectorAlerts(stored, chosen, latest, settings, now, readable, long);
  const alertingIds = new Set(settings.enabled ? settings.alerting : []);
  const unread = new Set(unreadGroups);
  for (const [id, v] of Object.entries(stored.seen)) {
    if (id in next.state.seen)
      continue;
    const notLooked = model.collectors === void 0 || unread.has(id.slice(0, id.indexOf("/")));
    const keep = id.includes("~") ? alertingIds.has(id.slice(0, id.indexOf("~"))) : notLooked && alertingIds.has(id);
    if (keep)
      next.state.seen[id] = v;
  }
  if (JSON.stringify(next.state) === JSON.stringify(stored))
    return { done, failed };
  try {
    await kvWrite(t, COLLECTOR_RUNS_KEY, next.state);
  } catch (err) {
    failed.push(`collector alerts: couldn't record them (${err instanceof Error ? err.message : String(err)}), so nothing was queued`);
    return { done, failed };
  }
  if (Object.keys(next.rows).length === 0)
    return { done, failed };
  try {
    const read = await readQueue(t, share);
    if (!read)
      throw new Error("the stored alert queue couldn't be read");
    const queue = copyQueue(read);
    for (const [id, rows] of Object.entries(next.rows)) {
      const waiting = queue.pending[id] ??= [];
      for (const r of rows) {
        if (waiting.some((w) => w.rowId === r.rowId && w.job === r.job && w.status === r.status))
          continue;
        const opposite = r.job === void 0 ? waiting.findIndex((w) => w.rowId === r.rowId && w.job === void 0 && w.status !== r.status) : -1;
        if (opposite >= 0)
          waiting.splice(opposite, 1);
        else
          waiting.push(r);
      }
      if (waiting.length === 0)
        delete queue.pending[id];
    }
    await kvWriteLarge(t, TOKEN_ALERTS_KEY, queue);
    if (share)
      share.queue = queue;
    for (const rows of Object.values(next.rows))
      for (const r of rows)
        done.push(`queued ${r.source} in ${r.group}: ${r.detail}`);
  } catch (err) {
    failed.push(`collector alerts: couldn't queue them (${err instanceof Error ? err.message : String(err)})`);
    await kvWrite(t, COLLECTOR_RUNS_KEY, stored).catch(() => failed.push("collector alerts: couldn't put the old record back; this change may not be sent"));
  }
  return { done, failed };
}

// src/data/volume.ts
var VOLUME_SPAN_MS = 60 * 6e4;
var MIN_USUAL_PER_HOUR = 10;
var MIN_HISTORY_DAYS = 2;
var HISTORY_DAYS = 5;
function lastHourWindows(model) {
  const rb = model.recentBuckets;
  const rw = model.recentWindowSeconds * 1e3;
  if (!model.recentAvailable || rb.length < 2 || rw <= 0)
    return void 0;
  const to = rb.length - (rw < 2 * 6e4 ? 2 : 1);
  const k = Math.round(VOLUME_SPAN_MS / rw);
  const from = to - k;
  if (from < 0)
    return void 0;
  return { from, to, start: rb[from], end: rb[to] };
}
function lastHourOf(s, w) {
  if (s.recentEvents.length < w.to)
    return void 0;
  let events = 0;
  let bytes = 0;
  for (let i = w.from; i < w.to; i++) {
    events += s.recentEvents[i] ?? 0;
    bytes += s.recentBytes[i] ?? 0;
  }
  return { events, bytes };
}
var HOUR = 36e5;
function blendHours(byHour, start, end) {
  let events = 0;
  let bytes = 0;
  let days = Infinity;
  for (let h = Math.floor(start / HOUR) * HOUR; h < end; h += HOUR) {
    const u = byHour.get(h);
    if (!u)
      return void 0;
    const share = (Math.min(end, h + HOUR) - Math.max(start, h)) / HOUR;
    events += u.events * share;
    bytes += u.bytes * share;
    days = Math.min(days, u.days ?? Infinity);
  }
  return { events: events * HOUR / (end - start), bytes: bytes * HOUR / (end - start), days: Number.isFinite(days) ? days : 0 };
}
var MIN_FLAT_HOURS = 3;
var flatUsual = (s) => s.day && s.day.hours >= MIN_FLAT_HOURS ? { events: s.day.events / s.day.hours, bytes: s.day.bytes / s.day.hours } : void 0;
var noiseShare = (usualEvents) => usualEvents > 0 ? 3 / Math.sqrt(usualEvents) : Infinity;
function volumeOf(model, s, settings, history) {
  const pct = volumePctFor(settings, s.id);
  if (s.disabled || s.status === "untracked" || s.collector || s.pull || s.token || s.part || pct <= 0)
    return { state: "off", pct };
  const w = lastHourWindows(model);
  const now = w && lastHourOf(s, w);
  if (!w || !now)
    return { state: "unknown", pct };
  let run = 0;
  let longest = 0;
  for (let i = w.from; i < w.to; i++)
    longest = Math.max(longest, run = (s.recentEvents[i] ?? 0) > 0 ? 0 : run + 1);
  if (longest * model.recentWindowSeconds * 1e3 > s.allowanceMs)
    return { state: "unknown", pct, silence: true };
  let usual;
  let basis;
  if (settings.volume.method === "sameKindOfDay" && history) {
    const byHour = history.rows.get(s.id);
    const blended = byHour && blendHours(byHour, w.start, w.end);
    if (blended && blended.days >= MIN_HISTORY_DAYS) {
      usual = blended;
      basis = { method: "sameKindOfDay", days: blended.days };
    }
  }
  if (!usual) {
    usual = flatUsual(s);
    basis = { method: "flat24" };
  }
  const base = { pct, events: now.events, bytes: now.bytes, from: w.start, to: w.end };
  if (!usual)
    return { ...base, state: "unknown" };
  const scale = (w.end - w.start) / HOUR;
  const usualEvents = usual.events * scale;
  const usualBytes = usual.bytes * scale;
  const reading = { ...base, basis, usualEvents, usualBytes };
  if (usual.events < MIN_USUAL_PER_HOUR)
    return { ...reading, state: "low" };
  const devEvents = (now.events - usualEvents) / usualEvents;
  const devBytes = usualBytes > 0 ? (now.bytes - usualBytes) / usualBytes : void 0;
  const limit = Math.max(pct / 100, noiseShare(usualEvents));
  const out = [];
  if (Math.abs(devEvents) >= limit)
    out.push("events");
  if (devBytes !== void 0 && Math.abs(devBytes) >= limit)
    out.push("bytes");
  const withDev = { ...reading, devEvents, ...devBytes !== void 0 ? { devBytes } : {} };
  if (out.length === 0)
    return { ...withDev, state: "normal" };
  const dir = out.length === 2 ? Math.abs(devEvents) >= Math.abs(devBytes) ? devEvents : devBytes : out[0] === "events" ? devEvents : devBytes;
  return { ...withDev, out, state: dir < 0 ? "drop" : "spike" };
}
function volumeReadings(model, settings, history) {
  return new Map(model.sources.map((s) => [s.id, volumeOf(model, s, settings, history)]));
}
function formatDeviation(share) {
  const p = Math.round(share * 100);
  return `${p > 0 ? "+" : p < 0 ? "\u2212" : "\xB1"}${Math.abs(p)}%`;
}
function shownMeasure(r) {
  if (r.state !== "drop" && r.state !== "spike" || !r.out?.length)
    return "events";
  const goes = (d) => d !== void 0 && (r.state === "drop" ? d < 0 : d > 0);
  return r.out?.includes("events") && goes(r.devEvents) ? "events" : "bytes";
}

// src/data/volumeHistory.ts
var HOUR2 = 36e5;
var DAY = 24 * HOUR2;
var RING_DAYS = 14;
var RING_HOURS = RING_DAYS * 24;
var RECORD_LAG_MS = 5 * 6e4;
var MAX_RECORD_PER_RUN = 2;
var MAX_HOUR_READS = 8;
var SUMMARY_KEY = "vol/summary";
var piecesOf = (value) => Math.max(1, Math.ceil(JSON.stringify(value).replace(/[\u007f-\uffff]/g, "______").length / 85e3));
async function readSummary(t, now) {
  const read = await readShards(t, SUMMARY_KEY);
  const summary = read.state === "ok" ? parseSummary(read.value) : void 0;
  return { read, ...summary && String(Math.floor(now / HOUR2) * HOUR2) in summary.hours ? { inUse: summary } : {} };
}
var IDS_KEY = "vol/ids";
var hourKey = (hour) => `vol/hours/${Math.floor(hour / HOUR2) % RING_HOURS}`;
async function readIds(t, signal) {
  try {
    const v = await kvReadLarge(t, IDS_KEY, signal);
    if (v === void 0)
      return { state: "absent" };
    return v === UNREADABLE_VALUE || !isObj3(v) ? { state: "bad" } : { state: "ok", value: v, stamp: "" };
  } catch (err) {
    if (signal?.aborted)
      throw err;
    return { state: "failed", reason: err instanceof Error ? err.message : String(err) };
  }
}
var writeIds = (t, doc) => kvWriteLarge(t, IDS_KEY, doc);
var isObj3 = (v) => Boolean(v) && typeof v === "object" && !Array.isArray(v);
var weekdayFormats = /* @__PURE__ */ new Map();
function isWeekend(at, timeZone = "UTC") {
  let f = weekdayFormats.get(timeZone);
  if (!f) {
    try {
      f = new Intl.DateTimeFormat("en-US", { timeZone, weekday: "short" });
    } catch {
      f = new Intl.DateTimeFormat("en-US", { timeZone: "UTC", weekday: "short" });
    }
    weekdayFormats.set(timeZone, f);
  }
  const d = f.format(at);
  return d === "Sat" || d === "Sun";
}
var hourFormats = /* @__PURE__ */ new Map();
function localHour(at, timeZone) {
  let f = hourFormats.get(timeZone);
  if (!f) {
    try {
      f = new Intl.DateTimeFormat("en-US", { timeZone, hour: "numeric", hourCycle: "h23" });
    } catch {
      f = new Intl.DateTimeFormat("en-US", { timeZone: "UTC", hour: "numeric", hourCycle: "h23" });
    }
    hourFormats.set(timeZone, f);
  }
  return Number(f.format(at)) % 24;
}
function sameKindHours(hour, timeZone) {
  const weekend = isWeekend(hour, timeZone);
  const local = timeZone ? localHour(hour, timeZone) : 0;
  const out = [];
  for (let k = 1; k < RING_DAYS; k++) {
    let h = hour - k * DAY;
    if (timeZone) {
      let shift = local - localHour(h, timeZone);
      if (shift > 12)
        shift -= 24;
      if (shift < -12)
        shift += 24;
      h += shift * HOUR2;
    }
    if (h < hour && isWeekend(h, timeZone) === weekend)
      out.push(h);
  }
  return out;
}
function prefixPrints(ids) {
  const out = [""];
  let acc = "";
  for (const id of ids) {
    acc = fingerprint(`${acc}\0${id}`);
    out.push(acc);
  }
  return out;
}
function parseHour(v, hour, prints) {
  if (!isObj3(v) || v.v !== 1 || v.hour !== hour || typeof v.n !== "number" || typeof v.h !== "string" || !Array.isArray(v.e) || !Array.isArray(v.b))
    return void 0;
  if (v.n > prints.length - 1 || prints[v.n] !== v.h || v.e.length !== v.n || v.b.length !== v.n)
    return void 0;
  return v;
}
var recorded = (s) => !s.disabled && !s.collector && !s.pull && !s.token && !s.part && !s.sourceGroup;
function hourTotals(model, hour) {
  const w = model.windowSeconds * 1e3;
  if (w <= 0 || HOUR2 % w !== 0)
    return void 0;
  const idx = model.buckets.map((b, i) => [b, i]).filter(([b]) => b >= hour && b < hour + HOUR2).map(([, i]) => i);
  if (idx.length !== HOUR2 / w)
    return void 0;
  const out = /* @__PURE__ */ new Map();
  for (const s of model.sources) {
    if (!recorded(s))
      continue;
    let events = 0;
    let bytes = 0;
    for (const i of idx) {
      events += s.eventsSeries[i] ?? 0;
      bytes += s.bytesSeries[i] ?? 0;
    }
    out.set(s.id, { events, bytes });
  }
  return out;
}
var median = (xs) => {
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
};
function usualFor(ids, hours) {
  const out = /* @__PURE__ */ new Map();
  const used = hours.filter((h) => h !== void 0);
  for (let i = 0; i < ids.length; i++) {
    const e = [];
    const b = [];
    for (const h of used) {
      if (e.length >= HISTORY_DAYS)
        break;
      if (i < h.n && h.e[i] >= 0) {
        e.push(h.e[i]);
        b.push(h.b[i] >= 0 ? h.b[i] : 0);
      }
    }
    if (e.length)
      out.set(ids[i], { events: median(e), bytes: median(b), days: e.length });
  }
  return out;
}
function parseSummary(v) {
  if (!isObj3(v) || v.v !== 1 || typeof v.at !== "number" || typeof v.recorded !== "number" || !isObj3(v.hours) || !Array.isArray(v.ids))
    return void 0;
  const n = v.ids.length;
  if (!v.ids.every((x) => typeof x === "string") || !Object.values(v.hours).every((h) => Array.isArray(h) && h.length === 3 * n))
    return void 0;
  return v;
}
function usualFromSummary(summary, model) {
  const rows = /* @__PURE__ */ new Map();
  for (const [hourKeyText, flat] of Object.entries(summary.hours)) {
    const hour = Number(hourKeyText);
    if (!Number.isFinite(hour))
      continue;
    for (let i = 0; i < summary.ids.length; i++) {
      const [events, bytes, days] = [flat[3 * i], flat[3 * i + 1], flat[3 * i + 2]];
      if (!(days > 0) || !Number.isFinite(events) || !Number.isFinite(bytes))
        continue;
      const id = summary.ids[i];
      let m = rows.get(id);
      if (!m)
        rows.set(id, m = /* @__PURE__ */ new Map());
      m.set(hour, { events, bytes, days });
    }
  }
  for (const g of model?.sources.filter((s) => s.sourceGroup) ?? []) {
    const members = (model.members ?? []).filter((m) => m.memberOf === g.id && !m.disabled && m.status !== "untracked");
    if (members.length === 0)
      continue;
    const hours = new Set(members.flatMap((m) => [...rows.get(m.id)?.keys() ?? []]));
    const out = /* @__PURE__ */ new Map();
    for (const h of hours) {
      const each = members.map((m) => rows.get(m.id)?.get(h));
      if (each.some((u) => u === void 0))
        continue;
      out.set(h, { events: each.reduce((n, u) => n + u.events, 0), bytes: each.reduce((n, u) => n + u.bytes, 0), days: Math.min(...each.map((u) => u.days)) });
    }
    rows.set(g.id, out);
  }
  return { rows, at: summary.at };
}
async function runVolumeHistory(t, model, settings, now, write = true, callsLeft, reserve = 0, preread) {
  const affords = (calls) => !callsLeft || callsLeft() - calls >= reserve;
  const done = [];
  const failed = [];
  const current = Math.floor(now / HOUR2) * HOUR2;
  const wanted = [current - 2 * HOUR2, current - HOUR2, current, current + HOUR2];
  const stored = preread ?? await readShards(t, SUMMARY_KEY);
  if (stored.state === "failed")
    return { done, failed: [`volume history: the summary couldn't be read (${stored.reason})`] };
  const summary = stored.state === "ok" ? parseSummary(stored.value) : void 0;
  if (!write)
    return { done, failed, summary: summary && String(current) in summary.hours ? summary : void 0 };
  const tz = settings.volume.timeZone;
  const firstHour = model.buckets.length ? Math.ceil(model.buckets[0] / HOUR2) * HOUR2 : current;
  const due = [];
  for (let h = Math.max(firstHour, (summary?.recorded ?? -Infinity) + HOUR2); h + HOUR2 + RECORD_LAG_MS <= now && due.length < MAX_RECORD_PER_RUN; h += HOUR2)
    due.push(h);
  const covered = summary !== void 0 && summary.timeZone === tz && wanted.every((h) => String(h) in summary.hours);
  if (due.length === 0 && covered)
    return { done, failed, summary };
  const listSize = summary?.ids.length ?? model.sources.length;
  const listCalls = piecesOf({ ids: summary?.ids ?? model.sources.map((s) => s.id) });
  const hourCalls = piecesOf({ e: new Array(listSize).fill(999999), b: new Array(listSize).fill(999999999) });
  const summaryCalls = summary ? piecesOf(summary) : piecesOf({ ids: model.sources.map((s) => s.id), hours: wanted.map(() => new Array(3 * listSize).fill(99999)) });
  if (!affords(2 * listCalls + due.length * hourCalls + summaryCalls))
    return { done, failed, summary: summary && String(current) in summary.hours ? summary : void 0 };
  const idsRead = await readIds(t);
  if (idsRead.state === "failed")
    return { done, failed: [`volume history: the Source list couldn't be read (${idsRead.reason})`], summary: covered ? summary : void 0 };
  const ids = idsRead.state === "ok" && isObj3(idsRead.value) && Array.isArray(idsRead.value.ids) && idsRead.value.ids.every((x) => typeof x === "string") ? [...idsRead.value.ids] : [];
  const filledFrom = idsRead.state === "ok" && isObj3(idsRead.value) && typeof idsRead.value.from === "number" ? idsRead.value.from : void 0;
  const listFirst = idsRead.state === "ok" && isObj3(idsRead.value) && typeof idsRead.value.first === "number" ? idsRead.value.first : void 0;
  if (idsRead.state === "bad")
    failed.push("volume history: the stored Source list was unreadable, so the history starts again");
  if (stored.state === "bad")
    failed.push("volume history: the usual volumes were unreadable (a write cut short), so they are made again");
  const index = new Map(ids.map((id, i) => [id, i]));
  const before = ids.length;
  const records = [];
  let recordedTo = summary?.recorded ?? -Infinity;
  for (const h of due) {
    const totals = hourTotals(model, h);
    if (!totals)
      break;
    for (const id of totals.keys())
      if (!index.has(id))
        index.set(id, ids.push(id) - 1);
    records.push({ v: 1, hour: h, n: 0, h: "", e: [], b: [] });
    const r = records[records.length - 1];
    r.e = new Array(ids.length).fill(-1);
    r.b = new Array(ids.length).fill(-1);
    for (const [id, v] of totals) {
      r.e[index.get(id)] = v.events;
      r.b[index.get(id)] = Math.round(v.bytes);
    }
  }
  const prints = prefixPrints(ids);
  for (const r of records) {
    while (r.e.length < ids.length) {
      r.e.push(-1);
      r.b.push(-1);
    }
    r.n = ids.length;
    r.h = prints[ids.length];
  }
  const recordedFirst = idsRead.state === "ok" ? summary?.first ?? listFirst ?? records[0]?.hour : records[0]?.hour;
  try {
    if (ids.length !== before || idsRead.state !== "ok" || recordedFirst !== void 0 && listFirst !== recordedFirst) {
      await writeIds(t, { ids, ...filledFrom !== void 0 ? { from: filledFrom } : {}, ...recordedFirst !== void 0 ? { first: recordedFirst } : {} });
    }
    for (const r of records) {
      if (!affords(piecesOf(r) + summaryCalls))
        break;
      await writeShards(t, hourKey(r.hour), r);
      recordedTo = r.hour;
    }
    if (records.length)
      done.push(`volume history: recorded ${records.length === 1 ? `the hour from ${new Date(records[0].hour).toISOString().slice(11, 16)} UTC` : `${records.length} hours`}`);
  } catch (err) {
    failed.push(`volume history: couldn't record (${err instanceof Error ? err.message : String(err)})`);
  }
  const sameIds = summary !== void 0 && summary.ids.length <= ids.length && summary.ids.every((id, i) => ids[i] === id);
  const keep = summary && summary.timeZone === tz && sameIds ? summary.hours : {};
  const pad = new Array(sameIds ? 3 * (ids.length - summary.ids.length) : 0).fill(0);
  const hours = {};
  const need = wanted.filter((h) => !(String(h) in keep));
  for (const h of wanted)
    if (String(h) in keep)
      hours[String(h)] = pad.length ? [...keep[String(h)], ...pad] : keep[String(h)];
  const first = filledFrom !== void 0 && recordedFirst !== void 0 ? Math.min(filledFrom, recordedFirst) : recordedFirst ?? filledFrom;
  const held = (h) => first !== void 0 && h >= first && h <= recordedTo;
  const byHour = new Map(records.map((r) => [r.hour, r]));
  let budget = MAX_HOUR_READS;
  for (const h of [current, current - HOUR2, current + HOUR2, current - 2 * HOUR2].filter((x) => need.includes(x))) {
    const from = sameKindHours(h, tz).filter(held).slice(0, HISTORY_DAYS);
    const toRead = from.filter((x) => !byHour.has(x));
    if (toRead.length > budget || !affords(toRead.length * hourCalls + summaryCalls))
      break;
    budget -= toRead.length;
    const read = await Promise.all(toRead.map(async (x) => [x, await readShards(t, hourKey(x)).then((r) => r.state === "ok" ? parseHour(r.value, x, prints) : void 0)]));
    for (const [x, r] of read)
      byHour.set(x, r);
    const usual = usualFor(ids, from.map((x) => byHour.get(x)));
    hours[String(h)] = ids.flatMap((id) => {
      const u = usual.get(id);
      return u ? [Math.round(u.events * 10) / 10, Math.round(u.bytes), u.days] : [0, 0, 0];
    });
  }
  const next = { v: 1, at: now, recorded: Number.isFinite(recordedTo) ? recordedTo : firstHour - HOUR2, ...recordedFirst !== void 0 ? { first: recordedFirst } : {}, ...tz ? { timeZone: tz } : {}, ids, hours };
  if (!affords(piecesOf(next)))
    return { done, failed, summary: summary && String(current) in summary.hours ? summary : void 0 };
  try {
    await writeShards(t, SUMMARY_KEY, next);
  } catch (err) {
    failed.push(`volume history: couldn't store the usual volumes (${err instanceof Error ? err.message : String(err)})`);
  }
  return { done, failed, summary: next };
}

// src/data/monitorAlerts.ts
var MONITOR_KEY = "state/monitor-alerts";
var SUSTAIN_MS = 5 * 6e4;
var GAP_MS = 3 * 6e4;
var ALERTED_KEPT_MS = 60 * 6e4;
var REFRESH_MS = 10 * 6e4;
var keptMs = (v) => v.alerted ? ALERTED_KEPT_MS + REFRESH_MS : GAP_MS;
var rec3 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
var num3 = (v) => typeof v === "number" && Number.isFinite(v) ? v : void 0;
function parseMonitorState(raw) {
  const seen = {};
  for (const [k, v] of Object.entries(rec3(rec3(raw)?.seen) ?? {})) {
    const o = rec3(v);
    if (!o || !/~(health|volume|group)$/.test(k))
      continue;
    const s = {};
    if (num3(o.since) !== void 0)
      s.since = num3(o.since);
    if (num3(o.last) !== void 0)
      s.last = num3(o.last);
    if (o.alerted === true)
      s.alerted = true;
    if (num3(o.okSince) !== void 0)
      s.okSince = num3(o.okSince);
    if (num3(o.kept) !== void 0)
      s.kept = num3(o.kept);
    seen[k] = s;
  }
  return { seen };
}
function observe(c, model, readings) {
  const s = c.row;
  if (s.snoozedUntil !== void 0)
    return void 0;
  if (c.kind === "volume" && readings.get(s.id)?.state === "off")
    return { forget: true };
  if (c.kind === "health") {
    if (!model.healthAvailable || s.health === void 0)
      return void 0;
    return s.health === "error" ? { out: true, detail: "Unhealthy: Cribl has reported it red (error) for 5 minutes" } : { out: false };
  }
  if (c.kind === "group") {
    if (s.status === "overdue" || s.status === "nodata") {
      const n = s.sourceGroup?.members.length ?? 0;
      return { out: true, detail: `Overdue: no events from any of its ${formatInt(n)} ${plural(n, "Source")} for longer than its ${formatDuration(s.allowanceMs)} allowance` };
    }
    return s.status === "active" ? { out: false } : void 0;
  }
  if (s.status === "overdue" || s.status === "nodata")
    return void 0;
  const r = readings.get(s.id);
  if (!r)
    return void 0;
  if (r.state === "normal")
    return { out: false };
  if (r.state === "off")
    return { forget: true };
  if (r.state !== "drop" && r.state !== "spike")
    return void 0;
  const measure = shownMeasure(r);
  const dev = measure === "events" ? r.devEvents : r.devBytes;
  const now = measure === "events" ? r.events : r.bytes;
  const usual = measure === "events" ? r.usualEvents : r.usualBytes;
  const amount = (v) => measure === "events" ? `${formatInt(Math.round(v))} events` : `${formatInt(Math.round(v))} bytes`;
  const basis = r.basis?.method === "sameKindOfDay" ? "this hour on recent days like today" : "the last 24 hours";
  return { out: true, detail: `Volume ${r.state}: ${formatDeviation(dev)} ${measure} in the last hour (${amount(now)}, usually about ${amount(usual)} from ${basis}; threshold \xB1${r.pct}%)` };
}
var BACK = { health: "Back: healthy again", volume: "Back: volume near its usual again", group: "Back, sending again" };
var STATUS = { health: "Unhealthy", volume: "Volume", group: "Overdue" };
function nextMonitorAlerts(state, chosen, model, readings, settings, now, readable, unreadGroups = []) {
  const stillChosen = (v) => v.alerted && now - Math.max(v.last ?? 0, v.kept ?? 0) >= REFRESH_MS ? { ...v, kept: now } : v;
  const seen = {};
  const rows = {};
  const linkBase = linkBaseFor(settings);
  const handled = /* @__PURE__ */ new Set();
  for (const c of chosen) {
    const key = `${c.row.id}~${c.kind}`;
    handled.add(key);
    const stored = state.seen[key];
    const keptAt = Math.max(stored?.last ?? 0, stored?.kept ?? 0);
    const prev = stored && now - keptAt <= keptMs(stored) ? stored : void 0;
    const o = readable ? observe(c, model, readings) : void 0;
    if (!o) {
      if (prev)
        seen[key] = stillChosen(prev);
      continue;
    }
    if ("forget" in o)
      continue;
    const queue = (status, detail) => (rows[c.searchId] ??= []).push({
      rowId: key,
      status,
      kind: c.kind,
      token: "",
      source: c.row.sourceGroup ? c.row.name : criblInput(c.row.type, c.row.sourceId),
      group: c.row.sourceGroup ? c.row.sourceGroup.groups.join(", ") : c.row.group,
      detail,
      link: c.row.sourceGroup ? "" : sourceLink(linkBase, c.row),
      at: now
    });
    const sustain = c.kind === "group" ? 0 : SUSTAIN_MS;
    if (o.out) {
      if (prev?.alerted && prev.okSince === void 0 && prev.last !== void 0 && now - prev.last < REFRESH_MS) {
        seen[key] = prev;
        continue;
      }
      const running = prev?.since !== void 0 && prev.last !== void 0 && now - prev.last <= GAP_MS;
      const next = { since: running ? prev.since : now, last: now, ...prev?.alerted ? { alerted: true } : {} };
      if (!next.alerted && now - next.since >= sustain) {
        queue(STATUS[c.kind], o.detail);
        next.alerted = true;
      }
      seen[key] = next;
      continue;
    }
    if (!prev?.alerted)
      continue;
    const okRunning = prev.okSince !== void 0 && prev.last !== void 0 && now - prev.last <= GAP_MS;
    const okSince = okRunning ? prev.okSince : now;
    if (c.kind === "volume" && now - okSince < SUSTAIN_MS) {
      seen[key] = { ...prev, okSince, last: now };
      continue;
    }
    queue("Back", BACK[c.kind]);
  }
  const lists = { health: settings.health, volume: settings.volume, group: settings.alerting };
  const unread = new Set(unreadGroups);
  for (const [key, v] of Object.entries(state.seen)) {
    if (handled.has(key) || settings.enabled === false)
      continue;
    const at = key.lastIndexOf("~");
    const id = key.slice(0, at);
    const list = lists[key.slice(at + 1)];
    if (!list?.includes(id) || now - Math.max(v.last ?? 0, v.kept ?? 0) > keptMs(v))
      continue;
    seen[key] = unread.has(rowScope(id)?.group ?? "") ? stillChosen(v) : v;
  }
  return { state: { seen }, rows };
}
async function keepSent(t, settings, now) {
  const raw = await kvReadLarge(t, MONITOR_KEY);
  if (raw === void 0 || raw === UNREADABLE_VALUE)
    return;
  const stored = parseMonitorState(raw);
  const lists = settings && { health: settings.health, volume: settings.volume, group: settings.alerting };
  const seen = { ...stored.seen };
  let changed = false;
  for (const [key, v] of Object.entries(stored.seen)) {
    const at = key.lastIndexOf("~");
    const still = !lists || lists[key.slice(at + 1)]?.includes(key.slice(0, at));
    const age = now - Math.max(v.last ?? 0, v.kept ?? 0);
    if (v.alerted && still && age >= REFRESH_MS && age <= keptMs(v)) {
      seen[key] = { ...v, kept: now };
      changed = true;
    }
  }
  if (changed)
    await kvWriteLarge(t, MONITOR_KEY, { seen });
}
async function runMonitorAlerts(t, model, readings, settings, now, readable, share, unreadGroups = []) {
  const done = [];
  const failed = [];
  const anyChosen = !settings || settings.enabled !== false && (settings.health.length > 0 || settings.volume.length > 0 || settings.alerting.some((id) => id.startsWith(GROUP_ROW_PREFIX)));
  if (!anyChosen)
    return { done, failed };
  if (!model || !settings) {
    await keepSent(t, settings, now).catch((err) => failed.push(`health and volume alerts: couldn't keep their record (${err instanceof Error ? err.message : String(err)})`));
    return { done, failed };
  }
  const chosen = chosenMonitoring(model, settings);
  const raw = await kvReadLarge(t, MONITOR_KEY);
  if (raw === UNREADABLE_VALUE)
    return { done, failed: ["health and volume alerts: their stored record couldn't be read, so they weren't checked this run"] };
  const stored = parseMonitorState(raw);
  const next = nextMonitorAlerts(stored, chosen, model, readings, settings, now, readable, unreadGroups);
  const same = (s) => JSON.stringify(Object.keys(s.seen).sort().map((k) => [k, s.seen[k].since, s.seen[k].last, s.seen[k].alerted, s.seen[k].okSince, s.seen[k].kept]));
  if (same(next.state) === same(stored) && Object.keys(next.rows).length === 0)
    return { done, failed };
  try {
    await kvWriteLarge(t, MONITOR_KEY, next.state);
  } catch (err) {
    failed.push(`health and volume alerts: couldn't record them (${err instanceof Error ? err.message : String(err)}), so nothing was queued`);
    return { done, failed };
  }
  if (Object.keys(next.rows).length === 0)
    return { done, failed };
  try {
    const read = await readQueue(t, share);
    if (!read)
      throw new Error("the stored alert queue couldn't be read");
    const queue = copyQueue(read);
    for (const [id, rows] of Object.entries(next.rows)) {
      const waiting = queue.pending[id] ??= [];
      for (const r of rows) {
        if (waiting.some((w) => w.rowId === r.rowId && w.status === r.status))
          continue;
        const opposite = waiting.findIndex((w) => w.rowId === r.rowId && w.status !== r.status);
        if (opposite >= 0)
          waiting.splice(opposite, 1);
        else
          waiting.push(r);
      }
      if (waiting.length === 0)
        delete queue.pending[id];
    }
    await kvWriteLarge(t, TOKEN_ALERTS_KEY, queue);
    if (share)
      share.queue = queue;
    for (const rows of Object.values(next.rows))
      for (const r of rows)
        done.push(`queued ${r.source} in ${r.group}: ${r.detail}`);
  } catch (err) {
    failed.push(`health and volume alerts: couldn't queue them (${err instanceof Error ? err.message : String(err)})`);
    await kvWriteLarge(t, MONITOR_KEY, stored).catch(() => failed.push("health and volume alerts: couldn't put the old record back; this change may not be sent"));
  }
  return { done, failed };
}

// src/data/armingRun.ts
async function allowancesReadable(t) {
  const res = await t(`/kvstore/${SETTINGS_KEY}`);
  if (res.status === 404)
    return true;
  if (!res.ok)
    return false;
  const text2 = (await res.text()).trim();
  return !text2 || unwrapKvValue(text2) !== void 0;
}
var BACKEND_LISTED_GROUPS = 8;
var BACKEND_MAX_ARMING = 8;
var BACKEND_MAX_SNOOZE = 4;
var message = (err) => err instanceof Error ? err.message : String(err);
var holdNoData = (model) => ({ ...model, sources: model.sources.map((s) => s.status === "nodata" ? { ...s, status: "unknown" } : s) });
async function withLookback(t, model) {
  try {
    const search = await loadSearchSettings(t);
    if (!search.lookbackEnabled)
      return model;
    const state = usableLookback(parseLookbackState(await kvRead(t, LOOKBACK_KEY)), search.lookbackDays);
    return lookbackApplies(model, state) ? applyLookback(model, state) : holdNoData(model);
  } catch {
    return holdNoData(model);
  }
}
var HISTORY_WRITES_AFTER = 4;
var RUN_RECORD_CALLS = 1;
var BACKEND_CALL_LIMIT = 48;
async function runArming(raw, now) {
  const result = { at: now, own: 0, armed: 0, done: [], failed: [] };
  const ctx = {};
  let calls = 0;
  const t = (path, init) => {
    calls++;
    return raw(path, init);
  };
  const share = { callsLeft: () => BACKEND_CALL_LIMIT - calls };
  try {
    await armSources(t, now, result, ctx);
  } catch (err) {
    result.failed.push(`run: ${message(err)}`);
  }
  if (!ctx.alerts && ctx.choices === void 0)
    ctx.choices = await readChoices(t);
  if (ctx.alerts?.tokenSearches)
    share.searches = ctx.alerts.tokenSearches.filter((e) => e.notification).map((e) => e.id);
  share.dropVolume = ctx.thresholds !== void 0 && !volumeChecksOn(ctx.thresholds);
  const settings = ctx.alerts ? ctx.alerts.savedUnreadable ? void 0 : effectiveAlertSettings(ctx.alerts.saved, ctx.alerts.notifications, ctx.model?.sources ?? []).settings : ctx.choices;
  try {
    const runs = await runCollectorAlerts(t, ctx.model, settings, now, ctx.readable === true, ctx.unreadGroups, share);
    result.done.push(...runs.done);
    result.failed.push(...runs.failed);
  } catch (err) {
    result.failed.push(`collector runs: ${message(err)}`);
  }
  let grouped;
  let history;
  let summaryRead;
  if (ctx.model && ctx.thresholds) {
    try {
      const judged = ctx.judged ?? (ctx.thresholds.sourceGroups.length > 0 ? await withLookback(t, ctx.model) : ctx.model);
      grouped = applySourceGroups(judged, ctx.thresholds, ctx.unreadGroups);
    } catch (err) {
      result.failed.push(`health and volume: ${message(err)}`);
    }
    if (grouped && ctx.activityOk && ctx.thresholds && volumeChecksOn(ctx.thresholds)) {
      try {
        summaryRead = await readSummary(t, now);
        history = summaryRead.inUse ? usualFromSummary(summaryRead.inUse, grouped) : void 0;
        if (summaryRead.read.state === "failed")
          result.failed.push(`volume history: the summary couldn't be read (${summaryRead.read.reason})`);
      } catch (err) {
        result.failed.push(`volume history: ${message(err)}`);
      }
    }
  }
  try {
    const readings = grouped && ctx.thresholds ? volumeReadings(grouped, ctx.thresholds, history) : /* @__PURE__ */ new Map();
    const mon = await runMonitorAlerts(t, grouped, readings, settings, now, grouped !== void 0 && ctx.activityOk === true && settings !== void 0, share, ctx.unreadGroups);
    result.done.push(...mon.done);
    result.failed.push(...mon.failed);
  } catch (err) {
    result.failed.push(`health and volume: ${message(err)}`);
  }
  try {
    const sent = await runTokenAlerts(t, grouped ?? ctx.model, settings, now, ctx.readable === true && settings !== void 0, share);
    result.done.push(...sent.done);
    result.failed.push(...sent.failed);
  } catch (err) {
    result.failed.push(`token alerts: ${message(err)}`);
  }
  if (summaryRead && summaryRead.read.state !== "failed" && ctx.model && ctx.thresholds && (ctx.unreadGroups ?? []).length === 0 && (ctx.leaderWrites ?? 0) <= HISTORY_WRITES_AFTER) {
    try {
      const h = await runVolumeHistory(t, ctx.model, ctx.thresholds, now, true, share.callsLeft, RUN_RECORD_CALLS, summaryRead.read);
      result.failed.push(...h.failed);
    } catch (err) {
      result.failed.push(`volume history: ${message(err)}`);
    }
  }
  return result;
}
var readChoices = (t) => kvReadLarge(t, ALERTS_KEY).then((raw) => raw !== void 0 && isAlertSettingsDoc(raw) ? parseAlertSettings(raw) : void 0, () => void 0);
async function armSources(t, now, result, ctx) {
  if (!await allowancesReadable(t)) {
    result.skipped = "saved allowances are unreadable";
    return;
  }
  const settings = await loadSettings(t);
  ctx.thresholds = settings;
  const choices = await readChoices(t);
  if (choices)
    ctx.choices = choices;
  const tokensOn = choices ? choices.enabled && (Object.keys(choices.tokens).length > 0 || choices.alerting.length > 0) : false;
  const { model, groups, unreadGroups, warnings } = await loadActivity(t, rangeFor("24h"), settings, void 0, {}, { perToken: tokensOn, awaitCacheWrite: true, maxListedGroups: BACKEND_LISTED_GROUPS });
  ctx.model = model;
  ctx.unreadGroups = unreadGroups;
  result.done.push(...warnings.filter((w) => w.startsWith("Couldn't list Sources") || w.startsWith("Couldn't read activity")));
  if (!model.recentAvailable) {
    result.skipped = "recent activity unreadable";
    return;
  }
  const enabled = model.sources.filter((s) => !s.disabled);
  const recentSpan = model.recentBuckets.length > 0 ? model.generatedAt - model.recentBuckets[0] : 0;
  const sending = (s) => s.recentEvents.some(Boolean) || s.allowanceMs > recentSpan && s.status === "active";
  if (enabled.length > 0 && !enabled.some(sending)) {
    result.skipped = "no recent events from any Source";
    return;
  }
  ctx.activityOk = true;
  ctx.readable = choices !== void 0;
  const alerts = await loadAlertState(t, groups, void 0, false);
  ctx.alerts = alerts;
  const own = alerts.notifications.filter(isOwnAlert);
  result.own = own.length;
  const state = parseArmState(await kvRead(t, ARM_STATE_KEY));
  if (own.length === 0 && Object.keys(state).length === 0)
    return;
  const paused = parseSnoozePaused(await kvRead(t, SNOOZE_PAUSED_KEY).catch(() => void 0));
  let pausedChanged = false;
  const snooze = planSnooze(own, settings.snoozed, paused, now);
  const snoozeChanges = [...snooze.pause.map((x) => [x, true]), ...snooze.resume.map((x) => [x, false])];
  if (snoozeChanges.length > BACKEND_MAX_SNOOZE)
    result.done.push(`${snoozeChanges.length - BACKEND_MAX_SNOOZE} more snooze changes wait for the next run (at most ${BACKEND_MAX_SNOOZE} a run)`);
  for (const [n, disabled] of snoozeChanges.slice(0, BACKEND_MAX_SNOOZE)) {
    const path = `/m/${encodeURIComponent(n.group)}/notifications/${encodeURIComponent(n.id)}`;
    try {
      const current = parseNotifications(n.group, await apiGet(t, path))[0];
      if (!current || !isOwnAlert(current))
        continue;
      if (current.disabled !== disabled) {
        const rest = disabled && isArmed(current) ? state[n.id]?.restWindow : void 0;
        await apiWrite(t, "PATCH", path, disabledBody(current.raw, disabled, rest));
        ctx.leaderWrites = (ctx.leaderWrites ?? 0) + 1;
        result.done.push(`${disabled ? "pause" : "resume"} ${n.id}: ${n.input} in ${n.group} ${disabled ? "is snoozed" : "is no longer snoozed"}`);
        if (rest)
          delete state[n.id];
      }
      if (disabled)
        paused[n.id] = now;
      else
        delete paused[n.id];
      pausedChanged = true;
      n.disabled = disabled;
    } catch (err) {
      result.failed.push(`${disabled ? "pause" : "resume"} ${n.id}: ${message(err)}`);
    }
  }
  if (pausedChanged)
    await kvWrite(t, SNOOZE_PAUSED_KEY, paused).catch((err) => result.failed.push(`recording paused alerts: ${message(err)}`));
  const judged = await withLookback(t, model);
  ctx.judged = judged;
  const { actions, next } = planArming(judged.sources, own, state, now);
  if (alerts.failedGroups.length) {
    for (const [id, v] of Object.entries(state))
      if (!(id in next) && !own.some((n) => n.id === id))
        next[id] = v;
  }
  const keepPriorOf = (id) => {
    if (state[id])
      next[id] = state[id];
    else
      delete next[id];
  };
  const ordered = [...actions.filter((a) => a.kind === "arm"), ...actions.filter((a) => a.kind !== "arm")];
  for (const a of ordered.slice(BACKEND_MAX_ARMING))
    keepPriorOf(a.notification.id);
  if (ordered.length > BACKEND_MAX_ARMING)
    result.done.push(`${ordered.length - BACKEND_MAX_ARMING} more alert changes wait for the next run (at most ${BACKEND_MAX_ARMING} a run)`);
  for (const a of ordered.slice(0, BACKEND_MAX_ARMING)) {
    const n = a.notification;
    const path = `/m/${encodeURIComponent(n.group)}/notifications/${encodeURIComponent(n.id)}`;
    const keepPrior = () => keepPriorOf(n.id);
    try {
      const current = parseNotifications(n.group, await apiGet(t, path))[0];
      if (!current || !isOwnAlert(current) || current.disabled || isArmed(current) === (a.kind === "arm")) {
        result.done.push(`${a.kind} ${n.id}: skipped, it changed since this run read it`);
        keepPrior();
        continue;
      }
      await apiWrite(t, "PATCH", path, windowBody(current.raw, a.timeWindow));
      ctx.leaderWrites = (ctx.leaderWrites ?? 0) + 1;
      result.done.push(`${a.kind} ${n.id} \u2192 ${a.timeWindow}: ${a.reason}`);
    } catch (err) {
      result.failed.push(`${a.kind} ${n.id}: ${message(err)}`);
      keepPrior();
    }
  }
  await kvWrite(t, ARM_STATE_KEY, next);
  result.armed = Object.keys(next).length;
}

// backend/check.ts
var message2 = (err) => err instanceof Error ? err.message : String(err);
async function onRequest(_request, context) {
  const t = (path, init) => fetch(path.startsWith("/kvstore/") ? `/api/v1/a/${encodeURIComponent(context.appId)}${path}` : `/api/v1${path}`, init);
  const now = Date.now();
  let result;
  try {
    result = await runArming(t, now);
  } catch (err) {
    result = { at: now, own: 0, armed: 0, done: [], failed: [`run: ${message2(err)}`] };
  }
  try {
    await kvWrite(t, ARM_RUN_KEY, fitRunRecord(result));
  } catch (err) {
    result.failed.push(`recording this run: ${message2(err)}`);
  }
  return new Response(JSON.stringify(result), { status: 200, headers: { "content-type": "application/json" } });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onRequest
});
//# sourceMappingURL=check.js.map

# Data Source Health and Activity

See which Cribl Stream Sources are sending data, which have gone quiet, and which drive your ingest volume.

## Summary

Data Source Health and Activity is a Cribl app for monitoring Stream Sources across Worker Groups. It flags Sources that have been silent for longer than you allow, warns before they get there, calls out Sources that stopped together, and shows whether data is flowing. The Overview reloads every minute while it's open. Alerts go through Cribl's own notifications, so they reach the same email, Slack, PagerDuty, AWS SNS and webhook targets as your other Cribl alerts, even when nobody has the app open.

## What This App Does

* Primary purpose: a health and activity view of every Stream Source (input), with alerts when a Source goes quiet. The only Cribl configuration it changes is its own alert notifications: an administrator confirms each change, and the app's backend (when installed on an Enterprise plan) only narrows and restores their time window.
* Key capabilities:
  * Overview, reloaded every minute, for all Worker Groups or the ones you pick:
    * Status counts, each Source counted once, as one line or, with several Worker Groups, a table per group.
    * Needs attention: Overdue Sources and tokens, most recent first, then Sources whose health reports errors or degraded, then collectors whose latest run failed. Sources in one group that stopped together are one row.
    * Due soon: Sources and tokens that will pass their allowance within 15 minutes.
    * Last hour: Sources that went Overdue, resumed or sent their first data; a Source Overdue more than once is one Intermittent row, with a suggested allowance when its normal gaps run past its own. Use suggestion opens it in Settings to review and save.
    * Current ingest: the last 15 minutes against the 15 before.
    * A Sources-by-time activity strip for the selected range.
    * Recent activity and health reload every minute; the Source list and range chart every five minutes, or at once with Refresh.
    * If a reload fails, the last good data stays on screen, clearly marked stale, on the Overview, Sources and a Source's details.
  * Sources: search, filters (status, Worker Group, type, hide disabled), sorting and CSV export, with the search, filters and time range kept in the link. Each row shows Cribl's health as an icon and has actions: Open in Cribl, Ingestion in Cribl Search, Logs in Cribl Search, Copy Source ID, and for administrators Edit allowance and Edit alert. Administrators can also tick several Sources and edit their allowance together. Token rows sit under their Source. Collectors have their own tab, with their schedule and latest run; selecting one shows its details: schedule, what each run collects, and its recent runs with links to Cribl's Job Inspector. Arrow keys move through the list and Enter opens a Source.
  * Sources with several tokens: a Splunk HEC, Zscaler HEC or Cloudflare HEC Source with Cribl's "Emit per-token request metrics" turned on is watched token by token. Each token gets its own row under its Source, with its own status, allowance and History. A token that goes quiet shows on the Overview while the others keep its Source sending, and its Source counts with its most urgent token's status. Cribl measures a token's request size rather than its event bytes, so tokens show no bytes. A disabled token that senders still use shows how many requests Cribl refused. Other Sources that take several tokens (HTTP, Splunk S2S, Elastic and more) are measured by Cribl only as a whole, and the app says so on the Source.
  * History: every time a Source or token went Overdue, one row per silence with when it began and ended, and when each first sent data, as far back as Cribl holds metrics, with search and filters. The Overview, the Source details and History show the same Overdue periods.
  * Source details: status, Cribl's own log lines for an Overdue or unhealthy Source from the 10 minutes before the problem began (or the last 10 minutes), its activity across the range, the times it was Overdue, its allowance, Open in Cribl, and the Cribl Search links.
  * Alerts: one Cribl "No Data Received" notification per Source, using that Source's allowance as the time window, sent to the Cribl notification targets you pick (email, Slack, PagerDuty, AWS SNS, webhooks, System Messages). Different Sources can alert to different places: besides the default targets, profiles name other sets of targets and email recipients, and each Source alerts with the default, a profile, or not at all. Tick several Sources to give them the same one. Cribl's Leader sends them, so they work with the app closed. With this app's backend running (Cribl runs app backends on Enterprise plans), the app checks every Source every minute; when one passes its allowance, it narrows that Source's Cribl alert to a one-minute window, so Cribl alerts within a few minutes, and puts the window back as soon as the Source sends again. Without the backend, Cribl checks once per window as long as the allowance, so an alert arrives one to two allowances after the Source goes quiet. Jira, ServiceNow and similar services connect through a Webhook target or through Cribl Stream. Cribl alerts when the silence starts and when it ends. Before applying, the app shows every change and estimates how often each Source would have alerted recently. Sources already watched by a notification set up in Cribl are left alone. The Alerts page shows where alerts go and how often Sources are checked, each Source's alert and its state in Cribl, and the alerts Cribl sent (from its System Messages).
  * Settings: the allowable silence and expected delay, as defaults, rules for a Source type or Worker Group, and per-Source overrides; and Cribl Search: the "Ingestion in Cribl Search" and "Logs in Cribl Search" links, each turned on or off, with the dataset its CriblMetrics or CriblLogs data is routed to (defaults `cribl_metrics` and `cribl_logs`, off until turned on) and the query. Only Organization or Workspace administrators can change them.
  * Help: statuses, allowances, alerts, keyboard keys and support. The Cribl API calls are listed under Permissions below.
  * Time ranges of 1 hour, 6 hours, 12 hours, 24 hours and 7 days.
  * Follows your Cribl light or dark theme. Same look and behaviour as Config Quest for Cribl.
* Intended users: Admin, Platform owner
* Works with: Stream (distributed deployments, Cribl.Cloud or hybrid)

Status definitions:

Each Source has an allowance: its allowable silence plus its expected delay (15 + 0 minutes unless you change them in Settings).

| Status | Meaning |
|---|---|
| Overdue | No events for longer than its allowance |
| Due soon | Active, but quiet for over half its allowance, and it passes its allowance within 15 minutes if nothing arrives |
| Active | Its last event is within its allowance |
| No data | Enabled, with no events in the selected range |
| Unknown | Recent activity couldn't be read, so Active and Overdue can't be told apart |
| Disabled | Turned off in Cribl, and not monitored |

Each Source has one status and counts once; a Source watched token by token shows its most urgent enabled token's status. When Cribl's own Source health metric over the last two minutes reports Errors or Degraded, that shows beside the status.

## When To Use This App

* Catch a Source that stopped sending before downstream teams notice missing data.
* Find enabled Sources that never receive data and can be cleaned up.
* See which Sources drive ingest growth or a volume spike.

## Before You Install

* Required deployment: a distributed Cribl Stream Leader with Worker Groups. Single-instance deployments aren't supported yet.
* Required permissions: an admin installs the app and shares it with App users. The app's own read grants are listed under Permissions.
* Who can change Settings and alerts: Organization Owners and Admins, Workspace Owners and Admins, or a member whose role grants every action on every object (the built-in Admin role on self-managed Cribl). Everyone else the app is shared with can view.
* Alerts need a Cribl plan that includes Stream Source notifications. The every-minute check runs in the app's backend, which Cribl allows on Enterprise plans.
* The backend only changes the time window of alerts this app created and an administrator turned on; it never creates or deletes notifications. It keeps its working state in the app's storage under `state/arming` and records each run under `state/arming-run`, which the Alerts page shows. Without an Enterprise plan the app works the same, with Cribl's slower alert timing. Email, Slack, PagerDuty and other targets are set up in Cribl (Stream › Notifications › Targets); the app picks from them.
* No external systems, API keys or configuration values are needed.

## Installation

### Install From Marketplace or URL
1. Go to Apps in your Cribl environment.
2. Install from the Cribl Marketplace, or import from the Marketplace-hosted URL.
3. Review the app's permissions and complete installation.

### If The App Is Not Yet In The Cribl Marketplace
1. Download the `.tgz` package for the version you want from the repository's Releases.
2. In Cribl, go to Apps and choose import from file.
3. Upload the `.tgz` file, review the permissions and complete installation.

## Configuration

None is needed: the app reads every Stream Worker Group it is allowed to, with a 15-minute allowance (15 minutes of allowable silence plus 0 minutes of expected delay).

To change it, open Settings:

* **Allowable silence**: the longest normal gap between a Source's events.
* **Expected delay**: how late data normally arrives, including metrics reporting lag.
* **Rules by type or Worker Group**: an allowance for every Source of a type (all S3 Sources, say) or every Source in a Worker Group.
* **Per-Source overrides**: for batch or bursty Sources that are normally quiet for longer. On the Sources page, administrators can also tick several Sources and set their overrides together.

The most specific setting wins, field by field: a Source's own override, then (for a token) its Source's, then its type's rule, then its Worker Group's rule, then the defaults.

Review changes lists what will change and asks for confirmation before saving. Settings are shared by everyone the app is shared with, so only Organization or Workspace administrators can save them; everyone else sees them read-only.

## How To Use

### Typical Workflow
1. Open the app. The Overview says Live and when it last read the data.
2. Work through Needs attention now, newest first. A "stopped together" row usually means the Workers or their network, not each sender.
3. Check Due soon for Sources that are unusually quiet for them.
4. Use Last hour to see what just broke or recovered, and Current ingest to confirm data is flowing.
5. Open Sources to sort or filter the full list. Open Settings to give batch or bursty Sources a longer allowance.
6. On the Alerts page, choose where alerts go and which Sources alert, review the changes and apply them. Set up new targets in Cribl first, under Stream › Notifications › Targets.

### First-Run Checklist
* Confirm the Overview header counts your Worker Groups and says Live.
* If a warning says some data couldn't be read, check the app's permissions.

## Permissions

The app runs in Strict mode: it can call only the paths below, whatever the signed-in member's own role. Every call is a read except the alert notifications, which the app writes only after an administrator confirms the exact changes, and which its backend updates only to change their time window. If the health or recent-activity query fails, the app keeps working and marks what's incomplete. If Worker Groups, Sources or volume can't be read, it shows an error instead of guessing.

### Cribl API Endpoints Used

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/v1/products/stream/groups` | List Stream Worker Groups |
| GET | `/api/v1/m/<group>/system/inputs` | List each group's Sources (id, type, enabled) |
| POST | `/api/v1/system/metrics/query` | Read Source volume (`total.in_events`, `total.in_bytes`) for the selected range and, per minute, for the last two hours, and health (`health.inputs`), and per minute for the last three hours for one unhealthy Source, to find when its health turned. For Sources with per-token metrics on, the same for each token (`http.perToken.numEvents`, `.bytesReceived`, `.numErrors`). The POST carries the query; it changes nothing. |
| GET | `/api/v1/authorize/roles` | Your roles in this session, to decide whether you can change the shared allowances |
| GET | `/api/v1/authorize/policy` | Your effective policy in this session: Cribl.Cloud reports a Workspace admin as the role `admin`, which counts only with a global all-actions grant |
| GET | `/api/v1/notification-targets` | List Cribl's notification targets for the alert settings (the app keeps only each target's ID and type) |
| GET | `/api/v1/notification-targets/<id>` | Granted alongside the list so Cribl returns the targets (the app doesn't read single targets) |
| GET, POST | `/api/v1/m/<group>/notifications` | List each group's notifications; create this app's "No Data Received" notifications |
| GET | `/api/v1/m/<group>/notifications/<id>` | Read single notifications (granted alongside the list so Cribl returns them) |
| PATCH, DELETE | `/api/v1/m/<group>/notifications/dsh-*` | Update or delete this app's notifications; the backend uses PATCH to arm and restore their time window. The grant only covers IDs starting `dsh-`, so other notifications can't be changed through the app |
| GET | `/api/v1/system/messages` and `/messages/<id>` | The alerts Cribl sent, from its System Messages, shown on the Alerts page |
| GET | `/api/v1/products/stream/workers` and `/workers/<id>` | List a Worker Group's connected Workers, to read a Source's recent log lines (the item path is needed or Cribl returns an empty list) |
| GET | `/api/v1/w/<worker>/system/logs/search` and `/api/v1/m/<group>/system/logs/search` | Search each Worker's logs for one Source's channel (`input:<id>`) over a 10-minute window (before the problem began, or the latest), as Cribl's own Source › Logs tab does. Worker paths are authorized against their group path, so both are declared |
| GET | `/api/v1/m/<group>/lib/jobs` and `/lib/jobs/<id>` | List each group's collectors (the app keeps only each one's ID, type and schedule) |
| GET | `/api/v1/m/<group>/jobs` and `/jobs/<id>` | Each collector's recent runs (up to 10) and their state |

The app's own key-value store (granted automatically to every app) holds the allowance settings and the alert choices; see Data And Storage.

What these grants give app users, beyond what the app shows:

* The Sources grant returns each Source's full configuration in every Stream Worker Group, which can include secrets such as HEC tokens. Anyone the app is shared with can read it through the app, whatever their own role. The app reads a Source's tokens, and the token in each per-token metric, only to reduce each one to a short one-way fingerprint that tells tokens apart; it never shows, stores or exports a token.
* The metrics grant is Leader-wide. The app asks only for Source metrics, but the grant isn't limited to particular metrics or Worker Groups.
* The log grants let anyone the app is shared with search any Worker's logs through the app. The app asks only for one Source's lines, only for unhealthy Sources, and only when its details are opened.
* The collector grants return each collector's full definition, which can include credentials (a Splunk search collector's password, for example). The app keeps only the ID, type and schedule, but anyone the app is shared with can read the definitions through the app.
* The notification targets grant returns each target's full configuration, which can include secrets such as webhook URLs, keys and SMTP settings. The app keeps only each target's ID and type.
* The notification targets are read only for administrators, but the grant lets anyone the app is shared with read every target's configuration through the app.
* Updating and deleting notifications is limited by the grant to IDs starting `dsh-`, the app's own. Creating can't be limited that way: anyone the app is shared with could create a notification through the app, including one that emails any address through an Email target. Only administrators can create them in the app, but that's an app rule, not a security boundary.

Share the app only with people who may see that information.

## External API Access

None. The app makes no external calls and ships no `proxies.yml` entries.

## Data And Storage

The app stores these documents in its own key-value store: the allowance defaults, rules and per-Source and per-token overrides (a token's override is keyed by its fingerprint, never the token), the Cribl Search datasets and queries (`settings/search`), the alert choices (on or off, the default targets, profiles with their targets, which Sources use each profile, Sources left out, and the email recipients for Email targets), each with who saved it and when, and, when the backend runs, its working state (`state/arming`: which alerts it armed and the window each had) and its last run (`state/arming-run`). Email addresses are personal data: they're stored there and in each Cribl notification that sends email, and anyone the app is shared with can read them. Only administrators can save from the app, but Cribl's app storage itself is open to everyone the app is shared with, so treat that as an app-level rule rather than a security boundary.

The app's alerts are Cribl notifications, so they stay in Cribl if the app is uninstalled. To remove them, turn alerts off on the Alerts page and apply before uninstalling, or delete the notifications whose IDs start with `dsh-` under Stream › Notifications.

## Support

### Partner Built
This app is built and supported by Discovered Intelligence. For questions, bugs and feature requests, contact support@discoveredintelligence.ca.

## Known Limitations

* Sources inside Packs aren't listed yet. Their metrics are reported as unmatched on the Overview rather than dropped silently.
* Distributed deployments only.
* "Last seen" is accurate to a minute for recent events, as long as every allowance is under 6 hours. Older events are accurate to the chart interval (up to 2 hours for 7 days).
* Rhythm is read from the last two hours, so a Source that sends less often than about every 40 minutes has no rhythm to compare with.
* The Overview reloads only while it's open and visible; it isn't an alerting service.
* With the 7-day range, outages that began more than two hours ago aren't grouped as "stopped together", because their start is only known to the 2-hour chart interval.
* Custom date ranges aren't available yet.
* Alerts are per Source: several Sources that stop together send one alert each.
* Alerts don't follow allowance changes by themselves. After changing allowances, review and apply the alert changes the app lists.
* Cribl's Source notifications require an eligible plan or licence, and the Leader must be able to reach each target.
* The alert preview is an estimate from the last two hours of one-minute metrics; Cribl evaluates on its own schedule.
* History reaches back only as far as Cribl holds metrics. Cribl's Leader keeps them in memory, limited by volume rather than time, and loses them on restart (about a day and a half on the Cribl.Cloud tenant it was tested on). Overdue periods in the last two hours are to the minute; earlier ones are to 15 minutes, so a shorter silence before then may not show.
* The Cribl Search links need setting up: route the CriblMetrics and CriblLogs Sources to a dataset Cribl Search can read (a Cribl Lake dataset, for example), then turn each link on in Settings › Cribl Search with that dataset. On Cribl.Cloud the built-in `cribl_metrics` and `cribl_logs` datasets hold only the Leader's own data and can't be routed to. The default queries fit CriblMetrics and CriblLogs routed to a Cribl Lake dataset with CriblMetrics' default name prefix (`cribl.logstream.`), verified on Cribl.Cloud; both can be edited there if yours differ. On Cribl.Cloud, routing them to the existing `default_metrics` and `default_logs` datasets works: one Cribl Lake Destination per dataset and a Route per Source (filter `__inputId=='cribl:CriblMetrics'` or `__inputId=='cribl:CriblLogs'`).
* Collectors are checked by their latest run only; data they collect isn't counted per collector. Cribl keeps runs for the collector's time to live (4 hours by default), so the details list only those.
* Allowance rules were added in 1.5.0. An older version of the app reads the allowances without them, and saving allowances from an older version drops them.
* Alert profiles were added in 1.6.0. Once a profile is saved, versions before 1.6.0 can't read the alert choices and won't change alerts until they're upgraded, so they can't send profile Sources' alerts back to the default targets.
* The logs search finds a Source's cribl.log lines by their `input:<id>` channel, verified for streaming Sources. Scheduled-pull Sources (Office 365, Wiz, ServiceNow and similar) haven't been checked with live data.
* Source types that Cribl Stream's UI has no page for (Edge-only types and S3 Inventory) open the Worker Group's Sources list.
* Watching each token needs Cribl's "Emit per-token request metrics" on and deployed for that Source (off by default), and exists only for Splunk HEC, Zscaler HEC and Cloudflare HEC Sources. Until Cribl reports per-token data, the Source is watched as a whole.
* Cribl's alerts watch whole Sources, so one token going quiet sends no Cribl alert; it shows in the app. A Source's own alert fires only once every token has stopped.
* A token whose settings reference a stored secret is matched to its metrics by its description. Without a unique description it can't be watched by name; its traffic shows under the tokens Cribl reports, and only while they send. Rotating a token's value makes it a new token to the app: its per-token allowance override no longer applies.
* Faster alerts need the app's backend, which Cribl installs only on Enterprise plans. Without it, Cribl checks once per window as long as the allowance.
* Even with faster alerts, Cribl adds about five minutes between its check and the alert (measured on Cribl.Cloud), so an alert arrives about 7–8 minutes after a Source passes its allowance.
* If any Source has an allowance over 6 hours, the backend's view of recent activity is coarser (5-minute windows for a day-long allowance), so arming can be up to that much later for every Source.

## Troubleshooting

### The App Opens But Some Features Do Not Work
A yellow notice names the query that failed. Check that the installed app still has the grants listed under Permissions.

### The App Shows "Couldn't load Source activity"
A 401 or 403 means the app isn't allowed to read Worker Groups, Sources or metrics. Ask an admin to review the app's Permissions.

### The App Works Locally But Not In Cribl
Locally, outside Cribl, the app runs on demo data and says so. Live data only appears when the app runs inside Cribl.

## Development

```bash
npm install
npm run dev       # outside Cribl: demo data; in Cribl Live Preview: your Leader's data
npm test          # unit tests for the activity model and formatting
npm run package   # build and pack a .tgz
```

Opened directly in a browser, the dev server has no Cribl API, so the app uses synthetic data (`src/api/demo.ts`) and shows a Demo data banner. Add `?theme=dark` to check dark mode there. Inside Cribl, the theme follows the Cribl shell.

To check behaviour that needs several Worker Groups on a plan with one, start the dev server with `VITE_DSH_MIRROR=1 npm run dev`. In Live Preview the app then also shows `dmz-mirror`, a read-only copy of the first Worker Group with three Sources silenced from 40 minutes before the app loaded (`src/api/mirror.ts`), and refuses every change. Production builds leave it out.

## Project Layout

```text
src/
  App.tsx             navigation and routes
  pages/              Overview and Sources
  components/         chart, sparkline, time scope, page shell
  data/activity.ts    joins metrics to Sources and classifies status (unit-tested)
  data/load.ts        Cribl API calls
  api/                fetch wrapper and demo transport
config/
  policies.yml        Cribl API access grants
  proxies.yml         external domains (none)
README.md
```

## Versioning And Releases

Semantic versioning. `npm run package` bumps the patch version; use `-- --minor` or `-- --major` for larger changes.

## Contributing

Open an issue or contact the maintainer before proposing changes.

## License

Not yet set.

## App Metadata

| Field | Value |
|---|---|
| App Name | Data Source Health and Activity |
| App ID | data-source-activity |
| Version | 1.0.0 |
| Author | Discovered Intelligence |
| Support Model | partner-built |
| Support Label | Partner Built |
| Support Contact | support@discoveredintelligence.ca |
| License | Not yet set |
| License File | Not yet set |
| Product Tags | stream |
| Category | Monitoring |
| Audience | admin, platform-owner |
| Availability | preview |
| Requires External Access | no |
| Repository | Not yet set |
| Documentation | This README |
| README Schema Version | 1.0 |

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// backend/check.ts
var check_exports = {};
__export(check_exports, {
  onRequest: () => onRequest
});
module.exports = __toCommonJS(check_exports);

// src/api/client.ts
var ApiError = class extends Error {
  constructor(status, path, detail) {
    super(`${status} from ${path.split("?")[0]}${detail ? `: ${detail}` : ""}`);
    this.status = status;
  }
};
function errorDetail(body) {
  const text2 = body.trim();
  if (!text2 || text2.startsWith("<"))
    return "";
  try {
    const parsed = JSON.parse(text2);
    const said = typeof parsed?.message === "string" ? parsed.message : typeof parsed?.error === "string" ? parsed.error : void 0;
    if (said)
      return said.slice(0, 200);
  } catch {
  }
  return text2.slice(0, 200);
}
var unreadable = (path) => new Error(`Cribl's answer from ${path.split("?")[0]} wasn't in the form this app reads`);
async function parse(res, path) {
  if (!res.ok)
    throw new ApiError(res.status, path, errorDetail(await res.text().catch(() => "")));
  const text2 = await res.text();
  try {
    return JSON.parse(text2);
  } catch {
    throw unreadable(path);
  }
}
async function apiGet(t, path, signal) {
  return parse(await t(path, { signal }), path);
}
async function apiQuery(t, path, body, signal) {
  const res = await t(path, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
    signal
  });
  const parsed = await parse(res, path);
  const results = parsed && typeof parsed === "object" ? parsed.results : null;
  if (results === null || results !== void 0 && !Array.isArray(results))
    throw unreadable(path);
  return parsed;
}
async function apiWrite(t, method, path, body) {
  const res = await t(path, {
    method,
    ...body === void 0 ? {} : { headers: { "content-type": "application/json" }, body: JSON.stringify(body) }
  });
  if (!res.ok)
    throw new ApiError(res.status, path, errorDetail(await res.text().catch(() => "")));
  const text2 = await res.text().catch(() => "");
  try {
    return text2 ? JSON.parse(text2) : void 0;
  } catch {
    return void 0;
  }
}
function itemsOf(payload) {
  if (payload === void 0)
    return [];
  if (Array.isArray(payload))
    return payload;
  if (payload && typeof payload === "object" && Array.isArray(payload.items)) {
    return payload.items;
  }
  throw new Error(`Cribl's answer wasn't in the form this app reads`);
}

// src/data/tokens.ts
var PER_TOKEN_TYPES = /* @__PURE__ */ new Set(["splunk_hec", "zscaler_hec", "cloudflare_hec"]);
function fingerprint(secret) {
  let h = 2166136261;
  for (let i = 0; i < secret.length; i++) {
    h ^= secret.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h.toString(16).padStart(8, "0");
}
var asRecord = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
var text = (v) => typeof v === "string" && v.trim() ? v.trim() : void 0;
function parseSourceTokens(type, item) {
  const raw = [...Array.isArray(item.authTokens) ? item.authTokens : [], ...Array.isArray(item.authTokensExt) ? item.authTokensExt : []];
  if (raw.length < 2)
    return void 0;
  if (!PER_TOKEN_TYPES.has(type))
    return { count: raw.length, perToken: "unsupported", tokens: [] };
  const tokens = raw.map((t) => {
    if (typeof t === "string")
      return { fp: t ? fingerprint(t) : "", enabled: true };
    const o = asRecord(t) ?? {};
    const secret = typeof o.token === "string" && o.token && o.authType !== "secret" ? o.token : void 0;
    return { fp: secret ? fingerprint(secret) : "", description: text(o.description), enabled: o.enabled !== false };
  });
  return { count: raw.length, perToken: item.emitTokenMetrics === true ? "on" : "off", tokens };
}
var KEEP = ["inputId", "tokenDescription", "__worker_group", "starttime", "endtime", "_time", "events", "bytes", "rejected", "recentEvents", "recentBytes"];
function scrubTokenRows(rows) {
  return rows.map((row) => {
    const out = { tokenFp: typeof row.token === "string" && row.token ? fingerprint(row.token) : "" };
    for (const k of KEEP)
      if (k in row)
        out[k] = row[k];
    return out;
  });
}
function tokenKey(t, index) {
  return t.fp ? `t${t.fp}` : t.description ? `d${fingerprint(t.description)}` : `n${index}`;
}
var tokenRowId = (sourceRowId, key) => `${sourceRowId}#${key}`;
var TOKEN_SUFFIX = /#(?:t[0-9a-f]{8}|d[0-9a-f]{8}|n\d+)$/;
var parentRowId = (rowId) => rowId.replace(TOKEN_SUFFIX, "");

// src/data/urgency.ts
var MIN = 6e4;
var NEW_MS = 60 * MIN;
var CHANGE_WINDOW_MS = 60 * MIN;
var TOGETHER_GAP_MS = 5 * MIN;
var TOGETHER_SPAN_MS = 10 * MIN;
var TOGETHER_MAX_RESOLUTION_S = 15 * 60;
var CHART_WINDOW_MS = 5 * MIN;

// src/data/criblNames.ts
var ALIASES = [{ inventory: "criblmetrics", cribl: "cribl", id: "CriblMetrics" }];
var NO_STREAM_PAGE = /* @__PURE__ */ new Set([
  "apple_unified_logs",
  "edge_prometheus",
  "exec",
  "file",
  "journal_files",
  "kube_events",
  "kube_logs",
  "kube_metrics",
  "s3_inventory",
  "system_metrics",
  "system_state",
  "win_event_logs",
  "windows_metrics"
]);
var criblType = (type) => ALIASES.find((a) => a.inventory === type)?.cribl ?? type;
var criblInput = (type, id) => `${criblType(type)}:${id}`;
function inventoryInput(input) {
  const i = input.indexOf(":");
  if (i < 0)
    return input;
  const type = input.slice(0, i);
  const id = input.slice(i + 1);
  const alias = ALIASES.find((a) => a.cribl === type && a.id === id);
  return alias ? `${alias.inventory}:${id}` : input;
}

// src/data/alerts.ts
var ALERT_PREFIX = "dsh-";
var NO_DATA = "no-data";
var ARMED_WINDOW = "1m";
var SYSTEM_TARGET = "system_notifications";
function asRecord2(v) {
  return v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
}
function parseTargets(payload) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const o = asRecord2(item);
    if (typeof o?.id === "string" && o.id && typeof o.type === "string" && o.type)
      out.push({ id: o.id, type: o.type });
  }
  return out.sort((a, b) => a.id === SYSTEM_TARGET ? -1 : b.id === SYSTEM_TARGET ? 1 : a.id.localeCompare(b.id));
}
var SOURCE_LINK = "{source_link}";
var SUBJECT_MAX = 300;
var BODY_MAX = 8e3;
function defaultEmailMessage(cribleCloud) {
  return {
    subject: "Cribl ${status}: ${input} in ${__worker_group}",
    body: [
      "Cribl reports ${status} for Source ${input} in Worker Group ${__worker_group}: no data for ${timewindow} (OK means its data is flowing again).",
      "",
      "Source: ${input}",
      "Worker Group: ${__worker_group}",
      ...cribleCloud ? ["Workspace: ${workspace}", "Organization: ${organization}"] : [],
      "Time window: ${timewindow}",
      "Status: ${status}",
      "Sent: ${timestamp}",
      "",
      "Sent by Data Source Health and Activity (Cribl notification ${cribl_notification})."
    ].join("\n")
  };
}
function legacyEmailMessage(cribleCloud) {
  const m = defaultEmailMessage(cribleCloud);
  const lines = m.body.split("\n");
  lines.splice(lines.length - 1, 0, `Open in Cribl: ${SOURCE_LINK}`, "");
  return { subject: m.subject, body: lines.join("\n") };
}
var DESCRIPTION_MAX = 500;
var isCollectorRow = (rowId) => /^[^/]+\/collection:/.test(rowId);
var defaultDescription = (rowId) => `Link to access this ${isCollectorRow(rowId) ? "collector" : "Source"} in Cribl: ${SOURCE_LINK}`;
function descriptionFor(settings, rowId) {
  const own = settings.descriptions[rowId];
  return own === void 0 ? defaultDescription(rowId) : own || void 0;
}
var cleanDescription = (text2) => text2.replace(/\r\n?/g, "\n").split("\n").map((l) => l.trimEnd()).filter((l) => l.trim()).join("\n").trim().slice(0, DESCRIPTION_MAX);
var DESCRIPTION_LABEL = "Description: ";
function extractDescription(body) {
  const lines = body.split("\n");
  if (lines.length < 3 || lines[1] !== "" || !lines[2].startsWith(DESCRIPTION_LABEL))
    return { body };
  let end = 3;
  while (end < lines.length && lines[end] !== "")
    end++;
  const description = [lines[2].slice(DESCRIPTION_LABEL.length), ...lines.slice(3, end)].join("\n");
  const rest = lines.slice(end + 1);
  return { body: [lines[0], ...rest.length ? ["", ...rest] : []].join("\n"), description };
}
var sourcePathFor = () => void 0;
var escapeRe = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
var unfillLink = (s, onBase) => {
  const path = sourcePathFor(s);
  if (!path) {
    const plain = new RegExp(escapeRe(`${s.group} \u203A ${criblInput(s.type, s.sourceId)}`), "g");
    return (text2) => text2.replace(plain, SOURCE_LINK);
  }
  const re = new RegExp(`(https?://[^\\s"'<>]*?)${escapeRe(path)}(?![\\w/-]|\\.\\w)`, "g");
  return (text2) => text2.replace(re, (_m, base) => {
    onBase?.(base);
    return SOURCE_LINK;
  });
};
function parseMessage(v, cap = true) {
  const m = asRecord2(v);
  const subject = typeof m?.subject === "string" ? m.subject.replace(/\s+/g, " ").trim().slice(0, cap ? SUBJECT_MAX : void 0) : "";
  const body = typeof m?.body === "string" ? m.body.replace(/\r\n/g, "\n").replace(/\s+$/, "").slice(0, cap ? BODY_MAX : void 0) : "";
  return subject || body ? { ...subject ? { subject } : {}, ...body ? { body } : {} } : void 0;
}
var sameMessage = (a, b) => (a?.subject ?? "") === (b?.subject ?? "") && (a?.body ?? "") === (b?.body ?? "");
function str(v) {
  return typeof v === "string" && v.trim() ? v.trim() : void 0;
}
function parseNotifications(group, payload) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const o = asRecord2(item);
    if (typeof o?.id !== "string" || !o.id || typeof o.condition !== "string")
      continue;
    if (typeof o.group === "string" && o.group && o.group !== group)
      continue;
    const conf = asRecord2(o.conf) ?? {};
    const emailByTarget = {};
    const messageByTarget = {};
    for (const tc of Array.isArray(o.targetConfigs) ? o.targetConfigs : []) {
      const c = asRecord2(tc);
      const r = asRecord2(asRecord2(c?.conf)?.emailRecipient);
      const to = str(r?.to);
      if (typeof c?.id === "string" && to)
        emailByTarget[c.id] = { to, cc: str(r?.cc), bcc: str(r?.bcc) };
      const m = parseMessage(asRecord2(c?.conf), false);
      if (typeof c?.id === "string" && m)
        messageByTarget[c.id] = m;
    }
    out.push({
      id: o.id,
      group,
      condition: o.condition,
      disabled: o.disabled === true,
      targets: Array.isArray(o.targets) ? o.targets.filter((t) => typeof t === "string") : [],
      emailByTarget,
      messageByTarget,
      input: str(conf.name),
      timeWindow: str(conf.timeWindow),
      notifyOnResolution: typeof conf.notifyOnResolution === "boolean" ? conf.notifyOnResolution : void 0,
      raw: o
    });
  }
  return out;
}
function alertIdForInput(group, input) {
  const i = input.indexOf(":");
  return i > 0 ? alertId(group, input.slice(0, i), input.slice(i + 1)) : `${ALERT_PREFIX}?`;
}
var isOwnAlert = (n) => n.id.startsWith(ALERT_PREFIX) && n.condition === NO_DATA && Boolean(n.input) && n.id === alertIdForInput(n.group, n.input);
var DEFAULT_ALERTS = { version: 3, enabled: false, targets: [SYSTEM_TARGET], profiles: [], assigned: {}, alerting: [], tokens: {}, descriptions: {} };
var tokenChoice = (settings, tokenRowId2) => settings.tokens[tokenRowId2] ?? "source";
var PROFILE_ID = /^[A-Za-z0-9_-]{1,40}$/;
var RESERVED = /* @__PURE__ */ new Set(["off", "default"]);
var PROFILE_NAME_MAX = 60;
var cleanName = (name) => name.trim().replace(/\s+/g, " ");
function profileOf(settings, sourceRowId) {
  const id = settings.assigned[sourceRowId];
  return id === void 0 ? void 0 : settings.profiles.find((p) => p.id === id);
}
function isAlertSettingsDoc(raw) {
  const o = asRecord2(raw);
  if (!o || typeof o.enabled !== "boolean" || !Array.isArray(o.targets))
    return false;
  return o.version === 3 ? Array.isArray(o.alerting) : (o.version === 1 || o.version === 2) && Array.isArray(o.excluded);
}
var strings = (v) => Array.isArray(v) ? [...new Set(v.filter((x) => typeof x === "string" && x.length > 0))] : [];
function parseEmail(v) {
  const e = asRecord2(v);
  const to = str(e?.to);
  return to ? { to, cc: str(e?.cc), bcc: str(e?.bcc) } : void 0;
}
function parseProfiles(v) {
  const out = [];
  for (const item of Array.isArray(v) ? v : []) {
    const p = asRecord2(item);
    if (typeof p?.id !== "string" || !PROFILE_ID.test(p.id) || RESERVED.has(p.id.toLowerCase()) || out.some((x) => x.id === p.id))
      continue;
    const name = cleanName(typeof p.name === "string" ? p.name : "").slice(0, PROFILE_NAME_MAX) || "Profile";
    out.push({ id: p.id, name, targets: strings(p.targets), email: parseEmail(p.email), message: parseMessage(p.message) });
  }
  return out;
}
function upgradeMessage(m) {
  for (const cloud of [false, true])
    if (m && sameMessage(m, legacyEmailMessage(cloud)))
      return defaultEmailMessage(cloud);
  return m;
}
function parseAlertSettings(raw) {
  const o = asRecord2(raw) ?? {};
  const current = o.version === 3;
  const profiles = parseProfiles(o.profiles).map((p) => current ? p : { ...p, message: upgradeMessage(p.message) });
  const known2 = new Set(profiles.map((p) => p.id));
  const assigned = Object.fromEntries(Object.entries(asRecord2(o.assigned) ?? {}).filter((e) => typeof e[1] === "string" && known2.has(e[1]) && e[0].length > 0));
  const tokens = current ? Object.fromEntries(
    Object.entries(asRecord2(o.tokens) ?? {}).filter((e) => typeof e[1] === "string" && e[0].includes("#") && e[0].indexOf("#") > 0).map(([k, v]) => [k, v === "off" || v === "default" || v === "source" || known2.has(v) ? v : "source"]).filter(([, v]) => v !== "source")
  ) : {};
  const descriptions = current ? Object.fromEntries(
    Object.entries(asRecord2(o.descriptions) ?? {}).filter((e) => typeof e[1] === "string" && e[0].includes("/")).map(([k, v]) => [k, cleanDescription(v)]).filter(([k, v]) => v !== cleanDescription(defaultDescription(k)))
  ) : {};
  const message3 = parseMessage(o.message);
  return {
    version: 3,
    enabled: o.enabled === true,
    targets: Array.isArray(o.targets) ? strings(o.targets) : DEFAULT_ALERTS.targets,
    email: parseEmail(o.email),
    message: current ? message3 : upgradeMessage(message3),
    linkBase: typeof o.linkBase === "string" && /^https?:\/\/[^\s]+$/.test(o.linkBase) ? o.linkBase.replace(/\/+$/, "") : void 0,
    defaultName: typeof o.defaultName === "string" && cleanName(o.defaultName) && cleanName(o.defaultName).toLowerCase() !== "default" ? cleanName(o.defaultName).slice(0, PROFILE_NAME_MAX) : void 0,
    profiles,
    assigned,
    alerting: current ? strings(o.alerting).filter((id) => id.includes("/") && !id.includes("#")).sort() : [],
    tokens,
    descriptions,
    updatedAt: typeof o.updatedAt === "number" ? o.updatedAt : void 0,
    updatedBy: typeof o.updatedBy === "string" ? o.updatedBy : void 0
  };
}
var rowOfNotification = (n) => `${n.group}/${inventoryInput(n.input ?? "")}`;
function currentIdOf(n) {
  const inv = inventoryInput(n.input ?? "");
  const i = inv.indexOf(":");
  return i > 0 ? alertId(n.group, criblType(inv.slice(0, i)), inv.slice(i + 1)) : "";
}
function adoptAlertSettings(own, sources) {
  if (own.length === 0)
    return DEFAULT_ALERTS;
  const byRow = /* @__PURE__ */ new Map();
  for (const n of own) {
    const row = rowOfNotification(n);
    const prev = byRow.get(row);
    if (!prev || prev.id !== currentIdOf(prev) && n.id === currentIdOf(n))
      byRow.set(row, n);
  }
  const emailOf = (n) => n.targets.map((t) => n.emailByTarget[t]).find(Boolean);
  const bases = /* @__PURE__ */ new Map();
  const rowById = new Map(sources.map((s) => [s.id, s]));
  const descriptions = {};
  const messageOf = (n, row) => {
    const m = n.targets.map((t) => n.messageByTarget?.[t]).find(Boolean);
    const inv = inventoryInput(n.input ?? "");
    const i = inv.indexOf(":");
    if (!m || i <= 0)
      return m;
    const known2 = row ? rowById.get(row) : void 0;
    const back = unfillLink({ group: n.group, type: inv.slice(0, i), sourceId: inv.slice(i + 1), ...known2?.collector ? { collector: known2.collector } : {} }, (b) => bases.set(b, (bases.get(b) ?? 0) + 1));
    const split = m.body ? extractDescription(back(m.body)) : { body: "" };
    if (row)
      descriptions[row] = split.description ?? "";
    return { ...m.subject ? { subject: back(m.subject) } : {}, ...split.body ? { body: split.body } : {} };
  };
  const sig = (n, row) => JSON.stringify([[...n.targets].sort(), emailOf(n) ?? null, messageOf(n, row) ?? null]);
  const combos = /* @__PURE__ */ new Map();
  for (const [row, n] of byRow) {
    if (!n.targets.some((t) => n.messageByTarget?.[t]))
      descriptions[row] = "";
    const k = sig(n, row);
    const c = combos.get(k);
    if (c)
      c.rows.push(row);
    else
      combos.set(k, { n, rows: [row] });
  }
  const ordered = [...combos.entries()].sort(([ka, a], [kb, b]) => b.rows.length - a.rows.length || ka.localeCompare(kb));
  const [[, common], ...others] = ordered;
  const names = [];
  const assigned = {};
  const profiles = others.map(([k, c]) => {
    const base = targetList(c.n.targets).slice(0, PROFILE_NAME_MAX - 6);
    let name = base;
    for (let i = 2; names.some((x) => x.toLowerCase() === name.toLowerCase()) || RESERVED.has(name.toLowerCase()); i++)
      name = `${base} (${i})`;
    names.push(name);
    const id = `adopted-${hash(k)}`;
    for (const row of c.rows)
      assigned[row] = id;
    return { id, name, targets: [...c.n.targets], email: emailOf(c.n), message: messageOf(c.n) };
  });
  return {
    version: 3,
    enabled: true,
    targets: [...common.n.targets],
    email: emailOf(common.n),
    message: messageOf(common.n),
    profiles,
    assigned,
    // What Cribl holds alerts, and nothing else: rows without one stay off.
    alerting: [...byRow.keys()].sort(),
    // Which tokens alerted isn't recorded in Cribl: they follow their Source (their searches are kept meanwhile).
    tokens: {},
    // Only descriptions that differ from the default are kept.
    descriptions: Object.fromEntries(Object.entries(descriptions).filter(([k, v]) => v !== cleanDescription(defaultDescription(k)))),
    ...bases.size ? { linkBase: [...bases].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0][0].replace(/\/+$/, "") } : {}
  };
}
function effectiveAlertSettings(saved, all, sources) {
  return saved ? { settings: saved, adopted: false } : { settings: adoptAlertSettings(all.filter(isOwnAlert), sources), adopted: true };
}
function alertId(group, type, id) {
  const raw = `${group}--${type}--${id}`;
  let safe = raw.replace(/[^A-Za-z0-9_-]/g, "_");
  if (safe !== raw || safe.length > 80)
    safe = `${safe.slice(0, 70)}-${hash(raw)}`;
  return `${ALERT_PREFIX}${safe}`;
}
function hash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++)
    h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return (h >>> 0).toString(16).padStart(8, "0");
}
var timeWindowFor = (allowanceMs2) => `${Math.max(1, Math.ceil(allowanceMs2 / 6e4))}m`;
var targetList = (ids) => ids.length ? [...ids].sort().join(", ") : "System Messages (default)";

// src/data/arming.ts
var ARM_STATE_KEY = "state/arming";
var ARM_RUN_KEY = "state/arming-run";
var RUN_STALE_MS = 3 * 6e4;
var isArmed = (n) => n.timeWindow === ARMED_WINDOW;
var isRecord = (v) => Boolean(v) && typeof v === "object" && !Array.isArray(v);
var strings2 = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string") : [];
function parseArmState(raw) {
  const out = {};
  if (!isRecord(raw))
    return out;
  for (const [id, v] of Object.entries(raw)) {
    if (!isRecord(v) || typeof v.armedAt !== "number")
      continue;
    out[id] = typeof v.restWindow === "string" && /^\d+m$/.test(v.restWindow) ? { armedAt: v.armedAt, restWindow: v.restWindow } : { armedAt: v.armedAt };
  }
  return out;
}
function parseArmRun(raw) {
  if (!isRecord(raw) || typeof raw.at !== "number")
    return void 0;
  return {
    at: raw.at,
    own: typeof raw.own === "number" ? raw.own : 0,
    armed: typeof raw.armed === "number" ? raw.armed : 0,
    done: strings2(raw.done),
    failed: strings2(raw.failed),
    skipped: typeof raw.skipped === "string" ? raw.skipped : void 0
  };
}
var pastAllowance = (s) => s.status === "overdue" || s.status === "nodata";
function planArming(sources, notifications, state, now) {
  const byRow = new Map(sources.map((s) => [s.id, s]));
  const actions = [];
  const next = {};
  for (const n of notifications) {
    if (!isOwnAlert(n) || n.condition !== NO_DATA || n.disabled || !n.input)
      continue;
    const s = byRow.get(`${n.group}/${inventoryInput(n.input)}`);
    const prior = state[n.id];
    if (!s || s.disabled || s.status === "unknown") {
      if (prior)
        next[n.id] = prior;
      continue;
    }
    const resting = timeWindowFor(s.allowanceMs);
    if (resting === ARMED_WINDOW)
      continue;
    if (pastAllowance(s)) {
      if (!isArmed(n)) {
        actions.push({ kind: "arm", notification: n, timeWindow: ARMED_WINDOW, reason: `${n.input} in ${n.group} is past its ${resting} allowance` });
        next[n.id] = { armedAt: now, restWindow: n.timeWindow && n.timeWindow !== ARMED_WINDOW ? n.timeWindow : resting };
      } else {
        next[n.id] = prior ?? { armedAt: now, restWindow: resting };
      }
      continue;
    }
    if (!isArmed(n))
      continue;
    actions.push({ kind: "disarm", notification: n, timeWindow: prior?.restWindow ?? resting, reason: `${n.input} in ${n.group} is sending again` });
  }
  return { actions, next };
}
var SNOOZE_PAUSED_KEY = "state/snooze-paused";
function parseSnoozePaused(raw) {
  if (!isRecord(raw))
    return {};
  return Object.fromEntries(Object.entries(raw).filter((e) => typeof e[1] === "number" && Number.isFinite(e[1])));
}
function planSnooze(notifications, snoozed, paused, now) {
  const pause = [];
  const resume = [];
  for (const n of notifications) {
    if (!isOwnAlert(n) || n.condition !== NO_DATA || !n.input)
      continue;
    const until = snoozed[`${n.group}/${inventoryInput(n.input)}`];
    const snoozedNow = until !== void 0 && until > now;
    if (snoozedNow && !n.disabled)
      pause.push(n);
    else if (!snoozedNow && n.disabled && paused[n.id] !== void 0)
      resume.push(n);
  }
  return { pause, resume };
}
function disabledBody(raw, disabled, timeWindow) {
  const conf = isRecord(raw.conf) ? raw.conf : {};
  return timeWindow ? { ...raw, disabled, conf: { ...conf, timeWindow } } : { ...raw, disabled };
}
function windowBody(raw, timeWindow) {
  const conf = isRecord(raw.conf) ? raw.conf : {};
  return { ...raw, conf: { ...conf, timeWindow } };
}

// src/data/format.ts
var intFmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 0 });
var compactFmt = new Intl.NumberFormat(void 0, { notation: "compact", maximumFractionDigits: 1 });
var dec2Fmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 2 });
function formatInt(n) {
  return intFmt.format(Math.round(n));
}
var timeFmt = new Intl.DateTimeFormat(void 0, { hour: "numeric", minute: "2-digit" });
var dateTimeFmt = new Intl.DateTimeFormat(void 0, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });
var dateFmt = new Intl.DateTimeFormat(void 0, { month: "short", day: "numeric", year: "numeric" });
var clockFmt = new Intl.DateTimeFormat(void 0, { hour: "numeric", minute: "2-digit", second: "2-digit" });
function formatDuration(ms) {
  const min = Math.floor(Math.max(0, ms) / 6e4);
  if (min < 1)
    return "less than 1 min";
  if (min < 60)
    return `${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24)
    return min % 60 ? `${h} h ${min % 60} min` : `${h} h`;
  const d = Math.floor(h / 24);
  return h % 24 ? `${d} d ${h % 24} h` : `${d} d`;
}
var pctFmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 0, signDisplay: "exceptZero" });
var pctFineFmt = new Intl.NumberFormat(void 0, { maximumFractionDigits: 1, signDisplay: "exceptZero" });

// src/data/cron.ts
var RANGES = [
  [0, 59],
  [0, 23],
  [1, 31],
  [1, 12],
  [0, 7]
];
var NAMES = { sun: 0, mon: 1, tue: 2, wed: 3, thu: 4, fri: 5, sat: 6, jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
function field(text2, [lo, hi]) {
  const out = /* @__PURE__ */ new Set();
  for (const part of text2.replace(/[A-Za-z]{3}/g, (n) => n.toLowerCase() in NAMES ? String(NAMES[n.toLowerCase()]) : n).split(",")) {
    const m = /^(\*|(\d+)(?:-(\d+))?)(?:\/(\d+))?$/.exec(part.trim());
    if (!m)
      return void 0;
    const step = m[4] ? Number(m[4]) : 1;
    const from = m[1] === "*" ? lo : Number(m[2]);
    const to = m[1] === "*" ? hi : m[3] !== void 0 ? Number(m[3]) : m[4] ? hi : from;
    if (step < 1 || from < lo || to > hi || from > to)
      return void 0;
    for (let v = from; v <= to; v += step)
      out.add(v);
  }
  return out.size ? out : void 0;
}
var DAY_MS = 864e5;
var HORIZON_DAYS = 400;
var known = /* @__PURE__ */ new Map();
function cronLongestGapMinutes(cron, from = Date.UTC(2026, 0, 5)) {
  const key = `${cron ?? ""}|${from}`;
  if (known.has(key))
    return known.get(key);
  const gap = longestGap(cron, from);
  known.set(key, gap);
  return gap;
}
function longestGap(cron, from) {
  const f = (cron ?? "").trim().split(/\s+/);
  if (f.length !== 5)
    return void 0;
  const sets = f.map((v, i) => field(v, RANGES[i]));
  if (sets.some((s) => !s))
    return void 0;
  const [mins, hours, doms, months, dows] = sets;
  if (dows.has(7))
    dows.add(0);
  const domAny = f[2] === "*";
  const dowAny = f[4] === "*";
  let previous;
  let longest = 0;
  let count = 0;
  const start = Math.floor(from / DAY_MS) * DAY_MS;
  const sortedHours = [...hours].sort((a, b) => a - b);
  const sortedMins = [...mins].sort((a, b) => a - b);
  for (let d = 0; d < HORIZON_DAYS; d++) {
    const day = new Date(start + d * DAY_MS);
    if (!months.has(day.getUTCMonth() + 1))
      continue;
    const domOk = doms.has(day.getUTCDate());
    const dowOk = dows.has(day.getUTCDay());
    if (!(domAny || dowAny ? domOk && dowOk : domOk || dowOk))
      continue;
    for (const h of sortedHours)
      for (const m of sortedMins) {
        const at = d * 1440 + h * 60 + m;
        if (previous !== void 0)
          longest = Math.max(longest, at - previous);
        previous = at;
        count++;
      }
  }
  return count < 2 ? void 0 : longest;
}

// src/data/thresholds.ts
var DEFAULT_THRESHOLDS = { allowableSilenceMinutes: 15, expectedDelayMinutes: 0 };
var DEFAULT_SETTINGS = { version: 1, defaults: DEFAULT_THRESHOLDS, rules: {}, overrides: {}, untracked: [], snoozed: {} };
var SNOOZE_MAX_MINUTES = 30 * 24 * 60;
var SNOOZE_KEPT_MS = 7 * 24 * 60 * 6e4;
var snoozedUntil = (settings, rowId, now) => {
  const until = settings.snoozed[rowId];
  return until !== void 0 && until > now ? until : void 0;
};
var typeRule = (type) => `type:${type}`;
var groupRule = (group) => `group:${group}`;
var RULE_KEY = /^(type|group):./;
function rowScope(rowId) {
  const m = /^([^/]+)\/([^:/]+):/.exec(rowId);
  return m ? { group: m[1], type: m[2] } : void 0;
}
var MAX_MINUTES = 7 * 24 * 60;
var MIN_SILENCE = 1;
function minutes(v, min) {
  if (typeof v !== "number" || !Number.isFinite(v))
    return void 0;
  return Math.min(MAX_MINUTES, Math.max(min, Math.round(v)));
}
function parseSettings(raw) {
  const obj = raw && typeof raw === "object" ? raw : {};
  const d = obj.defaults && typeof obj.defaults === "object" ? obj.defaults : {};
  const defaults = {
    allowableSilenceMinutes: minutes(d.allowableSilenceMinutes, MIN_SILENCE) ?? DEFAULT_THRESHOLDS.allowableSilenceMinutes,
    expectedDelayMinutes: minutes(d.expectedDelayMinutes, 0) ?? DEFAULT_THRESHOLDS.expectedDelayMinutes
  };
  return {
    version: 1,
    defaults,
    rules: partials(obj.rules, (key) => RULE_KEY.test(key)),
    overrides: partials(obj.overrides, () => true),
    // Whole Sources only (`<group>/<type>:<id>`): a token is tracked with its Source.
    untracked: Array.isArray(obj.untracked) ? [...new Set(obj.untracked.filter((x) => typeof x === "string" && rowScope(x) !== void 0 && !x.includes("#")))].sort() : [],
    snoozed: Object.fromEntries(
      Object.entries(obj.snoozed && typeof obj.snoozed === "object" && !Array.isArray(obj.snoozed) ? obj.snoozed : {}).filter(
        (e) => rowScope(e[0]) !== void 0 && !e[0].includes("#") && typeof e[1] === "number" && Number.isFinite(e[1])
      )
    ),
    updatedAt: typeof obj.updatedAt === "number" ? obj.updatedAt : void 0,
    updatedBy: typeof obj.updatedBy === "string" ? obj.updatedBy : void 0
  };
}
function partials(raw, keyOk) {
  const out = {};
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    return out;
  for (const [key, value] of Object.entries(raw)) {
    if (!keyOk(key) || !value || typeof value !== "object")
      continue;
    const v = value;
    const o = {};
    const s = minutes(v.allowableSilenceMinutes, MIN_SILENCE);
    const dl = minutes(v.expectedDelayMinutes, 0);
    if (s !== void 0)
      o.allowableSilenceMinutes = s;
    if (dl !== void 0)
      o.expectedDelayMinutes = dl;
    if (Object.keys(o).length > 0)
      out[key] = o;
  }
  return out;
}
var schedules = /* @__PURE__ */ new Map();
var isCollectorRowId = (rowId) => /^[^/]+\/collection:/.test(rowId);
function registerCollectorSchedules(entries) {
  for (const [id, cron] of entries)
    schedules.set(id, { gap: cronLongestGapMinutes(cron), kind: "collector" });
}
function registerPullSchedules(entries) {
  for (const [id, gap] of entries) {
    if (gap !== void 0 && gap > 0)
      schedules.set(id, { gap, kind: "pull" });
    else
      schedules.delete(id);
  }
}
function scheduleBase(gapMinutes) {
  const gap = gapMinutes ?? 24 * 60;
  return { allowableSilenceMinutes: Math.min(MAX_MINUTES, Math.max(MIN_SILENCE, Math.ceil(2 * gap))), expectedDelayMinutes: 15 };
}
var isScheduledRowId = (rowId) => isCollectorRowId(rowId) || schedules.get(rowId)?.kind === "pull";
function levels(settings, rowId) {
  if (isCollectorRowId(rowId))
    return [
      { kind: "override", values: settings.overrides[rowId] },
      { kind: "schedule", values: scheduleBase(schedules.get(rowId)?.gap) }
    ];
  const parent = parentRowId(rowId);
  const scope = rowScope(rowId);
  const pull = schedules.get(rowId);
  return [
    { kind: "override", values: settings.overrides[rowId] },
    { kind: "source", values: parent !== rowId ? settings.overrides[parent] : void 0 },
    { kind: "type", key: scope?.type, values: scope ? settings.rules[typeRule(scope.type)] : void 0 },
    { kind: "group", key: scope?.group, values: scope ? settings.rules[groupRule(scope.group)] : void 0 },
    pull?.kind === "pull" ? { kind: "schedule", values: scheduleBase(pull.gap) } : { kind: "default", values: settings.defaults }
  ];
}
function thresholdsFor(settings, rowId) {
  const own = schedules.get(rowId);
  const merged = isCollectorRowId(rowId) || own?.kind === "pull" ? scheduleBase(own?.gap) : { ...settings.defaults };
  for (const level of levels(settings, rowId).reverse())
    Object.assign(merged, level.values);
  return merged;
}
function allowanceMs(t) {
  return (t.allowableSilenceMinutes + t.expectedDelayMinutes) * 6e4;
}
function maxAllowanceMs(settings, upToMs = Infinity) {
  let max = 0;
  const consider = (ms) => {
    if (ms <= upToMs)
      max = Math.max(max, ms);
  };
  consider(allowanceMs(settings.defaults));
  const rules = (prefix) => [void 0, ...Object.entries(settings.rules).filter(([k]) => k.startsWith(prefix)).map(([, v]) => v)];
  for (const g of rules("group:"))
    for (const t of rules("type:"))
      consider(allowanceMs({ ...settings.defaults, ...g, ...t }));
  for (const key of Object.keys(settings.overrides))
    if (!isScheduledRowId(key))
      consider(allowanceMs(thresholdsFor(settings, key)));
  return max;
}
var RECENT_MIN_LOOKBACK_SECONDS = 2 * 60 * 60;
var RECENT_MAX_LOOKBACK_SECONDS = 6 * 60 * 60;
function recentQueryShape(settings) {
  const fits2 = maxAllowanceMs(settings, (RECENT_MAX_LOOKBACK_SECONDS - 60) * 1e3);
  const lookbackSeconds = Math.min(RECENT_MAX_LOOKBACK_SECONDS, Math.max(RECENT_MIN_LOOKBACK_SECONDS, Math.ceil(fits2 / 1e3) + 60));
  return { lookbackSeconds, windowSeconds: 60 };
}
function longQueryShape(settings) {
  const lookbackSeconds = Math.ceil(maxAllowanceMs(settings) / 1e3) + 60;
  if (lookbackSeconds <= RECENT_MAX_LOOKBACK_SECONDS)
    return void 0;
  return { lookbackSeconds, windowSeconds: Math.ceil(lookbackSeconds / 360 / 60) * 60 };
}

// src/data/settingsStore.ts
var SETTINGS_KEY = "settings/thresholds";
function unwrapKvValue(text2) {
  let v = text2;
  for (let i = 0; i < 3 && typeof v === "string"; i++) {
    try {
      v = JSON.parse(v);
    } catch {
      return void 0;
    }
  }
  if (v && typeof v === "object" && !("defaults" in v)) {
    const o = v;
    if ("value" in o)
      return unwrapKvValue(typeof o.value === "string" ? o.value : JSON.stringify(o.value));
    if (Array.isArray(o.items) && o.items.length === 1)
      return unwrapKvValue(JSON.stringify(o.items[0]));
  }
  return v;
}
async function keyExists(t, key, signal) {
  try {
    const res = await t("/kvstore/keys", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ prefix: key.slice(0, key.lastIndexOf("/") + 1) }),
      signal
    });
    if (!res.ok)
      return void 0;
    const body = await res.json();
    const list = Array.isArray(body) ? body : Array.isArray(body?.items) ? body.items : void 0;
    if (!list)
      return void 0;
    return list.some((k) => k === key || k?.key === key);
  } catch {
    return void 0;
  }
}
async function kvRead(t, key, signal) {
  if (await keyExists(t, key, signal) === false)
    return void 0;
  const res = await t(`/kvstore/${key}`, { signal });
  if (res.status === 404)
    return void 0;
  if (!res.ok)
    throw new ApiError(res.status, "/kvstore", errorDetail(await res.text().catch(() => "")));
  const text2 = await res.text();
  if (!text2.trim())
    return void 0;
  const value = unwrapKvValue(text2);
  return value === void 0 ? UNREADABLE_VALUE : value;
}
var UNREADABLE_VALUE = Object.freeze({});
var UnreadableSettingsError = class extends Error {
  constructor(what = "allowances") {
    super(`The saved ${what} are not in a form this app can read`);
  }
};
async function kvWrite(t, key, value) {
  const res = await t(`/kvstore/${key}`, {
    method: "PUT",
    headers: { "content-type": "text/plain" },
    body: JSON.stringify(value)
  });
  if (!res.ok)
    throw new ApiError(res.status, "/kvstore", errorDetail(await res.text().catch(() => "")));
}
function isSettingsDoc(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    return false;
  const o = raw;
  return o.version === 1 || o.defaults !== null && typeof o.defaults === "object";
}
async function loadSettings(t, signal) {
  const raw = await kvRead(t, SETTINGS_KEY, signal);
  if (raw === void 0)
    return DEFAULT_SETTINGS;
  if (!isSettingsDoc(raw))
    throw new UnreadableSettingsError();
  return parseSettings(raw);
}

// src/data/tokenAlerts.ts
var TOKEN_SEARCH_PREFIX = "dsh_tokens_";
var TOKEN_ALERTS_KEY = "state/token-alerts";
var SAVED = "/m/default_search/search/saved";
var FORWARD = "/search/notifications";
function shortHash(s) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++)
    h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return (h >>> 0).toString(16).padStart(8, "0").slice(0, 6);
}
function tokenSearchId(deliveryKey) {
  if (deliveryKey === "default")
    return `${TOKEN_SEARCH_PREFIX}default`;
  const safe = deliveryKey.replace(/[^A-Za-z0-9_]/g, "_").slice(0, 40);
  return `${TOKEN_SEARCH_PREFIX}p_${safe}${safe === deliveryKey ? "" : `_${shortHash(deliveryKey)}`}`;
}
var tokenNotifyId = (searchId) => `${searchId}_notify`;
function chosenTokens(model, settings, implicit = true) {
  if (!settings.enabled)
    return [];
  const bySource = new Map(model.sources.map((s) => [s.id, s]));
  const byToken = new Map((model.tokens ?? []).map((t) => [t.id, t]));
  const alertingRows = new Set(settings.alerting);
  const ids = new Set(Object.keys(settings.tokens));
  if (implicit)
    for (const t of model.tokens ?? [])
      ids.add(t.id);
  const out = [];
  for (const rowId of ids) {
    const choice = tokenChoice(settings, rowId);
    if (choice === "off")
      continue;
    const hash2 = rowId.indexOf("#");
    const source = hash2 > 0 ? bySource.get(rowId.slice(0, hash2)) : void 0;
    if (!source || source.disabled || source.status === "untracked" && source.snoozedUntil === void 0)
      continue;
    if (choice === "source" && !alertingRows.has(source.id))
      continue;
    const token = byToken.get(rowId);
    if (token && (token.disabled || token.status === "untracked" && token.snoozedUntil === void 0))
      continue;
    const profile = choice === "default" ? void 0 : choice === "source" ? profileOf(settings, source.id) : settings.profiles.find((p) => p.id === choice);
    const deliveryKey = profile ? profile.id : "default";
    out.push({ rowId, source, deliveryKey, searchId: tokenSearchId(deliveryKey), ...token ? { token } : {} });
  }
  return out.sort((x, y) => x.rowId.localeCompare(y.rowId));
}
function chosenPullSources(model, settings) {
  if (!settings.enabled)
    return [];
  const on = new Set(settings.alerting);
  return model.sources.filter((s) => s.pull && on.has(s.id) && !s.disabled && !(s.status === "untracked" && s.snoozedUntil === void 0)).map((source) => {
    const deliveryKey = profileOf(settings, source.id)?.id ?? "default";
    return { source, deliveryKey, searchId: tokenSearchId(deliveryKey) };
  });
}
function chosenCollectors(model, settings) {
  if (!settings.enabled)
    return [];
  const on = new Set(settings.alerting);
  return (model.collectors ?? []).filter((c) => c.collector?.scheduled && on.has(c.id) && !c.disabled && !(c.status === "untracked" && c.snoozedUntil === void 0)).map((row) => {
    const deliveryKey = profileOf(settings, row.id)?.id ?? "default";
    return { row, deliveryKey, searchId: tokenSearchId(deliveryKey) };
  }).sort((a, b) => a.row.id.localeCompare(b.row.id));
}
var alertingTokens = (model, settings) => chosenTokens(model, settings).filter((c) => c.token !== void 0);
var rec = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
var str2 = (v) => typeof v === "string" ? v : void 0;
function parseTokenSearches(payload) {
  if (!Array.isArray(rec(payload)?.items) && !Array.isArray(payload))
    throw new Error("Cribl Search's saved searches weren't in the form this app reads");
  const items = Array.isArray(payload) ? payload : rec(payload).items;
  const out = [];
  for (const it of items) {
    const o = rec(it);
    const id = str2(o?.id);
    if (!o || !id || !id.startsWith(TOKEN_SEARCH_PREFIX))
      continue;
    const schedule = rec(o.schedule);
    const n = (Array.isArray(rec(schedule?.notifications)?.items) ? rec(schedule.notifications).items : []).map(rec).find((x) => x && str2(x.id) === tokenNotifyId(id));
    const emailByTarget = {};
    let subject;
    let body;
    for (const c of Array.isArray(n?.targetConfigs) ? n.targetConfigs : []) {
      const conf = rec(rec(c)?.conf);
      const r = rec(conf?.emailRecipient);
      const to = str2(r?.to);
      const tid = str2(rec(c)?.id);
      if (tid && to)
        emailByTarget[tid] = { to, ...str2(r?.cc) ? { cc: str2(r?.cc) } : {}, ...str2(r?.bcc) ? { bcc: str2(r?.bcc) } : {} };
      subject ??= str2(conf?.subject);
      body ??= str2(conf?.body);
    }
    out.push({
      id,
      name: str2(o.name) ?? "",
      query: str2(o.query) ?? "",
      ...schedule?.enabled === true ? { scheduled: true } : {},
      ...n ? {
        notification: {
          id: str2(n.id),
          targets: Array.isArray(n.targets) ? n.targets.filter((x) => typeof x === "string") : [],
          emailByTarget,
          message: str2(rec(n.conf)?.message),
          subject,
          body
        }
      } : {},
      raw: o
    });
  }
  return out;
}
async function loadTokenSearches(t, signal) {
  return parseTokenSearches(await apiGet(t, SAVED, signal));
}
var QUEUE_LIMIT_MS = 60 * 6e4;
var SEND_LIMIT_MS = 9e4;
function parseRows(v) {
  return (Array.isArray(v) ? v : []).map(rec).filter((r) => Boolean(r && typeof r.rowId === "string" && (r.status === "Overdue" || r.status === "Back" || r.status === "Failed"))).map((r) => ({
    rowId: String(r.rowId),
    status: r.status,
    ...r.kind === "collector" || r.kind === "part" ? { kind: r.kind } : {},
    ...typeof r.description === "string" && r.description ? { description: r.description } : {},
    ...typeof r.job === "string" && r.job ? { job: r.job } : {},
    token: String(r.token ?? ""),
    source: String(r.source ?? ""),
    group: String(r.group ?? ""),
    detail: String(r.detail ?? ""),
    link: String(r.link ?? ""),
    at: Number(r.at) || 0
  }));
}
function parseTokenAlertState(raw) {
  const o = rec(raw);
  const seen = {};
  for (const [k, v] of Object.entries(rec(o?.seen) ?? {}))
    if (typeof rec(v)?.overdue === "boolean")
      seen[k] = { overdue: rec(v).overdue };
  const pending = {};
  for (const [k, v] of Object.entries(rec(o?.pending) ?? {})) {
    const rows = parseRows(v);
    if (k.startsWith(TOKEN_SEARCH_PREFIX) && rows.length)
      pending[k] = rows;
  }
  const sendingRaw = rec(o?.sending);
  const sendingRows = {};
  for (const [k, v] of Object.entries(rec(sendingRaw?.rows) ?? {})) {
    const rows = parseRows(v);
    if (k.startsWith(TOKEN_SEARCH_PREFIX) && rows.length)
      sendingRows[k] = rows;
  }
  const sending = typeof sendingRaw?.at === "number" && Object.keys(sendingRows).length ? { at: sendingRaw.at, rows: sendingRows } : void 0;
  return { seen, pending, ...sending ? { sending } : {} };
}
function alertSummary(rows) {
  const cap = (v) => v.length > 200 ? `${v.slice(0, 199)}\u2026` : v;
  const parts = rows.map((r) => cap(r.kind === "collector" ? `collector ${r.source.replace(/^collection:/, "")} in ${r.group}: ${r.detail}` : r.kind === "part" ? `${r.source} in ${r.group}: ${r.detail}` : `${r.token} of ${r.source} in ${r.group}: ${r.detail}`));
  let out = "";
  for (let i = 0; i < parts.length; i++) {
    const next = out ? `${out}; ${parts[i]}` : parts[i];
    if (out && next.length > 400)
      return `${out}; and ${parts.length - i} more`;
    out = next;
  }
  return out;
}
function sourceLink(linkBase, s) {
  if (!linkBase)
    return "";
  let host = "";
  try {
    host = new URL(linkBase).hostname;
  } catch {
    return "";
  }
  const cloud = /\.cribl\.cloud$/i.test(host);
  const g = encodeURIComponent(s.group);
  return cloud && NO_STREAM_PAGE.has(s.type) ? `${linkBase}/stream/m/${g}/inputs` : `${linkBase}/stream/m/${g}/inputs/${encodeURIComponent(criblType(s.type))}/${encodeURIComponent(s.sourceId)}`;
}
function nextTokenAlerts(state, alerting, settings, now, readable) {
  const seen = {};
  const pending = Object.fromEntries(Object.entries(state.pending).map(([k, v]) => [k, [...v]]));
  const present = new Set(alerting.map((a) => a.token.id));
  const stillOn = (id) => {
    const choice = tokenChoice(settings, id);
    return choice !== "off" && (choice !== "source" || settings.alerting.includes(id.slice(0, Math.max(0, id.indexOf("#")))));
  };
  for (const [id, v] of Object.entries(state.seen))
    if (!present.has(id) && (!settings || stillOn(id)))
      seen[id] = v;
  for (const a of alerting) {
    const t = a.token;
    const prev = state.seen[t.id];
    if (!readable || t.status === "unknown" || t.snoozedUntil !== void 0 || a.source.snoozedUntil !== void 0) {
      if (prev)
        seen[t.id] = prev;
      continue;
    }
    const overdue = t.status === "overdue" || t.status === "nodata";
    seen[t.id] = { overdue };
    if (prev ? prev.overdue === overdue : !overdue)
      continue;
    const queued = pending[a.searchId] ??= [];
    const status = overdue ? "Overdue" : "Back";
    if (queued.some((r) => r.rowId === t.id && r.status === status))
      continue;
    const opposite = queued.findIndex((r) => r.rowId === t.id && r.status !== status);
    if (opposite >= 0) {
      queued.splice(opposite, 1);
      continue;
    }
    queued.push({
      rowId: t.id,
      status: overdue ? "Overdue" : "Back",
      token: t.token.label,
      source: criblInput(a.source.type, a.source.sourceId),
      group: a.source.group,
      detail: overdue ? `Overdue, no events for longer than its ${formatDuration(t.allowanceMs)} allowance` : "Back, sending again",
      link: sourceLink(settings?.linkBase, a.source),
      at: now
    });
  }
  for (const [k, v] of Object.entries(pending))
    if (v.length === 0)
      delete pending[k];
  return { seen, pending, ...state.sending ? { sending: state.sending } : {} };
}
function forwardBody(searchId, rows, now, batch = 0) {
  const summary = alertSummary(rows);
  const message3 = `Cribl alert: ${summary}`.slice(0, 1e3);
  const description = rows.length === 1 ? rows[0].description : void 0;
  const notificationId = tokenNotifyId(searchId);
  const ref = `${searchId}_${now}${batch ? `_${batch}` : ""}`;
  return {
    id: `SEARCH_NOTIFICATION_${notificationId}_${now}${batch ? `_${batch}` : ""}`,
    severity: "warn",
    title: "Cribl alert",
    _raw: message3,
    message: message3,
    _time: now,
    now,
    group: "default_search",
    searchId: ref,
    savedQueryId: searchId,
    searchResultsUrl: "",
    notificationId,
    __attachments: [],
    resultSet: rows.map((r) => ({
      status: r.status,
      token: r.token,
      source: r.source,
      group: r.group,
      detail: r.detail,
      link: r.link,
      summary,
      descriptionBlock: description ? `

Description: ${description}` : "",
      linkBlock: description ? "" : r.link ? `

Open in Cribl: ${r.link}` : ""
    })),
    origin_metadata: { itemType: "link", id: ref, type: "search", product: "search", groupId: "" }
  };
}
async function runTokenAlerts(t, model, settings, now, readable) {
  const done = [];
  const failed = [];
  const stored = parseTokenAlertState(await kvRead(t, TOKEN_ALERTS_KEY));
  const chosen = settings ? settings.enabled && (Object.keys(settings.tokens).length > 0 || settings.alerting.length > 0) : false;
  if (!chosen && Object.keys(stored.pending).length === 0 && Object.keys(stored.seen).length === 0 && !stored.sending)
    return { done, failed };
  const before = { seen: stored.seen, pending: { ...stored.pending } };
  if (stored.sending && now - stored.sending.at >= SEND_LIMIT_MS) {
    for (const [id, rows] of Object.entries(stored.sending.rows))
      before.pending[id] = [...rows, ...before.pending[id] ?? []];
  } else if (stored.sending)
    before.sending = stored.sending;
  const alerting = model && settings ? alertingTokens(model, settings) : [];
  const next = nextTokenAlerts(before, alerting, settings, now, readable && model !== void 0 && !model.tokensFailed);
  if (Object.keys(next.pending).length === 0) {
    if (JSON.stringify(next) !== JSON.stringify(stored))
      await kvWrite(t, TOKEN_ALERTS_KEY, next).catch((err) => failed.push(`token alerts: couldn't record them (${err instanceof Error ? err.message : String(err)})`));
    return { done, failed };
  }
  let existing = /* @__PURE__ */ new Set();
  try {
    existing = new Set((await loadTokenSearches(t)).filter((e) => e.notification).map((e) => e.id));
  } catch (err) {
    failed.push(`alerts: Cribl Search's saved searches couldn't be read (${err instanceof Error ? err.message : String(err)}), so nothing was sent`);
  }
  const sending = [];
  const after = { seen: next.seen, pending: {} };
  for (const [id, rows] of Object.entries(next.pending)) {
    if (existing.has(id))
      sending.push([id, rows]);
    else {
      const kept = rows.filter((r) => now - r.at < QUEUE_LIMIT_MS);
      if (kept.length)
        after.pending[id] = kept;
    }
  }
  if (sending.length)
    after.sending = { at: now, rows: Object.fromEntries(sending) };
  try {
    await kvWrite(t, TOKEN_ALERTS_KEY, after);
  } catch (err) {
    failed.push(`token alerts: couldn't record them (${err instanceof Error ? err.message : String(err)}), so nothing was sent`);
    return { done, failed };
  }
  if (sending.length === 0)
    return { done, failed };
  for (const [id, rows] of sending) {
    const batches = [rows.filter((r) => !r.kind), ...rows.filter((r) => r.kind).map((r) => [r])].filter((b) => b.length > 0);
    for (const [n, batch] of batches.entries()) {
      let ok = false;
      try {
        await apiWrite(t, "POST", FORWARD, forwardBody(id, batch, now, n));
        done.push(`sent ${alertSummary(batch)} through ${id}`);
        ok = true;
      } catch (err) {
        failed.push(`alerts ${id}: ${err instanceof Error ? err.message : String(err)}`);
      }
      if (after.sending) {
        const left = (after.sending.rows[id] ?? []).filter((r) => !batch.includes(r));
        if (left.length)
          after.sending.rows[id] = left;
        else
          delete after.sending.rows[id];
      }
      if (!ok)
        (after.pending[id] ??= []).push(...batch);
      if (batches.length > 1 || sending.length > 1)
        await kvWrite(t, TOKEN_ALERTS_KEY, after).catch(() => void 0);
    }
  }
  delete after.sending;
  await kvWrite(t, TOKEN_ALERTS_KEY, after).catch((err) => failed.push(`token alerts: couldn't record what was sent (${err instanceof Error ? err.message : String(err)}); a later run may send it again`));
  return { done, failed };
}

// src/data/ranges.ts
var RANGES2 = [
  { key: "1h", label: "Last 1 hour", seconds: 3600, windowSeconds: 60 },
  { key: "6h", label: "Last 6 hours", seconds: 21600, windowSeconds: 300 },
  { key: "12h", label: "Last 12 hours", seconds: 43200, windowSeconds: 600 },
  { key: "24h", label: "Last 24 hours", seconds: 86400, windowSeconds: 900 },
  { key: "7d", label: "Last 7 days", seconds: 604800, windowSeconds: 7200 }
];
function rangeFor(key) {
  return RANGES2.find((r) => r.key === key) ?? RANGES2[3];
}
function bucketStarts(range, now) {
  const w = range.windowSeconds * 1e3;
  const count = Math.round(range.seconds / range.windowSeconds);
  const last = Math.floor(now / w) * w;
  return Array.from({ length: count }, (_, i) => last - (count - 1 - i) * w);
}

// src/data/activity.ts
var FIELDS = { events: "events", bytes: "bytes", recent: "recentEvents", recentBytes: "recentBytes", health: "health", rejected: "rejected" };
function toEpochMs(t) {
  if (typeof t !== "number" || !Number.isFinite(t))
    return void 0;
  return t < 1e11 ? t * 1e3 : t;
}
function num(v) {
  return typeof v === "number" && Number.isFinite(v) && v > 0 ? v : 0;
}
function resolveKey(key, known2) {
  if (known2.has(key))
    return { base: key, variant: false };
  let k = key;
  for (let i = k.lastIndexOf(":"); i > 0; i = k.lastIndexOf(":")) {
    k = k.slice(0, i);
    if (known2.has(k))
      return { base: k, variant: true };
  }
  return void 0;
}
var Slot = class {
  constructor() {
    this.base = 0;
    this.variants = 0;
    this.hasBase = false;
  }
  add(value, variant) {
    if (variant)
      this.variants += value;
    else {
      this.base += value;
      this.hasBase = true;
    }
  }
  get value() {
    return this.hasBase ? this.base : this.variants;
  }
};
function rowTime(row) {
  return toEpochMs(row.starttime) ?? toEpochMs(row._time);
}
var UNTIMED = -1;
function rowKeys(row) {
  const input = row.input;
  const group = row.__worker_group;
  if (typeof input !== "string" || !input)
    return void 0;
  if (typeof group !== "string" || !group)
    return void 0;
  return { input, group };
}
function classify(s) {
  if (s.disabled)
    return "disabled";
  if (!s.recentAvailable)
    return s.events > 0 ? "unknown" : "nodata";
  if (s.lastActiveEnd !== void 0 && s.now - s.lastActiveEnd <= s.allowanceMs)
    return "active";
  if (s.events <= 0 && s.lastActiveEnd === void 0)
    return "nodata";
  return "overdue";
}
function healthLevel(level) {
  if (level === void 0)
    return void 0;
  if (level >= 2)
    return "error";
  if (level >= 1)
    return "degraded";
  return "healthy";
}
function buildActivity(input) {
  const { sources, range, now, seriesRows, recentRows, healthRows } = input;
  const w = range.windowSeconds * 1e3;
  let anchor = now;
  for (const row of seriesRows) {
    const t = rowTime(row);
    if (t !== void 0 && t > anchor && t <= now + w)
      anchor = t;
  }
  const buckets = bucketStarts(range, anchor);
  const start = buckets[0];
  const knownByGroup = /* @__PURE__ */ new Map();
  const accs = /* @__PURE__ */ new Map();
  const collectors = input.collectors ?? [];
  for (const s of [...sources, ...collectors]) {
    const base = `${s.type}:${s.id}`;
    let known2 = knownByGroup.get(s.group);
    if (!known2)
      knownByGroup.set(s.group, known2 = /* @__PURE__ */ new Set());
    known2.add(base);
    const acc = { windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map() };
    accs.set(`${s.group}/${base}`, acc);
    const alias = criblInput(s.type, s.id);
    if (alias !== base) {
      known2.add(alias);
      accs.set(`${s.group}/${alias}`, acc);
    }
  }
  const unmatched = /* @__PURE__ */ new Set();
  const pullIds = /* @__PURE__ */ new Map();
  for (const s of sources)
    if (s.pull)
      pullIds.set(`${s.group}/${s.id}`, s);
  const parts = /* @__PURE__ */ new Map();
  const partAcc = (group, input2) => {
    const m = /^collection:([^:]+):(.+)$/.exec(input2);
    if (!m || !pullIds.has(`${group}/${m[1]}`))
      return void 0;
    const key = `${group}/${m[1]}`;
    let byPart = parts.get(key);
    if (!byPart)
      parts.set(key, byPart = /* @__PURE__ */ new Map());
    let acc = byPart.get(m[2]);
    if (!acc)
      byPart.set(m[2], acc = { windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map() });
    return acc;
  };
  const resolved = /* @__PURE__ */ new Map();
  const noneKnown = /* @__PURE__ */ new Set();
  const match = (row, hasData) => {
    const keys = rowKeys(row);
    if (!keys)
      return void 0;
    const k = `${keys.group}\0${keys.input}`;
    let hit = resolved.get(k);
    if (hit === void 0) {
      const r = resolveKey(keys.input, knownByGroup.get(keys.group) ?? noneKnown);
      const acc = r && accs.get(`${keys.group}/${r.base}`);
      const part = acc ? void 0 : partAcc(keys.group, keys.input);
      hit = r && acc ? { acc, variant: r.variant } : part ? { acc: part, variant: false } : null;
      resolved.set(k, hit);
    }
    if (!hit) {
      if (hasData && !keys.input.startsWith("collection:"))
        unmatched.add(`${keys.group}/${keys.input}`);
      return void 0;
    }
    return hit;
  };
  for (const row of seriesRows) {
    const events = num(row[FIELDS.events]);
    const bytes = num(row[FIELDS.bytes]);
    const m = match(row, events > 0 || bytes > 0);
    if (m)
      addSeries(m.acc, row, events, bytes, m.variant);
  }
  for (const row of input.statusRows ?? []) {
    const m = match(row, false);
    if (m)
      addBasis(m.acc, row, num(row[FIELDS.events]), m.variant);
  }
  const rw = input.recentWindowSeconds * 1e3;
  let recentLast = Math.floor(now / rw) * rw;
  for (const row of recentRows ?? []) {
    const events = num(row[FIELDS.recent]);
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const m = match(row, events > 0);
    if (!m)
      continue;
    if (t > recentLast && t <= now + rw)
      recentLast = t;
    addRecent(m.acc, t, events, num(row[FIELDS.recentBytes]), m.variant);
  }
  for (const row of input.longRows ?? []) {
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const m = match(row, false);
    if (m)
      addLong(m.acc, t, num(row[FIELDS.recent]), m.variant);
  }
  const recentFirst = Math.floor(input.recentEarliest / rw) * rw;
  const recentBuckets = recentRows === void 0 || recentLast < recentFirst ? [] : Array.from({ length: (recentLast - recentFirst) / rw + 1 }, (_, i) => recentFirst + i * rw);
  for (const row of healthRows ?? []) {
    const level = row[FIELDS.health];
    if (typeof level !== "number" || !Number.isFinite(level))
      continue;
    const m = match(row, false);
    if (m && (m.acc.health === void 0 || level > m.acc.health))
      m.acc.health = level;
  }
  const ctx = {
    now,
    w,
    rw,
    start,
    buckets,
    recentBuckets,
    recentFirst,
    range,
    recentAvailable: recentRows !== void 0,
    recentEarliest: input.recentEarliest,
    recentWindowSeconds: input.recentWindowSeconds,
    basis: input.statusRows !== void 0,
    wb: (input.statusWindowSeconds ?? range.windowSeconds) * 1e3,
    ...input.longWindowSeconds !== void 0 ? { long: { windowMs: input.longWindowSeconds * 1e3, read: input.longRows !== void 0 } } : {}
  };
  for (const [key, byPart] of parts) {
    const s = pullIds.get(key);
    const own = accs.get(`${s.group}/${s.type}:${s.id}`);
    const together = mergeAccs([...byPart.values()], void 0);
    if (totalEvents(together) > totalEvents(own))
      accs.set(`${s.group}/${s.type}:${s.id}`, { ...together, health: own.health === void 0 ? together.health : Math.max(own.health, together.health ?? 0) });
  }
  const recentSpan = now - input.recentEarliest;
  const judgeLong = (row, rec3) => rec3.pull && rec3.pullGapMinutes !== void 0 && row.allowanceMs > recentSpan && !row.disabled ? bySchedule(row, now) : row;
  const out = sources.map((s) => {
    const id = `${s.group}/${s.type}:${s.id}`;
    const acc = accs.get(id);
    return {
      id,
      sourceId: s.id,
      name: s.id,
      group: s.group,
      type: s.type,
      disabled: s.disabled,
      health: healthLevel(acc.health),
      ...summarize(acc, s.disabled, input.allowanceMs(id), ctx),
      ...s.tokens ? { tokens: { count: s.tokens.count, perToken: s.tokens.perToken, split: false } } : {},
      ...s.pull ? { pull: true, ...s.pullGapMinutes !== void 0 ? { pullEveryMinutes: s.pullGapMinutes } : {} } : {}
    };
  });
  for (let i = 0; i < out.length; i++) {
    const s = sources[i];
    out[i] = s.pull && s.pullGapMinutes !== void 0 ? judgeLong(out[i], s) : judgeOnLong(out[i], accs.get(out[i].id), ctx);
  }
  const collectorRows = collectors.map((c) => {
    const id = `${c.group}/collection:${c.id}`;
    const summary = summarize(accs.get(id), false, input.allowanceMs(id), ctx);
    const row = {
      id,
      sourceId: c.id,
      name: c.id,
      group: c.group,
      type: "collection",
      disabled: false,
      health: healthLevel(accs.get(id).health),
      ...c.collector ? { collector: c.collector } : {},
      ...summary
    };
    if (c.collector?.scheduled === false)
      return { ...row, status: "untracked" };
    return bySchedule(row, now);
  });
  const partRows = [];
  for (const parent of out) {
    const byPart = parts.get(`${parent.group}/${parent.sourceId}`);
    if (!byPart || !pullIds.has(`${parent.group}/${parent.sourceId}`))
      continue;
    for (const [key, acc] of [...byPart].sort(([a], [b]) => a.localeCompare(b))) {
      const label = key.replace(/_/g, " ");
      partRows.push({
        id: `${parent.id}~${key}`,
        sourceId: parent.sourceId,
        name: `${parent.sourceId} \u203A ${label}`,
        group: parent.group,
        type: parent.type,
        disabled: parent.disabled,
        part: { key, parentId: parent.id },
        health: healthLevel(acc.health),
        ...summarize(acc, parent.disabled, parent.allowanceMs, ctx)
      });
      if (!parent.disabled && parent.allowanceMs > recentSpan && pullIds.get(`${parent.group}/${parent.sourceId}`)?.pullGapMinutes !== void 0)
        partRows[partRows.length - 1] = bySchedule(partRows[partRows.length - 1], now);
      else
        partRows[partRows.length - 1] = judgeOnLong(partRows[partRows.length - 1], acc, ctx);
    }
  }
  const tokens = [];
  const wantsSplit = sources.some((s) => s.tokens?.perToken === "on");
  const tokensFailed = wantsSplit && (input.tokenSeriesRows === void 0 || input.tokenRecentRows === void 0);
  if (wantsSplit && !tokensFailed) {
    sources.forEach((s, i) => {
      if (s.tokens?.perToken !== "on")
        return;
      const { rows, unmatched: unmatched2 } = buildTokenRows(s, out[i], input, { ...ctx, basis: ctx.basis && input.tokenStatusRows !== void 0 });
      if (unmatched2 > 0)
        out[i] = { ...out[i], tokens: { ...out[i].tokens, unmatched: unmatched2 } };
      if (rows.length === 0)
        return;
      tokens.push(...rows);
      out[i] = { ...out[i], tokens: { ...out[i].tokens, split: true } };
    });
  }
  const { untracked, snoozed } = input;
  const track = (s) => {
    if (s.disabled)
      return s;
    const root = s.token ? s.token.parentId : s.id;
    if (untracked?.(root))
      return { ...s, status: "untracked" };
    const until = snoozed?.(root);
    return until !== void 0 ? { ...s, status: "untracked", snoozedUntil: until } : s;
  };
  const sourcesOut = untracked || snoozed ? out.map(track) : out;
  const tokensOut = untracked || snoozed ? tokens.map(track) : tokens;
  const collectorsOut = untracked || snoozed ? collectorRows.map(track) : collectorRows;
  const partsOut = partRows.map((p) => {
    const parent = sourcesOut.find((s) => s.id === p.part.parentId);
    return parent && parent.status === "untracked" && !p.disabled ? { ...p, status: "untracked", ...parent.snoozedUntil !== void 0 ? { snoozedUntil: parent.snoozedUntil } : {} } : p;
  });
  let keptStart;
  if (ctx.basis) {
    for (const acc of accs.values())
      for (const [t, slot] of acc.basis ?? [])
        if (slot.value > 0 && (keptStart === void 0 || t < keptStart))
          keptStart = t;
  } else {
    const first = buckets.findIndex((_, i) => out.some((x) => (x.eventsSeries[i] ?? 0) > 0));
    if (first >= 0)
      keptStart = buckets[first];
  }
  const priorCoverage = {
    coversBefore: ctx.basis ? true : buckets.length > 0 && buckets[0] + w <= recentFirst,
    ...keptStart !== void 0 ? { keptFrom: keptStart + (ctx.basis ? ctx.wb : w) } : {}
  };
  return {
    buckets,
    windowSeconds: range.windowSeconds,
    sources: sourcesOut,
    ...tokensOut.length > 0 ? { tokens: tokensOut } : {},
    ...tokensFailed ? { tokensFailed } : {},
    ...input.collectors ? { collectors: collectorsOut } : {},
    ...partsOut.length > 0 ? { parts: partsOut } : {},
    unmatchedSeries: [...unmatched].sort(),
    recentAvailable: recentRows !== void 0,
    recentWindowSeconds: input.recentWindowSeconds,
    recentBuckets,
    healthAvailable: healthRows !== void 0,
    ...recentRows !== void 0 ? { priorCoverage } : {},
    generatedAt: now
  };
}
var COLLECTOR_STATUS_SPAN_MS = 24 * 36e5;
function bySchedule(row, now) {
  if (row.lastSeen === void 0)
    return { ...row, status: row.allowanceMs <= COLLECTOR_STATUS_SPAN_MS ? "nodata" : "unknown", silentMs: void 0 };
  const silent = Math.max(0, now - (row.lastSeen + (row.lastSeenResolutionSeconds ?? 60) * 1e3));
  return { ...row, silentMs: silent, status: silent > row.allowanceMs ? "overdue" : "active" };
}
function mergeAccs(list, health) {
  const out = { windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map(), health };
  for (const a of list) {
    for (const [t, x] of a.windows) {
      let w = out.windows.get(t);
      if (!w)
        out.windows.set(t, w = { events: new Slot(), bytes: new Slot() });
      w.events.add(x.events.value, false);
      w.bytes.add(x.bytes.value, false);
    }
    for (const [t, x] of a.recent) {
      let w = out.recent.get(t);
      if (!w)
        out.recent.set(t, w = { events: new Slot(), bytes: new Slot() });
      w.events.add(x.events.value, false);
      w.bytes.add(x.bytes.value, false);
    }
    for (const [t, x] of a.basis ?? []) {
      const basis = out.basis ??= /* @__PURE__ */ new Map();
      let slot = basis.get(t);
      if (!slot)
        basis.set(t, slot = new Slot());
      slot.add(x.value, false);
    }
    for (const [t, x] of a.long ?? []) {
      const long = out.long ??= /* @__PURE__ */ new Map();
      let slot = long.get(t);
      if (!slot)
        long.set(t, slot = new Slot());
      slot.add(x.value, false);
    }
    if (a.health !== void 0 && (out.health === void 0 || a.health > out.health))
      out.health = a.health;
  }
  return out;
}
function totalEvents(acc) {
  let n = 0;
  for (const w of acc.windows.values())
    n += w.events.value;
  if (n > 0)
    return n;
  for (const w of acc.basis?.values() ?? [])
    n += w.value;
  if (n > 0)
    return n;
  for (const w of acc.recent.values())
    n += w.events.value;
  return n;
}
function addSeries(acc, row, events, bytes, variant) {
  const t = rowTime(row) ?? UNTIMED;
  let win = acc.windows.get(t);
  if (!win)
    acc.windows.set(t, win = { events: new Slot(), bytes: new Slot() });
  win.events.add(events, variant);
  win.bytes.add(bytes, variant);
}
function addBasis(acc, row, events, variant) {
  const t = rowTime(row);
  if (t === void 0)
    return;
  const basis = acc.basis ??= /* @__PURE__ */ new Map();
  let slot = basis.get(t);
  if (!slot)
    basis.set(t, slot = new Slot());
  slot.add(events, variant);
}
function addLong(acc, t, events, variant) {
  const long = acc.long ??= /* @__PURE__ */ new Map();
  let slot = long.get(t);
  if (!slot)
    long.set(t, slot = new Slot());
  slot.add(events, variant);
}
function judgeOnLong(row, acc, c) {
  const recentSpan = c.now - c.recentEarliest;
  if (!c.long || !c.recentAvailable || row.disabled || row.allowanceMs <= recentSpan || row.status === "active")
    return row;
  const bounds = [];
  if (row.lastSeen !== void 0 && row.status !== "nodata") {
    const res = row.lastSeenResolutionSeconds ?? 60;
    bounds.push({ seen: row.lastSeen, res, end: row.lastSeen + res * 1e3 });
  }
  let last;
  for (const [t, slot] of acc.long ?? [])
    if (slot.value > 0 && (last === void 0 || t > last))
      last = t;
  if (last !== void 0)
    bounds.push({ seen: last, res: c.long.windowMs / 1e3, end: last + c.long.windowMs });
  if (bounds.length === 0)
    return c.long.read || row.allowanceMs <= COLLECTOR_STATUS_SPAN_MS ? row : { ...row, status: "unknown", silentMs: void 0 };
  const b = bounds.reduce((x, y) => y.end < x.end ? y : x);
  const silentMs = Math.max(0, c.now - Math.min(b.end, c.now, c.recentEarliest));
  return { ...row, lastSeen: b.seen, lastSeenResolutionSeconds: b.res, silentMs, status: silentMs > row.allowanceMs ? "overdue" : "active" };
}
function addRecent(acc, t, events, bytes, variant) {
  let slot = acc.recent.get(t);
  if (!slot)
    acc.recent.set(t, slot = { events: new Slot(), bytes: new Slot() });
  slot.events.add(events, variant);
  slot.bytes.add(bytes, variant);
}
function summarize(acc, disabled, allowance, c) {
  const { now, w, rw, start, buckets, recentBuckets, recentFirst } = c;
  let events = 0;
  let bytes = 0;
  let lastSeen;
  const eventsSeries = buckets.map(() => 0);
  const bytesSeries = buckets.map(() => 0);
  for (const [t, win] of acc.windows) {
    const e = win.events.value;
    const b = win.bytes.value;
    events += e;
    bytes += b;
    if (t === UNTIMED)
      continue;
    if (e > 0 && (lastSeen === void 0 || t > lastSeen))
      lastSeen = t;
    const idx = Math.floor((t - start) / w);
    if (idx < 0 || idx >= buckets.length)
      continue;
    eventsSeries[idx] += e;
    bytesSeries[idx] += b;
  }
  let lastActive;
  const recentEvents = recentBuckets.map(() => 0);
  const recentBytes = recentBuckets.map(() => 0);
  for (const [t, slot] of acc.recent) {
    const e = slot.events.value;
    if (e > 0 && (lastActive === void 0 || t > lastActive))
      lastActive = t;
    const idx = (t - recentFirst) / rw;
    if (Number.isInteger(idx) && idx >= 0 && idx < recentBuckets.length) {
      recentEvents[idx] += e;
      recentBytes[idx] += slot.bytes.value;
    }
  }
  const lastActiveEnd = lastActive === void 0 ? void 0 : Math.min(lastActive + rw, now);
  let statusEvents = events;
  let seen = lastSeen;
  if (c.basis) {
    statusEvents = 0;
    seen = void 0;
    for (const [t, slot] of acc.basis ?? []) {
      statusEvents += slot.value;
      if (slot.value > 0 && (seen === void 0 || t > seen))
        seen = t;
    }
  }
  const basisWidth = c.basis ? c.wb : w;
  let seenWidth = basisWidth;
  if (c.basis && seen === void 0 && lastSeen !== void 0) {
    seen = lastSeen;
    seenWidth = w;
  }
  let priorEnd;
  const basisWindows = c.basis ? [...acc.basis ?? []].map(([t, slot]) => [t, slot.value]) : [...acc.windows].filter(([t]) => t !== UNTIMED).map(([t, win]) => [t, win.events.value]);
  for (const [t, e] of basisWindows) {
    if (e <= 0 || t >= recentFirst)
      continue;
    let end;
    if (t + basisWidth <= recentFirst)
      end = t + basisWidth;
    else {
      let inside = 0;
      for (const [rt, slot] of acc.recent)
        if (rt + rw <= t + basisWidth)
          inside += slot.events.value;
      if (e > inside)
        end = recentFirst;
    }
    if (end !== void 0 && (priorEnd === void 0 || end > priorEnd))
      priorEnd = end;
  }
  let lastEventEnd = lastActiveEnd;
  if (lastEventEnd === void 0 && seen !== void 0) {
    lastEventEnd = Math.min(seen + seenWidth, now);
    if (c.recentAvailable)
      lastEventEnd = Math.min(lastEventEnd, c.recentEarliest);
  }
  const precise = lastActive !== void 0 && (seen === void 0 || lastActive >= seen);
  return {
    status: classify({ disabled, events: statusEvents, recentAvailable: c.recentAvailable, lastActiveEnd, allowanceMs: allowance, now }),
    events,
    bytes,
    allowanceMs: allowance,
    lastSeen: precise ? lastActive : seen,
    lastSeenResolutionSeconds: precise ? c.recentWindowSeconds : seen !== void 0 ? seenWidth / 1e3 : void 0,
    silentMs: lastEventEnd === void 0 ? void 0 : Math.max(0, now - lastEventEnd),
    ...priorEnd !== void 0 ? { priorEnd, priorStraddles: priorEnd === recentFirst } : {},
    eventsSeries,
    bytesSeries,
    recentEvents,
    recentBytes
  };
}
var newAcc = () => ({ windows: /* @__PURE__ */ new Map(), recent: /* @__PURE__ */ new Map() });
function buildTokenRows(s, parent, input, c) {
  const all = s.tokens.tokens;
  const descriptionCount = /* @__PURE__ */ new Map();
  for (const t of all)
    if (!t.fp && t.description)
      descriptionCount.set(t.description, (descriptionCount.get(t.description) ?? 0) + 1);
  const matchable = (t) => Boolean(t.fp) || t.description !== void 0 && descriptionCount.get(t.description) === 1;
  const units = [];
  const byKey = /* @__PURE__ */ new Map();
  all.forEach((t, i) => {
    if (!matchable(t))
      return;
    const key = tokenKey(t, i);
    const same = byKey.get(key);
    if (same)
      same.enabled ||= t.enabled;
    else {
      const unit = { key, fp: t.fp, description: t.description, enabled: t.enabled, acc: newAcc(), rejected: 0, listed: true };
      units.push(unit);
      byKey.set(key, unit);
    }
  });
  const unmatched = all.filter((t) => !matchable(t)).length;
  const byFp = new Map(units.filter((u) => u.fp).map((u) => [u.fp, u]));
  const byDescription = new Map(units.filter((u) => !u.fp && u.description).map((u) => [u.description, u]));
  let reported = false;
  const unitOf = (row) => {
    if (row.inputId !== s.id || row.__worker_group !== s.group)
      return void 0;
    reported = true;
    const fp = typeof row.tokenFp === "string" ? row.tokenFp : "";
    const description = typeof row.tokenDescription === "string" && row.tokenDescription.trim() ? row.tokenDescription.trim() : void 0;
    const found = (fp ? byFp.get(fp) : void 0) ?? (description ? byDescription.get(description) : void 0);
    if (found)
      return found;
    if (!fp)
      return void 0;
    const unit = { key: `t${fp}`, fp, description, enabled: true, acc: newAcc(), rejected: 0, listed: false };
    units.push(unit);
    byFp.set(fp, unit);
    return unit;
  };
  for (const row of input.tokenSeriesRows ?? []) {
    const u = unitOf(row);
    if (!u)
      continue;
    addSeries(u.acc, row, num(row[FIELDS.events]), num(row[FIELDS.bytes]), false);
    u.rejected += num(row[FIELDS.rejected]);
  }
  for (const row of input.tokenRecentRows ?? []) {
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const u = unitOf(row);
    if (u)
      addRecent(u.acc, t, num(row[FIELDS.recent]), num(row[FIELDS.recentBytes]), false);
  }
  for (const row of input.tokenStatusRows ?? []) {
    const u = unitOf(row);
    if (u)
      addBasis(u.acc, row, num(row[FIELDS.events]), false);
  }
  for (const row of input.tokenLongRows ?? []) {
    const t = rowTime(row);
    if (t === void 0)
      continue;
    const u = unitOf(row);
    if (u)
      addLong(u.acc, t, num(row[FIELDS.recent]), false);
  }
  if (!reported)
    return { rows: [], unmatched };
  const sending = (u) => [...u.acc.windows.values(), ...u.acc.recent.values()].some((x) => x.events.value > 0);
  const shown = units.filter((u) => u.listed || sending(u));
  const labels = shown.map((u) => u.description ?? `token ${u.fp ? u.fp.slice(0, 6) : u.key}`);
  const rows = shown.map((u, i) => {
    const plain = labels[i];
    const label = labels.filter((l) => l === plain).length > 1 && u.fp ? `${plain} (${u.fp.slice(0, 6)})` : plain;
    const id = tokenRowId(parent.id, u.key);
    const disabled = parent.disabled || !u.enabled;
    return {
      id,
      sourceId: parent.sourceId,
      name: `${parent.sourceId} \u203A ${label}`,
      group: parent.group,
      type: parent.type,
      disabled,
      token: { key: u.key, label: u.listed ? label : `${label} (not in the Source's settings)`, parentId: parent.id, enabled: u.enabled, rejected: u.rejected },
      ...summarize(u.acc, disabled, input.allowanceMs(id), c)
    };
  });
  const tc = c.long ? { ...c, long: { ...c.long, read: input.tokenLongRows !== void 0 } } : c;
  return { rows: rows.map((r, i) => judgeOnLong(r, shown[i].acc, tc)), unmatched };
}

// src/data/load.ts
var HEALTH_WINDOW_SECONDS = 120;
var INVENTORY_CONCURRENCY = 4;
var GROUP_ID = /^[A-Za-z0-9._-]+$/;
var INVENTORY_TTL_MS = 5 * 6e4;
var seriesTtlMs = (range) => Math.min(5 * 6e4, range.windowSeconds * 1e3);
var STATUS_RANGE = rangeFor("24h");
var LIVE_REUSE_MS = 3e4;
function asRecord3(v) {
  return v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
}
function parseGroups(payload) {
  const ids = /* @__PURE__ */ new Set();
  for (const item of itemsOf(payload)) {
    const obj = asRecord3(item);
    const id = obj?.id;
    if (typeof id !== "string" || !GROUP_ID.test(id) || id === "." || id === "..")
      continue;
    if (typeof obj?.type === "string" && obj.type !== "stream")
      continue;
    if (obj?.isFleet === true || obj?.isSearch === true)
      continue;
    ids.add(id);
  }
  return [...ids].sort();
}
async function listGroups(t, signal) {
  return parseGroups(await apiGet(t, "/products/stream/groups", signal));
}
function pullGapMinutes(o) {
  const intervals = (Array.isArray(o.contentConfig) ? o.contentConfig : []).map(asRecord3).filter((c) => Boolean(c) && c.enabled !== false && typeof c.interval === "number" && Number.isFinite(c.interval) && c.interval > 0).map((c) => c.interval);
  if (intervals.length)
    return Math.max(...intervals);
  if (typeof o.interval === "number" && Number.isFinite(o.interval) && o.interval > 0) {
    const unit = typeof o.intervalUnit === "string" ? o.intervalUnit.toLowerCase() : "m";
    return unit.startsWith("s") ? o.interval / 60 : unit.startsWith("h") ? o.interval * 60 : o.interval;
  }
  return typeof o.cronSchedule === "string" ? cronLongestGapMinutes(o.cronSchedule) : void 0;
}
function parseInputs(group, payload) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const obj = asRecord3(item);
    const id = obj?.id;
    const type = obj?.type;
    if (typeof id !== "string" || !id || typeof type !== "string" || !type)
      continue;
    const tokens = parseSourceTokens(type, obj);
    const pull = "keepAliveTime" in obj || "maxMissedKeepAlives" in obj;
    const gap = pull ? pullGapMinutes(obj) : void 0;
    out.push({ group, id, type, disabled: obj?.disabled === true, ...tokens ? { tokens } : {}, ...pull ? { pull } : {}, ...gap !== void 0 ? { pullGapMinutes: gap } : {} });
  }
  return out;
}
function collectorRecords(group, payload) {
  const out = [];
  for (const item of itemsOf(payload)) {
    const o = asRecord3(item);
    if (!o || typeof o.id !== "string" || !o.id || o.type !== void 0 && o.type !== "collection")
      continue;
    const schedule = asRecord3(o.schedule);
    const kind = asRecord3(o.collector)?.type;
    const cron = typeof schedule?.cronSchedule === "string" && schedule.cronSchedule.trim() ? schedule.cronSchedule.trim() : void 0;
    out.push({ group, id: o.id, type: "collection", disabled: false, collector: { kind: typeof kind === "string" ? kind : "collector", scheduled: schedule?.enabled === true, ...cron ? { cron } : {} } });
  }
  return out;
}
async function mapPool(items, limit, fn) {
  const results = new Array(items.length);
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      results[i] = await fn(items[i], i);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return results;
}
function groupFilter(groups) {
  return groups.map((g) => `__worker_group == ${JSON.stringify(g)}`).join(" || ");
}
function seriesQuery(range, groups, now) {
  return {
    earliest: bucketStarts(range, now)[0],
    latest: now,
    where: groupFilter(groups),
    aggs: {
      aggregations: [`sum("total.in_events").as("${FIELDS.events}")`, `sum("total.in_bytes").as("${FIELDS.bytes}")`],
      splitBys: ["input", "__worker_group"],
      timeWindowSeconds: range.windowSeconds
    }
  };
}
function recentQuery(groups, now, shape) {
  const w = shape.windowSeconds * 1e3;
  return {
    earliest: Math.floor((now - shape.lookbackSeconds * 1e3) / w) * w,
    latest: now,
    where: groupFilter(groups),
    aggs: {
      aggregations: [`sum("total.in_events").as("${FIELDS.recent}")`, `sum("total.in_bytes").as("${FIELDS.recentBytes}")`],
      splitBys: ["input", "__worker_group"],
      timeWindowSeconds: shape.windowSeconds
    }
  };
}
var TOKEN_SPLIT = ["inputId", "token", "tokenDescription", "__worker_group"];
function tokenSeriesQuery(range, groups, now) {
  return {
    earliest: bucketStarts(range, now)[0],
    latest: now,
    where: groupFilter(groups),
    aggs: {
      aggregations: [`sum("http.perToken.numEvents").as("${FIELDS.events}")`, `sum("http.perToken.bytesReceived").as("${FIELDS.bytes}")`, `sum("http.perToken.numErrors").as("${FIELDS.rejected}")`],
      splitBys: TOKEN_SPLIT,
      timeWindowSeconds: range.windowSeconds
    }
  };
}
function tokenRecentQuery(groups, now, shape) {
  const base = recentQuery(groups, now, shape);
  return {
    ...base,
    aggs: {
      aggregations: [`sum("http.perToken.numEvents").as("${FIELDS.recent}")`, `sum("http.perToken.bytesReceived").as("${FIELDS.recentBytes}")`],
      splitBys: TOKEN_SPLIT,
      timeWindowSeconds: shape.windowSeconds
    }
  };
}
function healthQuery(groups, now) {
  return {
    earliest: now - HEALTH_WINDOW_SECONDS * 1e3,
    latest: now,
    where: groupFilter(groups),
    aggs: { aggregations: [`max("health.inputs").as("${FIELDS.health}")`], cumulative: true, splitBys: ["input", "__worker_group"] }
  };
}
function describe(err) {
  return err instanceof Error ? err.message : String(err);
}
async function loadActivity(t, range, settings, signal, cache = {}, options = {}) {
  const warnings = [];
  const now = Date.now();
  let shape = recentQueryShape(settings);
  let base = {
    range,
    now,
    recentWindowSeconds: shape.windowSeconds,
    recentEarliest: recentQuery([], now, shape).earliest,
    allowanceMs: (id) => allowanceMs(thresholdsFor(settings, id)),
    untracked: settings.untracked.length ? ((untrackedIds) => (id) => untrackedIds.has(id))(new Set(settings.untracked)) : void 0,
    snoozed: Object.keys(settings.snoozed).length ? (id) => snoozedUntil(settings, id, now) : void 0
  };
  let inventory = cache.inventory && now - cache.inventory.at < INVENTORY_TTL_MS ? cache.inventory : void 0;
  if (!inventory) {
    const groups2 = await listGroups(t, signal);
    const unread2 = [];
    const byReason = /* @__PURE__ */ new Map();
    let collectorsRead = true;
    const perGroupCollectors = [];
    const perGroup = await mapPool(groups2, INVENTORY_CONCURRENCY, async (group, i) => {
      const defs = apiGet(t, `/m/${encodeURIComponent(group)}/lib/jobs`, signal).then((payload) => {
        perGroupCollectors[i] = collectorRecords(group, payload);
      }).catch(() => {
        collectorsRead = false;
      });
      try {
        const inputs = parseInputs(group, await apiGet(t, `/m/${encodeURIComponent(group)}/system/inputs`, signal));
        await defs;
        return inputs;
      } catch (err) {
        await defs;
        if (signal?.aborted)
          throw err;
        const reason = describe(err);
        byReason.set(reason, [...byReason.get(reason) ?? [], group]);
        unread2.push(group);
        return [];
      }
    });
    const listWarnings = [...byReason].map(
      ([reason, gs]) => gs.length === 1 ? `Couldn't list Sources in Worker Group "${gs[0]}" (${reason}).` : `Couldn't list Sources in Worker Groups ${gs.map((g) => `"${g}"`).join(", ")} (${reason}).`
    );
    inventory = { at: now, groups: groups2, sources: perGroup.flat(), readable: groups2.filter((_, i) => perGroup[i].length > 0), unread: unread2, warnings: listWarnings, ...collectorsRead ? { collectors: perGroupCollectors.flat().filter(Boolean) } : {} };
    if (unread2.length === 0 && inventory.collectors !== void 0)
      cache.inventory = inventory;
  }
  const { groups, sources, readable, unread } = inventory;
  const collectors = inventory.collectors?.filter((c) => readable.includes(c.group));
  registerCollectorSchedules((collectors ?? []).map((c) => [`${c.group}/collection:${c.id}`, c.collector?.cron]));
  registerPullSchedules(sources.filter((s) => s.pull).map((s) => [`${s.group}/${s.type}:${s.id}`, s.pullGapMinutes]));
  shape = recentQueryShape(settings);
  const long = longQueryShape(settings);
  base = { ...base, recentWindowSeconds: shape.windowSeconds, recentEarliest: recentQuery([], now, shape).earliest };
  warnings.push(...inventory.warnings);
  if (!collectors)
    warnings.push("Collectors couldn't be listed, so they aren't shown with Cribl's metrics.");
  if (groups.length === 0) {
    return { model: buildActivity({ ...base, sources: [], collectors: [], seriesRows: [], recentRows: [], healthRows: [] }), groups, unreadGroups: unread, warnings };
  }
  if (readable.length === 0) {
    return { model: buildActivity({ ...base, sources, collectors, seriesRows: [], recentRows: [], healthRows: [] }), groups, unreadGroups: unread, warnings };
  }
  const seriesKey = `${range.key}|${readable.join(",")}`;
  const cachedSeries = cache.series && cache.series.key === seriesKey && now - cache.series.at < seriesTtlMs(range) ? cache.series : void 0;
  const tokenGroups = options.perToken === false ? [] : [...new Set(sources.filter((s) => s.tokens?.perToken === "on" && readable.includes(s.group)).map((s) => s.group))];
  const tokenKey2 = `${range.key}|${tokenGroups.join(",")}`;
  const cachedTokens = cache.tokenSeries && cache.tokenSeries.key === tokenKey2 && now - cache.tokenSeries.at < seriesTtlMs(range) ? cache.tokenSeries : void 0;
  const none = Promise.resolve(void 0);
  const liveKey = `${readable.join(",")}|${tokenGroups.join(",")}|${shape.lookbackSeconds}|${shape.windowSeconds}|${long ? `${long.lookbackSeconds}/${long.windowSeconds}` : ""}`;
  const cachedLive = cache.live && cache.live.key === liveKey && now - cache.live.at >= 0 && now - cache.live.at < LIVE_REUSE_MS ? cache.live : void 0;
  const statusRange = range.key === STATUS_RANGE.key ? void 0 : STATUS_RANGE;
  const fresh = (c) => c !== void 0 && now - c.at < seriesTtlMs(STATUS_RANGE);
  const statusKey = readable.join(",");
  const cachedStatus = fresh(cache.status) && cache.status.key === statusKey ? cache.status : cache.series && fresh(cache.series) && cache.series.key === `${STATUS_RANGE.key}|${statusKey}` ? cache.series : void 0;
  const tokenStatusKey = tokenGroups.join(",");
  const cachedTokenStatus = fresh(cache.tokenStatus) && cache.tokenStatus.key === tokenStatusKey ? cache.tokenStatus : cache.tokenSeries && fresh(cache.tokenSeries) && cache.tokenSeries.key === `${STATUS_RANGE.key}|${tokenStatusKey}` ? cache.tokenSeries : void 0;
  const [series, recent, health, tokenSeries, tokenRecent, statusSeries, tokenStatusSeries, longRecent, tokenLongRecent] = await Promise.allSettled([
    cachedSeries ? Promise.resolve({ results: cachedSeries.rows }) : apiQuery(t, "/system/metrics/query", seriesQuery(range, readable, cachedLive ? cachedLive.at : now), signal),
    cachedLive ? Promise.resolve({ results: cachedLive.recent }) : apiQuery(t, "/system/metrics/query", recentQuery(readable, now, shape), signal),
    cachedLive ? Promise.resolve({ results: cachedLive.health }) : apiQuery(t, "/system/metrics/query", healthQuery(readable, now), signal),
    tokenGroups.length === 0 ? none : cachedTokens ? Promise.resolve({ results: cachedTokens.rows }) : apiQuery(t, "/system/metrics/query", tokenSeriesQuery(range, tokenGroups, now), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) })),
    tokenGroups.length === 0 ? none : cachedLive?.tokenRecent ? Promise.resolve({ results: cachedLive.tokenRecent }) : apiQuery(t, "/system/metrics/query", tokenRecentQuery(tokenGroups, now, shape), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) })),
    !statusRange ? none : cachedStatus ? Promise.resolve({ results: cachedStatus.rows }) : apiQuery(t, "/system/metrics/query", seriesQuery(statusRange, readable, now), signal),
    !statusRange || tokenGroups.length === 0 ? none : cachedTokenStatus ? Promise.resolve({ results: cachedTokenStatus.rows }) : apiQuery(t, "/system/metrics/query", tokenSeriesQuery(statusRange, tokenGroups, now), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) })),
    !long ? none : cachedLive?.long ? Promise.resolve({ results: cachedLive.long }) : apiQuery(t, "/system/metrics/query", recentQuery(readable, now, long), signal),
    !long || tokenGroups.length === 0 ? none : cachedLive?.tokenLong ? Promise.resolve({ results: cachedLive.tokenLong }) : apiQuery(t, "/system/metrics/query", tokenRecentQuery(tokenGroups, now, long), signal).then((r) => ({ results: scrubTokenRows(r.results ?? []) }))
  ]);
  if (signal?.aborted)
    throw new DOMException("Aborted", "AbortError");
  if (statusRange && statusSeries.status === "fulfilled" && statusSeries.value && cachedStatus !== cache.status)
    cache.status = { at: cachedStatus?.at ?? now, key: statusKey, rows: statusSeries.value.results ?? [] };
  if (statusRange && tokenStatusSeries.status === "fulfilled" && tokenStatusSeries.value && cachedTokenStatus !== cache.tokenStatus)
    cache.tokenStatus = { at: cachedTokenStatus?.at ?? now, key: tokenStatusKey, rows: tokenStatusSeries.value.results ?? [] };
  if (statusRange && statusSeries.status === "rejected")
    warnings.push(`The last day's activity couldn't be read, so statuses use the selected range (${describe(statusSeries.reason)}).`);
  if (statusRange && tokenStatusSeries.status === "rejected")
    warnings.push(`The last day's per-token activity couldn't be read, so tokens' statuses use the selected range (${describe(tokenStatusSeries.reason)}).`);
  if (tokenGroups.length > 0) {
    if (tokenSeries.status === "fulfilled" && tokenSeries.value && !cachedTokens)
      cache.tokenSeries = { at: now, key: tokenKey2, rows: tokenSeries.value.results ?? [] };
    if (tokenSeries.status === "rejected")
      warnings.push(`Per-token query failed, so Sources with several tokens are watched as a whole (${describe(tokenSeries.reason)}).`);
    if (tokenRecent.status === "rejected")
      warnings.push(`Per-token recent-activity query failed, so Sources with several tokens are watched as a whole (${describe(tokenRecent.reason)}).`);
  }
  if (series.status === "rejected")
    throw series.reason;
  if (!cachedSeries)
    cache.series = { at: now, key: seriesKey, rows: series.value.results ?? [] };
  if (recent.status === "rejected")
    warnings.push(`Recent-activity query failed, so Active and Overdue can't be told apart (${describe(recent.reason)}).`);
  if (health.status === "rejected")
    warnings.push(`Health query failed, so Source health isn't shown (${describe(health.reason)}).`);
  if (long && longRecent.status === "rejected")
    warnings.push(`The query for allowances of 6 hours or more failed, so a Source with one longer than a day and no events in it reads Unknown (${describe(longRecent.reason)}).`);
  if (long && tokenGroups.length > 0 && tokenLongRecent.status === "rejected")
    warnings.push(`The per-token query for allowances of 6 hours or more failed, so a token with one longer than a day and no events in it reads Unknown (${describe(tokenLongRecent.reason)}).`);
  const longRows = long && longRecent.status === "fulfilled" && longRecent.value ? longRecent.value.results ?? [] : void 0;
  const tokenLongRows = long && tokenLongRecent.status === "fulfilled" && tokenLongRecent.value ? tokenLongRecent.value.results ?? [] : void 0;
  if (!cachedLive && recent.status === "fulfilled" && health.status === "fulfilled" && (tokenGroups.length === 0 || tokenRecent.status === "fulfilled" && tokenRecent.value) && (!long || longRows !== void 0 && (tokenGroups.length === 0 || tokenLongRows !== void 0))) {
    cache.live = {
      at: now,
      key: liveKey,
      recent: recent.value.results ?? [],
      health: health.value.results ?? [],
      tokenRecent: tokenRecent.status === "fulfilled" && tokenRecent.value ? tokenRecent.value.results ?? [] : void 0,
      ...longRows ? { long: longRows } : {},
      ...tokenLongRows ? { tokenLong: tokenLongRows } : {}
    };
  }
  const asOf = cachedLive ? { now: cachedLive.at, recentEarliest: recentQuery([], cachedLive.at, shape).earliest } : {};
  const model = buildActivity({
    ...base,
    ...asOf,
    sources,
    collectors,
    seriesRows: series.value.results ?? [],
    recentRows: recent.status === "fulfilled" ? recent.value.results ?? [] : void 0,
    healthRows: health.status === "fulfilled" ? health.value.results ?? [] : void 0,
    tokenSeriesRows: tokenSeries.status === "fulfilled" && tokenSeries.value ? tokenSeries.value.results ?? [] : void 0,
    tokenRecentRows: tokenRecent.status === "fulfilled" && tokenRecent.value ? tokenRecent.value.results ?? [] : void 0,
    ...long ? { longWindowSeconds: long.windowSeconds, longRows, tokenLongRows } : {},
    ...statusRange && statusSeries.status === "fulfilled" && statusSeries.value ? {
      statusRows: statusSeries.value.results ?? [],
      statusWindowSeconds: statusRange.windowSeconds,
      ...tokenStatusSeries.status === "fulfilled" && tokenStatusSeries.value ? { tokenStatusRows: tokenStatusSeries.value.results ?? [] } : {}
    } : {}
  });
  const listed = unread.length ? { ...model, unmatchedSeries: model.unmatchedSeries.filter((k) => !unread.includes(k.slice(0, k.indexOf("/")))) } : model;
  return { model: listed, groups, unreadGroups: unread, warnings };
}

// src/data/alertsApi.ts
var ALERTS_KEY = "settings/alerts";
var READ_CONCURRENCY = 4;
var notificationsPath = (group, id) => `/m/${encodeURIComponent(group)}/notifications${id ? `/${encodeURIComponent(id)}` : ""}`;
async function loadAlertState(t, groups, signal, withTargets = true) {
  const [targets, raw, perGroup, lastRun, armState, tokenSearches] = await Promise.all([
    withTargets ? apiGet(t, "/notification-targets", signal).then(parseTargets) : Promise.resolve([]),
    kvRead(t, ALERTS_KEY, signal),
    mapPool(
      groups,
      READ_CONCURRENCY,
      (g) => apiGet(t, notificationsPath(g), signal).then(
        (payload) => ({ group: g, notifications: parseNotifications(g, payload) }),
        () => ({ group: g, notifications: void 0 })
      )
    ),
    kvRead(t, ARM_RUN_KEY, signal).then(parseArmRun, () => void 0),
    kvRead(t, ARM_STATE_KEY, signal).then(parseArmState, () => ({})),
    loadTokenSearches(t, signal).catch(() => void 0)
  ]);
  const running = lastRun !== void 0 && Date.now() - lastRun.at <= RUN_STALE_MS;
  const savedUnreadable = raw !== void 0 && !isAlertSettingsDoc(raw);
  return {
    targets,
    saved: raw !== void 0 && !savedUnreadable ? parseAlertSettings(raw) : void 0,
    savedUnreadable,
    notifications: perGroup.flatMap((p) => p.notifications ?? []),
    failedGroups: perGroup.filter((p) => !p.notifications).map((p) => p.group),
    lastRun,
    armedIds: running ? Object.keys(armState) : [],
    backendRunning: running,
    withTargets,
    ...tokenSearches ? { tokenSearches } : {}
  };
}

// src/data/searchSettings.ts
var SEARCH_KEY = "settings/search";
var DEFAULT_METRICS_QUERY = 'dataset={dataset} | where _metric == "cribl.logstream.total.in_events" and (input == {input} or input startswith {prefix}) and group == {group} | timestats span={span} events=sum(_value)';
var DEFAULT_LOGS_QUERY = "dataset={dataset} | where channel == {channel} | sort by _time desc";
var FORMER_DEFAULTS = /* @__PURE__ */ new Set([
  'dataset={dataset} | where _metric == "cribl.logstream.total.in_events" and input == {input} | timestats span={span} events=sum(_value)',
  'dataset={dataset} | where _metric == "cribl.logstream.total.in_events" and input == {input} and group == {group} | timestats span={span} events=sum(_value)'
]);
var DEFAULT_SEARCH = {
  version: 1,
  metricsEnabled: false,
  metricsDataset: "cribl_metrics",
  logsEnabled: false,
  logsDataset: "cribl_logs",
  metricsQuery: DEFAULT_METRICS_QUERY,
  logsQuery: DEFAULT_LOGS_QUERY,
  lookbackEnabled: false,
  lookbackDays: 30
};
var TOKENS = {
  dataset: "the dataset above",
  input: "Cribl's name for the Source, such as http:in_http or cribl:CriblMetrics",
  prefix: "that name and a colon, to match its protocol variants such as http:in_http:cribl",
  id: "the Source ID",
  channel: "its log channel, input:<Source ID>",
  group: "its Worker Group",
  span: "the chart interval, such as 60s (not quoted)"
};
var DATASET = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/;
var MAX_QUERY = 2e3;
function datasetError(value, required = true) {
  const v = value.trim();
  if (!v)
    return required ? "Enter the dataset to search, or turn this search off." : void 0;
  return DATASET.test(v) ? void 0 : "Use letters, digits, underscores, dots and dashes.";
}
function queryError(value) {
  const v = value.trim();
  if (!v)
    return "Enter a query, or reset it to the default.";
  if (v.length > MAX_QUERY)
    return `Keep it under ${MAX_QUERY} characters.`;
  if (!v.includes("{dataset}"))
    return "Include {dataset}.";
  const unknown = [...v.matchAll(/\{([a-z]+)\}/g)].map((m) => m[1]).find((t) => !(t in TOKENS));
  return unknown ? `Unknown placeholder {${unknown}}.` : void 0;
}
function parseSearchSettings(raw) {
  const o = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  const ds = (v, fallback) => typeof v === "string" && v.trim() && !datasetError(v) ? v.trim() : fallback;
  const on = (v, dataset) => typeof v === "boolean" ? v : typeof dataset === "string" && dataset.trim() !== "" && !datasetError(dataset);
  const q = (v, fallback) => typeof v === "string" && !queryError(v) && !FORMER_DEFAULTS.has(v.trim()) ? v.trim() : fallback;
  return {
    version: 1,
    metricsEnabled: on(o.metricsEnabled, o.metricsDataset),
    metricsDataset: ds(o.metricsDataset, DEFAULT_SEARCH.metricsDataset),
    logsEnabled: on(o.logsEnabled, o.logsDataset),
    logsDataset: ds(o.logsDataset, DEFAULT_SEARCH.logsDataset),
    metricsQuery: q(o.metricsQuery, DEFAULT_METRICS_QUERY),
    logsQuery: q(o.logsQuery, DEFAULT_LOGS_QUERY),
    lookbackEnabled: o.lookbackEnabled === true,
    lookbackDays: typeof o.lookbackDays === "number" && Number.isInteger(o.lookbackDays) && o.lookbackDays >= 1 && o.lookbackDays <= 90 ? o.lookbackDays : DEFAULT_SEARCH.lookbackDays,
    updatedAt: typeof o.updatedAt === "number" ? o.updatedAt : void 0,
    updatedBy: typeof o.updatedBy === "string" ? o.updatedBy : void 0
  };
}
function isSearchDoc(raw) {
  return !!raw && typeof raw === "object" && !Array.isArray(raw) && raw.version === 1;
}
async function loadSearchSettings(t, signal) {
  const raw = await kvRead(t, SEARCH_KEY, signal);
  if (raw === void 0)
    return DEFAULT_SEARCH;
  if (!isSearchDoc(raw))
    throw new UnreadableSettingsError("search settings");
  return parseSearchSettings(raw);
}

// src/data/lookback.ts
var LOOKBACK_KEY = "state/lookback";
var LOOKBACK_DATASET = "default_metrics";
var CLAIM_MS = 5 * 6e4;
var SKEW_MS = 5 * 6e4;
var LAKE_LAG_MS = 10 * 6e4;
var OVERLAP_MS = LAKE_LAG_MS + 5 * 6e4;
function parseLookbackState(raw) {
  const o = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : void 0;
  if (!o || o.version !== 1 || typeof o.at !== "number" || typeof o.dataset !== "string" || typeof o.days !== "number" || !o.last || typeof o.last !== "object")
    return void 0;
  const last = {};
  for (const [k, v] of Object.entries(o.last))
    if (typeof v === "number" && Number.isFinite(v) && k.includes("/"))
      last[k] = v;
  return {
    version: 1,
    at: o.at,
    dataset: o.dataset,
    days: o.days,
    last,
    ...typeof o.failedAt === "number" ? { failedAt: o.failedAt, error: typeof o.error === "string" ? o.error : "The look-back failed." } : {},
    ...typeof o.startedAt === "number" ? { startedAt: o.startedAt } : {}
  };
}
var fits = (s, days) => s !== void 0 && s.dataset === LOOKBACK_DATASET && s.days === days;
function usableLookback(s, days) {
  return fits(s, days) && s.at > 0 ? s : void 0;
}
function coveredFrom(model) {
  const sw = model.windowSeconds * 1e3;
  const i = model.buckets.findIndex((_, j) => model.sources.some((s) => (s.eventsSeries[j] ?? 0) > 0));
  const fromSeries = i >= 0 ? model.buckets[i] + sw : model.generatedAt;
  const fromRecent = model.recentAvailable && model.recentBuckets.length ? model.recentBuckets[0] : model.generatedAt;
  return Math.min(fromSeries, fromRecent);
}
function lookbackApplies(model, state) {
  return state !== void 0 && state.at > 0 && state.at - LAKE_LAG_MS >= coveredFrom(model);
}
function applyLookback(model, state) {
  if (!lookbackApplies(model, state) || Object.keys(state.last).length === 0)
    return model;
  const byName = /* @__PURE__ */ new Map();
  for (const s of model.sources) {
    if (s.token)
      continue;
    const k = byName.get(s.group) ?? /* @__PURE__ */ new Map();
    k.set(`${s.type}:${s.sourceId}`, s);
    k.set(criblInput(s.type, s.sourceId), s);
    byName.set(s.group, k);
  }
  const lastBy = /* @__PURE__ */ new Map();
  for (const [key, at] of Object.entries(state.last)) {
    const i = key.indexOf("/");
    const names = byName.get(key.slice(0, i));
    if (!names)
      continue;
    const r = resolveKey(key.slice(i + 1), new Set(names.keys()));
    const s = r ? names.get(r.base) : void 0;
    if (s)
      lastBy.set(s.id, Math.max(lastBy.get(s.id) ?? 0, at));
  }
  let changed = false;
  const sources = model.sources.map((s) => {
    const at = lastBy.get(s.id);
    const judged = s.lastSeen !== void 0 && s.status !== "nodata";
    if (at === void 0 || s.disabled || s.status === "untracked" || judged || at > model.generatedAt)
      return s;
    changed = true;
    if (s.lastSeen !== void 0 && s.lastSeen > at) {
      const end = Math.min(s.lastSeen + (s.lastSeenResolutionSeconds ?? 60) * 1e3, model.generatedAt - 24 * 60 * 6e4);
      const silent = model.generatedAt - end;
      return { ...s, silentMs: silent, status: silent > s.allowanceMs ? "overdue" : "active" };
    }
    const silentMs = model.generatedAt - at;
    return { ...s, lastSeen: at, lastSeenResolutionSeconds: 60, silentMs, lastSeenFromSearch: true, status: silentMs > s.allowanceMs ? "overdue" : "active" };
  });
  return changed ? { ...model, sources } : model;
}

// src/data/redact.ts
function redactUrls(text2) {
  return text2.replace(/\b([a-z][a-z0-9+.-]*:\/\/)[^\s/@]*@/gi, "$1").replace(/(\b[a-z][a-z0-9+.-]*:\/\/[^\s?#]*)\?[^\s#]*/gi, "$1?\u2026").replace(/(^|\s)(\/[^\s?#]*)\?[^\s#]*/g, "$1$2?\u2026");
}

// src/data/collectors.ts
var SIGNAL_WINDOW_MS = 36e5;
var SIGNAL_LOOKBACK_MS = 7 * 24 * SIGNAL_WINDOW_MS;
function collectorSignalsQuery(groups, now) {
  return {
    earliest: Math.floor((now - SIGNAL_LOOKBACK_MS) / SIGNAL_WINDOW_MS) * SIGNAL_WINDOW_MS,
    latest: now,
    where: `(${groups.map((g) => `__worker_group == ${JSON.stringify(g)}`).join(" || ")}) && !!input && input.startsWith("collection:")`,
    aggs: { aggregations: ['max("health.inputs").as("health")', 'sum("total.in_events").as("events")'], splitBys: ["input", "__worker_group"], timeWindowSeconds: SIGNAL_WINDOW_MS / 1e3 }
  };
}
function collectorSignals(rows) {
  const out = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const input = typeof r.input === "string" ? r.input : "";
    const group = typeof r.__worker_group === "string" ? r.__worker_group : "";
    if (!group || !input.startsWith("collection:"))
      continue;
    const start = rowTime(r);
    if (start === void 0)
      continue;
    const end = toEpochMs(r.endtime) ?? start + SIGNAL_WINDOW_MS;
    const key = `${group}/${input.slice("collection:".length)}`;
    const health = typeof r.health === "number" ? r.health : void 0;
    const cur = out.get(key) ?? { at: 0 };
    if (end > cur.at) {
      cur.at = end;
      cur.health = health;
    } else if (end === cur.at && health !== void 0)
      cur.health = Math.max(cur.health ?? health, health);
    if (typeof r.events === "number" && r.events > 0 && end > (cur.eventsAt ?? 0))
      cur.eventsAt = end;
    out.set(key, cur);
  }
  return out;
}
var RUNS_KEPT = 10;
function runOutcome(r) {
  if (/fail|error|orphan/i.test(r.state))
    return "failed";
  if (/finish|complete|success/i.test(r.state))
    return (r.failedTasks ?? 0) > 0 ? "failed" : "succeeded";
  if (/run|pending|initializ|paused/i.test(r.state))
    return "running";
  return "other";
}
var asRecord4 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
function runTime(id, stats) {
  const states = asRecord4(stats?.state);
  for (const k of ["initializing", "pending", "running"]) {
    const v = states?.[k];
    if (typeof v === "number" && v > 0)
      return v > 1e11 ? v : v * 1e3;
  }
  for (const k of ["startTime", "startedAt", "start", "launchTime"]) {
    const v = stats?.[k];
    if (typeof v === "number" && v > 0)
      return v > 1e11 ? v : v * 1e3;
  }
  const m = id.match(/^(?:[a-z]+:)?(\d{10,14})\./);
  if (!m)
    return void 0;
  const n = Number(m[1]);
  return n > 1e11 ? n : n * 1e3;
}
var num2 = (v) => typeof v === "number" && Number.isFinite(v) ? v : void 0;
var JOB_STATES = ["initializing", "pending", "running", "paused", "cancelled", "finished", "failed", "orphaned", "unknown"];
var stateName = (v) => typeof v === "number" ? JOB_STATES[v] ?? "unknown" : typeof v === "string" && v ? v : "unknown";
function pullRuns(payload) {
  const all = collectorRuns(payload);
  const types = /* @__PURE__ */ new Map();
  for (const item of itemsOf(payload)) {
    const args = asRecord4(asRecord4(item)?.args);
    const type = asRecord4(args?.input)?.type;
    if (typeof args?.id === "string" && typeof type === "string" && type)
      types.set(args.id, type);
  }
  const out = /* @__PURE__ */ new Map();
  for (const [id, runs] of all) {
    const m = /^([^:]+):(.+)$/.exec(id);
    const type = types.get(id);
    if (!m || !type)
      continue;
    let entry = out.get(m[1]);
    if (!entry)
      out.set(m[1], entry = { type, parts: /* @__PURE__ */ new Map() });
    entry.parts.set(m[2], runs);
  }
  return out;
}
function collectorRuns(payload) {
  const out = /* @__PURE__ */ new Map();
  for (const item of itemsOf(payload)) {
    const o = asRecord4(item);
    const args = asRecord4(o?.args);
    if (!o || typeof o.id !== "string" || typeof args?.id !== "string")
      continue;
    const mode = asRecord4(args.run)?.mode;
    if (mode === "preview" || mode === "list")
      continue;
    const status = asRecord4(o.status);
    const reason = asRecord4(status?.reason);
    const stats = asRecord4(o.stats);
    const tasks = asRecord4(stats?.tasks);
    const finishedAt = num2(asRecord4(stats?.state)?.finished);
    const run = {
      jobId: o.id,
      state: stateName(status?.state),
      at: runTime(o.id, stats),
      ...finishedAt ? { finishedAt } : {},
      ...num2(tasks?.count) !== void 0 ? { tasks: num2(tasks?.count), failedTasks: num2(tasks?.failed) ?? 0 } : {},
      ...num2(stats?.collectedEvents) !== void 0 ? { events: num2(stats?.collectedEvents) } : {},
      ...(num2(stats?.collectedBytes) ?? 0) > 0 ? { bytes: num2(stats?.collectedBytes) } : {},
      reason: typeof reason?.message === "string" ? redactUrls(reason.message) : void 0
    };
    out.set(args.id, [...out.get(args.id) ?? [], run]);
  }
  for (const [id, runs] of out)
    out.set(id, runs.sort((a, b) => (b.at ?? 0) - (a.at ?? 0)).slice(0, RUNS_KEPT));
  return out;
}
var COLLECTOR_FILTER_PARAMS = { kind: "ckind", schedule: "csched", run: "crun", status: "cstatus" };
var COLLECTOR_FILTER_KEYS = Object.values(COLLECTOR_FILTER_PARAMS);

// src/data/collectorAlerts.ts
var COLLECTOR_RUNS_KEY = "state/collector-runs";
var FRESH_FAILURE_MS = 15 * 6e4;
var STATUS_SPAN_MS = 24 * 36e5;
function pastAllowance2(row, now = Date.now(), long) {
  if (row.status === "untracked" || row.status === "disabled" || row.snoozedUntil !== void 0)
    return void 0;
  if (row.status === "unknown" || row.status === "nodata" && row.allowanceMs > STATUS_SPAN_MS) {
    if (row.allowanceMs <= STATUS_SPAN_MS || !long)
      return void 0;
    if (long.eventsAt !== void 0)
      return now - long.eventsAt > row.allowanceMs;
    return long.from !== void 0 && now - long.from >= row.allowanceMs ? true : void 0;
  }
  if (row.status === "nodata")
    return true;
  return row.status === "overdue";
}
var rec2 = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : void 0;
function parseCollectorRunState(raw) {
  const seen = {};
  for (const [k, v] of Object.entries(rec2(rec2(raw)?.seen) ?? {})) {
    const o = rec2(v);
    if (!o)
      continue;
    const entry = {
      ...typeof o.job === "string" && typeof o.failed === "boolean" ? { job: o.job, failed: o.failed, ...o.alerted === true ? { alerted: true } : {} } : {},
      ...typeof o.overdue === "boolean" ? { overdue: o.overdue } : {},
      ...o.overdueSent === true ? { overdueSent: true } : {},
      ...typeof o.lastEventAt === "number" && Number.isFinite(o.lastEventAt) ? { lastEventAt: o.lastEventAt } : {}
    };
    if (Object.keys(entry).length)
      seen[k] = entry;
  }
  return { seen };
}
var latestSettled = (runs) => runs?.find((r) => r.jobId.includes(".scheduled.") && (runOutcome(r) === "succeeded" || runOutcome(r) === "failed"));
var failure = (r) => r.failedTasks ? `run failed, ${formatInt(r.failedTasks)} of ${formatInt(r.tasks ?? r.failedTasks)} ${r.tasks === 1 ? "task" : "tasks"} failed` : r.reason ? `run failed: ${r.reason.slice(0, 160)}` : "run failed";
function collectorLink(settings, row) {
  const g = encodeURIComponent(row.group);
  if (!row.collector)
    return settings.linkBase ? `${settings.linkBase}/stream/m/${g}/inputs/${encodeURIComponent(row.type)}/${encodeURIComponent(row.sourceId)}` : `${row.group} \u203A ${row.type}:${row.sourceId}`;
  if (!settings.linkBase)
    return `${row.group} \u203A collection:${row.sourceId}`;
  return `${settings.linkBase}/stream/m/${g}/inputs/collectors/${encodeURIComponent(row.collector.kind)}/${encodeURIComponent(row.sourceId)}`;
}
function nextCollectorAlerts(state, chosen, latest, settings, now, readable = true, long = /* @__PURE__ */ new Map()) {
  const seen = {};
  const rows = {};
  for (const c of chosen) {
    const prev = state.seen[c.row.id] ?? {};
    const next = { ...prev };
    const snoozed = c.row.snoozedUntil !== void 0;
    const link = collectorLink(settings, c.row);
    const description = descriptionFor(settings, c.part?.sourceRowId ?? c.row.id);
    const queue = (status, detail, job) => {
      if (snoozed)
        return;
      (rows[c.searchId] ??= []).push({
        rowId: c.row.id,
        kind: c.part ? "part" : "collector",
        status,
        ...job ? { job } : {},
        ...description ? { description: description.split(SOURCE_LINK).join(link) } : {},
        token: "",
        source: c.part ? `${c.row.type}:${c.row.sourceId} \u203A ${c.part.label}` : `collection:${c.row.sourceId}`,
        group: c.row.group,
        detail,
        link: /^https?:/.test(link) ? link : "",
        at: now
      });
    };
    const run = latest.get(c.row.id);
    let runBack = false;
    if (run && prev.job !== run.jobId) {
      const failed = runOutcome(run) === "failed";
      next.job = run.jobId;
      next.failed = failed;
      if (failed) {
        const alreadyAlerted = prev.failed === true && prev.alerted === true;
        const fresh = now - (run.finishedAt ?? run.at ?? 0) <= FRESH_FAILURE_MS;
        const send = !snoozed && !alreadyAlerted && (prev.job !== void 0 || fresh);
        if (send)
          queue("Failed", failure(run), run.jobId);
        if (alreadyAlerted || send)
          next.alerted = true;
        else
          delete next.alerted;
      } else {
        if (prev.failed && prev.alerted) {
          queue("Back", "Back, a run succeeded", run.jobId);
          runBack = true;
        }
        delete next.alerted;
      }
    }
    const lv = long.get(c.row.id);
    if (lv?.eventsAt !== void 0 && lv.eventsAt > (prev.lastEventAt ?? 0))
      next.lastEventAt = lv.eventsAt;
    const past = readable && !c.part ? pastAllowance2(c.row, now, lv ? { ...lv, eventsAt: lv.eventsAt ?? prev.lastEventAt } : prev.lastEventAt !== void 0 ? { eventsAt: prev.lastEventAt } : void 0) : void 0;
    if (past !== void 0) {
      const held = next.failed && next.alerted || runBack;
      if (past && !prev.overdue) {
        if (!held) {
          next.overdue = true;
          queue("Overdue", `Overdue, no events for longer than its ${formatDuration(c.row.allowanceMs)} allowance`);
          if (!snoozed)
            next.overdueSent = true;
        }
      } else if (!past && prev.overdue) {
        next.overdue = false;
        if (prev.overdueSent && !runBack)
          queue("Back", "Back, collecting again");
        delete next.overdueSent;
      } else
        next.overdue = past;
    }
    if (Object.keys(next).length)
      seen[c.row.id] = next;
  }
  return { state: { seen }, rows };
}
async function runCollectorAlerts(t, model, settings, now, readable = false) {
  const done = [];
  const failed = [];
  if (!model || !settings)
    return { done, failed };
  const chosen = chosenCollectors(model, settings);
  const pulls = "sources" in model ? chosenPullSources(model, settings) : [];
  const stored = parseCollectorRunState(await kvRead(t, COLLECTOR_RUNS_KEY));
  if (chosen.length === 0 && pulls.length === 0 && Object.keys(stored.seen).length === 0)
    return { done, failed };
  const latest = /* @__PURE__ */ new Map();
  for (const group of [.../* @__PURE__ */ new Set([...chosen.map((c) => c.row.group), ...pulls.map((p) => p.source.group)])]) {
    try {
      const payload = await apiGet(t, `/m/${encodeURIComponent(group)}/jobs`);
      const runs = collectorRuns(payload);
      for (const c of chosen)
        if (c.row.group === group)
          latest.set(c.row.id, latestSettled(runs.get(c.row.sourceId)));
      const byPull = pullRuns(payload);
      for (const p of pulls) {
        if (p.source.group !== group)
          continue;
        for (const [key, partRuns] of byPull.get(p.source.sourceId)?.parts ?? []) {
          const id = `${p.source.id}~${key}`;
          chosen.push({ row: { ...p.source, id, status: "unknown", part: { key, parentId: p.source.id } }, deliveryKey: p.deliveryKey, searchId: p.searchId, part: { key, label: key.replace(/_/g, " "), sourceRowId: p.source.id } });
          latest.set(id, latestSettled(partRuns));
        }
      }
    } catch (err) {
      failed.push(`collector runs in ${group}: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
  const long = /* @__PURE__ */ new Map();
  const longOnes = chosen.filter((c) => !c.part && c.row.allowanceMs > STATUS_SPAN_MS && (c.row.status === "unknown" || c.row.status === "nodata"));
  if (readable && longOnes.length) {
    try {
      const groups = [...new Set(longOnes.map((c) => c.row.group))];
      const r = await apiQuery(t, "/system/metrics/query", collectorSignalsQuery(groups, now));
      const rows = r.results ?? [];
      const signals = collectorSignals(rows);
      let from = now;
      for (const x of rows)
        from = Math.min(from, rowTime(x) ?? now);
      for (const c of longOnes)
        long.set(c.row.id, { eventsAt: signals.get(`${c.row.group}/${c.row.sourceId}`)?.eventsAt, ...rows.length ? { from } : {} });
    } catch (err) {
      failed.push(`collector hourly metrics: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
  const next = nextCollectorAlerts(stored, chosen, latest, settings, now, readable, long);
  const alertingIds = new Set(settings.enabled ? settings.alerting : []);
  for (const [id, v] of Object.entries(stored.seen)) {
    if (id in next.state.seen)
      continue;
    const keep = id.includes("~") ? alertingIds.has(id.slice(0, id.indexOf("~"))) : model.collectors === void 0 && alertingIds.has(id);
    if (keep)
      next.state.seen[id] = v;
  }
  if (JSON.stringify(next.state) === JSON.stringify(stored))
    return { done, failed };
  try {
    await kvWrite(t, COLLECTOR_RUNS_KEY, next.state);
  } catch (err) {
    failed.push(`collector alerts: couldn't record them (${err instanceof Error ? err.message : String(err)}), so nothing was queued`);
    return { done, failed };
  }
  if (Object.keys(next.rows).length === 0)
    return { done, failed };
  try {
    const queue = parseTokenAlertState(await kvRead(t, TOKEN_ALERTS_KEY));
    for (const [id, rows] of Object.entries(next.rows)) {
      const waiting = queue.pending[id] ??= [];
      for (const r of rows) {
        if (waiting.some((w) => w.rowId === r.rowId && w.job === r.job && w.status === r.status))
          continue;
        const opposite = r.job === void 0 ? waiting.findIndex((w) => w.rowId === r.rowId && w.job === void 0 && w.status !== r.status) : -1;
        if (opposite >= 0)
          waiting.splice(opposite, 1);
        else
          waiting.push(r);
      }
      if (waiting.length === 0)
        delete queue.pending[id];
    }
    await kvWrite(t, TOKEN_ALERTS_KEY, queue);
    for (const rows of Object.values(next.rows))
      for (const r of rows)
        done.push(`queued ${r.source} in ${r.group}: ${r.detail}`);
  } catch (err) {
    failed.push(`collector alerts: couldn't queue them (${err instanceof Error ? err.message : String(err)})`);
    await kvWrite(t, COLLECTOR_RUNS_KEY, stored).catch(() => failed.push("collector alerts: couldn't put the old record back; this change may not be sent"));
  }
  return { done, failed };
}

// src/data/armingRun.ts
async function allowancesReadable(t) {
  const res = await t(`/kvstore/${SETTINGS_KEY}`);
  if (res.status === 404)
    return true;
  if (!res.ok)
    return false;
  const text2 = (await res.text()).trim();
  return !text2 || unwrapKvValue(text2) !== void 0;
}
var message = (err) => err instanceof Error ? err.message : String(err);
var holdNoData = (model) => ({ ...model, sources: model.sources.map((s) => s.status === "nodata" ? { ...s, status: "unknown" } : s) });
async function withLookback(t, model) {
  try {
    const search = await loadSearchSettings(t);
    if (!search.lookbackEnabled)
      return model;
    const state = usableLookback(parseLookbackState(await kvRead(t, LOOKBACK_KEY)), search.lookbackDays);
    return lookbackApplies(model, state) ? applyLookback(model, state) : holdNoData(model);
  } catch {
    return holdNoData(model);
  }
}
async function runArming(t, now) {
  const result = { at: now, own: 0, armed: 0, done: [], failed: [] };
  const ctx = {};
  try {
    await armSources(t, now, result, ctx);
  } catch (err) {
    result.failed.push(`run: ${message(err)}`);
  }
  const settings = ctx.alerts ? ctx.alerts.savedUnreadable ? void 0 : effectiveAlertSettings(ctx.alerts.saved, ctx.alerts.notifications, ctx.model?.sources ?? []).settings : ctx.choices;
  try {
    const runs = await runCollectorAlerts(t, ctx.model, settings, now, ctx.readable === true);
    result.done.push(...runs.done);
    result.failed.push(...runs.failed);
  } catch (err) {
    result.failed.push(`collector runs: ${message(err)}`);
  }
  try {
    const sent = await runTokenAlerts(t, ctx.model, settings, now, ctx.readable === true && settings !== void 0);
    result.done.push(...sent.done);
    result.failed.push(...sent.failed);
  } catch (err) {
    result.failed.push(`token alerts: ${message(err)}`);
  }
  return result;
}
async function armSources(t, now, result, ctx) {
  if (!await allowancesReadable(t)) {
    result.skipped = "saved allowances are unreadable";
    return;
  }
  const settings = await loadSettings(t);
  const choices = await kvRead(t, ALERTS_KEY).then((raw) => raw !== void 0 && isAlertSettingsDoc(raw) ? parseAlertSettings(raw) : void 0, () => void 0);
  if (choices)
    ctx.choices = choices;
  const tokensOn = choices ? choices.enabled && (Object.keys(choices.tokens).length > 0 || choices.alerting.length > 0) : false;
  const { model, groups } = await loadActivity(t, rangeFor("24h"), settings, void 0, {}, { perToken: tokensOn });
  ctx.model = model;
  if (!model.recentAvailable) {
    result.skipped = "recent activity unreadable";
    return;
  }
  const enabled = model.sources.filter((s) => !s.disabled);
  if (enabled.length > 0 && enabled.every((s) => s.recentEvents.every((v) => !v))) {
    result.skipped = "no recent events from any Source";
    return;
  }
  ctx.readable = choices !== void 0;
  const alerts = await loadAlertState(t, groups, void 0, false);
  ctx.alerts = alerts;
  const own = alerts.notifications.filter(isOwnAlert);
  result.own = own.length;
  const state = parseArmState(await kvRead(t, ARM_STATE_KEY));
  if (own.length === 0 && Object.keys(state).length === 0)
    return;
  const paused = parseSnoozePaused(await kvRead(t, SNOOZE_PAUSED_KEY).catch(() => void 0));
  let pausedChanged = false;
  const snooze = planSnooze(own, settings.snoozed, paused, now);
  for (const [n, disabled] of [...snooze.pause.map((x) => [x, true]), ...snooze.resume.map((x) => [x, false])]) {
    const path = `/m/${encodeURIComponent(n.group)}/notifications/${encodeURIComponent(n.id)}`;
    try {
      const current = parseNotifications(n.group, await apiGet(t, path))[0];
      if (!current || !isOwnAlert(current))
        continue;
      if (current.disabled !== disabled) {
        const rest = disabled && isArmed(current) ? state[n.id]?.restWindow : void 0;
        await apiWrite(t, "PATCH", path, disabledBody(current.raw, disabled, rest));
        result.done.push(`${disabled ? "pause" : "resume"} ${n.id}: ${n.input} in ${n.group} ${disabled ? "is snoozed" : "is no longer snoozed"}`);
        if (rest)
          delete state[n.id];
      }
      if (disabled)
        paused[n.id] = now;
      else
        delete paused[n.id];
      pausedChanged = true;
      n.disabled = disabled;
    } catch (err) {
      result.failed.push(`${disabled ? "pause" : "resume"} ${n.id}: ${message(err)}`);
    }
  }
  if (pausedChanged)
    await kvWrite(t, SNOOZE_PAUSED_KEY, paused).catch((err) => result.failed.push(`recording paused alerts: ${message(err)}`));
  const { actions, next } = planArming((await withLookback(t, model)).sources, own, state, now);
  if (alerts.failedGroups.length) {
    for (const [id, v] of Object.entries(state))
      if (!(id in next) && !own.some((n) => n.id === id))
        next[id] = v;
  }
  for (const a of actions) {
    const n = a.notification;
    const path = `/m/${encodeURIComponent(n.group)}/notifications/${encodeURIComponent(n.id)}`;
    const keepPrior = () => {
      if (state[n.id])
        next[n.id] = state[n.id];
      else
        delete next[n.id];
    };
    try {
      const current = parseNotifications(n.group, await apiGet(t, path))[0];
      if (!current || !isOwnAlert(current) || current.disabled || isArmed(current) === (a.kind === "arm")) {
        result.done.push(`${a.kind} ${n.id}: skipped, it changed since this run read it`);
        keepPrior();
        continue;
      }
      await apiWrite(t, "PATCH", path, windowBody(current.raw, a.timeWindow));
      result.done.push(`${a.kind} ${n.id} \u2192 ${a.timeWindow}: ${a.reason}`);
    } catch (err) {
      result.failed.push(`${a.kind} ${n.id}: ${message(err)}`);
      keepPrior();
    }
  }
  await kvWrite(t, ARM_STATE_KEY, next);
  result.armed = Object.keys(next).length;
}

// backend/check.ts
var message2 = (err) => err instanceof Error ? err.message : String(err);
async function onRequest(_request, context) {
  const t = (path, init) => fetch(path.startsWith("/kvstore/") ? `/api/v1/a/${encodeURIComponent(context.appId)}${path}` : `/api/v1${path}`, init);
  const now = Date.now();
  let result;
  try {
    result = await runArming(t, now);
  } catch (err) {
    result = { at: now, own: 0, armed: 0, done: [], failed: [`run: ${message2(err)}`] };
  }
  try {
    await kvWrite(t, ARM_RUN_KEY, result);
  } catch (err) {
    result.failed.push(`recording this run: ${message2(err)}`);
  }
  return new Response(JSON.stringify(result), { status: 200, headers: { "content-type": "application/json" } });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  onRequest
});
//# sourceMappingURL=check.js.map
